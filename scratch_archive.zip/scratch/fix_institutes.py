import json

master_path = 'src/frontend/src/data/master_workshops.json'
with open(master_path, 'r', encoding='utf-8') as f:
    master_data = json.load(f)

for ws in master_data:
    if ws.get("number") == 8:
        # Fix presentation sessions
        for session in ws.get("presentation_sessions", []):
            for pres in session.get("presentations", []):
                institutes_set = set()
                for author in pres.get("authors", []):
                    inst = author.get("institute")
                    if inst:
                        institutes_set.add(inst)
                pres["institutes"] = list(institutes_set)

        # Fix posters
        for poster in ws.get("posters", []):
            institutes_set = set()
            for author in poster.get("authors", []):
                inst = author.get("institute")
                if inst:
                    institutes_set.add(inst)
            poster["institutes"] = list(institutes_set)

with open(master_path, 'w', encoding='utf-8') as f:
    json.dump(master_data, f, indent=2)

print("Successfully injected institutes arrays into Presentations and Posters for Workshop 8.")
