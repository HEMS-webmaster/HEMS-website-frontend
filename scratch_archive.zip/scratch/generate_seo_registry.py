import os
import json
import sys

# Ensure stdout uses UTF-8
sys.stdout.reconfigure(encoding='utf-8')

# Dynamic relative path resolution
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SCRIPT_DIR)

master_path = os.path.join(BASE_DIR, "src", "frontend", "src", "data", "master_workshops.json")
proceedings_base = os.path.join(BASE_DIR, "docs", "archives_translation", "proceedings")
output_md_path = os.path.join(BASE_DIR, "docs", "design", "pdf_seo_registry.md")

if not os.path.exists(master_path):
    print(f"Error: master_workshops.json not found at {master_path}")
    sys.exit(1)

with open(master_path, 'r', encoding='utf-8') as f:
    workshops = json.load(f)

def find_file_recursively(directory, filename):
    if not os.path.exists(directory):
        return None
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower() == filename.lower():
                # Return relative path from HEMS-website root to be clean
                abs_path = os.path.join(root, file)
                return os.path.relpath(abs_path, BASE_DIR)
    return None

print(f"Loaded {len(workshops)} workshops from metadata. Compiling PDF SEO Registry...")

registry_entries = []

def get_ordinal(n):
    n = int(n)
    if 11 <= (n % 100) <= 13:
        suffix = 'th'
    else:
        suffix = ['th', 'st', 'nd', 'rd', 'th', 'th', 'th', 'th', 'th', 'th'][n % 10]
    return f"{n}{suffix}"


# Loop through workshops to find all PDFs
for ws in workshops:
    year = ws.get('year')
    ordinal = ws.get('number')
    ordinal_str = get_ordinal(ordinal)
    proceedings_dir = os.path.join(proceedings_base, ordinal_str)

    
    # Process oral presentations
    if 'presentation_sessions' in ws and isinstance(ws['presentation_sessions'], list):
        for session in ws['presentation_sessions']:
            session_title = session.get('session_title') or session.get('title') or "Oral Session"
            if 'presentations' in session and isinstance(session['presentations'], list):
                for talk in session['presentations']:
                    title = talk.get('title', '').strip()
                    # Authors list
                    authors_list = []
                    raw_authors = talk.get('authors')
                    if isinstance(raw_authors, list):
                        for a in raw_authors:
                            if isinstance(a, dict) and 'name' in a:
                                authors_list.append(a['name'])
                    elif isinstance(raw_authors, str):
                        authors_list = [n.strip() for n in raw_authors.split(',')]
                    
                    author_str = ", ".join(authors_list)
                    
                    # Check files
                    p_file = talk.get('presentation_file')
                    a_file = talk.get('abstract_file')
                    
                    if p_file:
                        p_path = find_file_recursively(proceedings_dir, p_file)
                        if p_path:
                            registry_entries.append({
                                'filename': p_file,
                                'path': p_path,
                                'year': year,
                                'ordinal': ordinal,
                                'type': 'Presentation',
                                'title': title,
                                'authors': author_str,
                                'session': session_title
                            })
                            
                    if a_file:
                        a_path = find_file_recursively(proceedings_dir, a_file)
                        if a_path:
                            registry_entries.append({
                                'filename': a_file,
                                'path': a_path,
                                'year': year,
                                'ordinal': ordinal,
                                'type': 'Abstract',
                                'title': title,
                                'authors': author_str,
                                'session': session_title
                            })
                            
    # Process posters
    if 'posters' in ws and isinstance(ws['posters'], list):
        for poster in ws['posters']:
            title = poster.get('title', '').strip()
            authors_list = []
            raw_authors = poster.get('authors')
            if isinstance(raw_authors, list):
                for a in raw_authors:
                    if isinstance(a, dict) and 'name' in a:
                        authors_list.append(a['name'])
            elif isinstance(raw_authors, str):
                authors_list = [n.strip() for n in raw_authors.split(',')]
            
            author_str = ", ".join(authors_list)
            
            p_file = poster.get('poster_file')
            a_file = poster.get('abstract_file')
            
            if p_file:
                p_path = find_file_recursively(proceedings_dir, p_file)
                if p_path:
                    registry_entries.append({
                        'filename': p_file,
                        'path': p_path,
                        'year': year,
                        'ordinal': ordinal,
                        'type': 'Poster',
                        'title': title,
                        'authors': author_str,
                        'session': 'Poster Session'
                    })
                    
            if a_file:
                a_path = find_file_recursively(proceedings_dir, a_file)
                if a_path:
                    registry_entries.append({
                        'filename': a_file,
                        'path': a_path,
                        'year': year,
                        'ordinal': ordinal,
                        'type': 'Abstract',
                        'title': title,
                        'authors': author_str,
                        'session': 'Poster Session'
                    })

print(f"Identified {len(registry_entries)} valid local PDF files with catalog metadata.")

# Write the Markdown Registry
md_lines = []
md_lines.append("# HEMS Workshop PDF SEO Metadata Registry")
md_lines.append("")
md_lines.append("This document contains the SEO metadata registry for all proceedings PDF files. Organize metadata properties for search engines here. Once customized, run the Python injection script to write these properties directly into the internal PDF files.")
md_lines.append("")
md_lines.append("---")
md_lines.append("")

for idx, entry in enumerate(registry_entries):
    # Construct descriptive subject
    subject_str = f"{entry['type']} from the {get_ordinal(entry['ordinal'])} HEMS Workshop ({entry['year']}), {entry['session']}."
    
    # Construct smart keyword list
    title_words = [w.strip("(),.[]:;\"'").lower() for w in entry['title'].split()]
    ignored_words = {'and', 'the', 'of', 'in', 'on', 'for', 'with', 'a', 'an', 'to', 'using', 'by', 'from', 'at'}
    clean_words = [w for w in title_words if w.isalpha() and w not in ignored_words and len(w) > 3]
    pre_keywords = ", ".join(clean_words[:6])
    
    md_lines.append(f"### Registry ID: {idx + 1}")
    md_lines.append(f"*   **Filename**: `{entry['filename']}`")
    md_lines.append(f"*   **Path**: `{entry['path']}`")
    md_lines.append(f"*   **Type**: `{entry['type']}`")
    md_lines.append(f"*   **Year**: `{entry['year']}`")
    md_lines.append(f"*   **Title**: {entry['title']}")
    md_lines.append(f"*   **Authors**: {entry['authors']}")
    md_lines.append(f"*   **Subject**: {subject_str}")
    md_lines.append(f"*   **Keywords**: {pre_keywords}")
    md_lines.append("")
    md_lines.append("---")
    md_lines.append("")

with open(output_md_path, 'w', encoding='utf-8') as f:
    f.write("\n".join(md_lines))

print(f"Successfully generated HEMS PDF SEO Registry at: {output_md_path}")
