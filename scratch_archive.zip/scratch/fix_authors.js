const fs = require('fs');
const path = './src/frontend/src/data/master_workshops.json';
const data = JSON.parse(fs.readFileSync(path, 'utf8'));

const ws2005 = data.find(ws => ws.year === "2005");

function fixAuthors(items) {
  if (!items) return;
  items.forEach(item => {
    if (typeof item.authors === 'string') {
      const presenterName = (item.presenter || '').trim();
      const authorNames = item.authors.split(',').map(n => n.trim());
      item.authors = authorNames.map(name => ({
        name: name,
        isPresenter: name === presenterName
      }));
      // remove the string presenter field to match schema
      delete item.presenter;
    }
  });
}

fixAuthors(ws2005.presentations);
fixAuthors(ws2005.posters);

fs.writeFileSync(path, JSON.stringify(data, null, 2));
console.log('Fixed authors schema for 2005');
