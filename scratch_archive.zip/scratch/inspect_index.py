import json

index_path = r"c:\Antigravity\HEMS-website\src\frontend\public\archives-index.json"
try:
    with open(index_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"Loaded {len(data)} items from flat index.")
    
    # Find items with Wright
    matches = []
    for item in data:
        text = json.dumps(item).lower()
        if 'wright' in text:
            matches.append(item)
            
    print(f"Found {len(matches)} matches for 'Wright':")
    for m in matches:
        print(m)
except Exception as e:
    print(f"Error: {e}")
