import json

master_file = 'src/frontend/src/data/master_workshops.json'

# Load master workshops database
with open(master_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Find Workshop 1
ws1 = None
for ws in data:
    if ws.get('number') == 1:
        ws1 = ws
        break

if ws1 is None:
    print("Error: Workshop 1 not found in master_workshops.json.")
    exit(1)

# 1. Update metadata fields
ws1['city'] = "St. Petersburg, Florida"
ws1['location'] = "St. Petersburg, Florida"
ws1['dates'] = "February 21–23"  # uses en-dash
ws1['venue'] = ""
ws1['venue_url'] = ""
ws1['venue_address_url'] = ""
ws1['program_url'] = "https://www.hems-workshop.org/1stWS/1hems_program.pdf"
ws1['program_file'] = "1th_Program.pdf"
ws1['participant_list_url'] = ""
ws1['participant_list_file'] = ""
ws1['host_corporation'] = {
    "name": "University of South Florida, Marine Science Department, Center for Ocean Technology",
    "url": ""
}
ws1['tagline'] = "The 1st Workshop on Harsh-Environment Mass Spectrometry."

# 2. Update itinerary events
ws1['events'] = [
    {
        "date": "1999-02-21",
        "title": "Opening Day",
        "events": [
            {
                "time": "7:00 PM",
                "end_time": "",
                "title": "Informal reception",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Moon over Water Restaurant, St. Petersburg",
                "location_url": ""
            }
        ]
    },
    {
        "date": "1999-02-22",
        "title": "HEMS Workshop, Day 1",
        "events": [
            {
                "time": "8:50 AM",
                "end_time": "",
                "title": "Opening remarks",
                "subtitle": "Peter Betzer, Chair, Department of Marine Science, USF",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "10:00 AM",
                "end_time": "",
                "title": "Break",
                "subtitle": "Refreshments Provided",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "11:00 AM",
                "end_time": "",
                "title": "Lunch Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "2:00 PM",
                "end_time": "",
                "title": "Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "3:00 PM",
                "end_time": "",
                "title": "Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "3:30 PM",
                "end_time": "7:00 PM",
                "title": "Excursion and Dinner",
                "subtitle": "Cruise on the Research Vessel (R/V) Suncoaster",
                "subtitle_url": "",
                "location": "Tampa Bay",
                "location_url": ""
            }
        ]
    },
    {
        "date": "1999-02-23",
        "title": "HEMS Workshop, Day 2",
        "events": [
            {
                "time": "10:00 AM",
                "end_time": "",
                "title": "Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "11:20 AM",
                "end_time": "",
                "title": "Closing Remarks...",
                "subtitle": "David Fries and Tim Short, USF",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            }
        ]
    }
]

# 3. Update presentation sessions
ws1['presentation_sessions'] = [
    {
        "session_title": "Monday Presentations",
        "title": "Monday Presentations",
        "date": "1999-02-22",
        "location": "UNKNOWN",
        "presentations": [
            {
                "time": "9:00 AM",
                "end_time": "",
                "title": "Mass Spectrometer on an Autonomous Underwater Vehicle (AUV)",
                "authors": [
                    {
                        "name": "Tim Short",
                        "isPresenter": True,
                        "institute": "USF"
                    }
                ],
                "presenter": "Tim Short",
                "presenter_initials": "T. S.",
                "institutes": ["USF"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "9:20 AM",
                "end_time": "",
                "title": "Mass Spectrometers aboard US Navy Submarines: Will Yesterday's Solutions Solve Tomorrow's Problems?",
                "authors": [
                    {
                        "name": "John Callahan",
                        "isPresenter": True,
                        "institute": "NRL"
                    }
                ],
                "presenter": "John Callahan",
                "presenter_initials": "J. C.",
                "institutes": ["NRL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "9:40 AM",
                "end_time": "",
                "title": "ICP-Mass Spectrometer: Extended At-Sea Trials",
                "authors": [
                    {
                        "name": "Alan Volpe",
                        "isPresenter": True,
                        "institute": "LLNL"
                    }
                ],
                "presenter": "Alan Volpe",
                "presenter_initials": "A. V.",
                "institutes": ["LLNL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "10:20 AM",
                "end_time": "",
                "title": "The Road to Miniaturizing Vacuum Pumps",
                "authors": [
                    {
                        "name": "Woody Weed",
                        "isPresenter": True,
                        "institute": "SNL"
                    }
                ],
                "presenter": "Woody Weed",
                "presenter_initials": "W. W.",
                "institutes": ["SNL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "10:40 AM",
                "end_time": "",
                "title": "Mass Spectrometry in Harsh Environments: The Use & Abuse of MS Techniques",
                "authors": [
                    {
                        "name": "David Koppenaal",
                        "isPresenter": True,
                        "institute": "PNNL"
                    }
                ],
                "presenter": "David Koppenaal",
                "presenter_initials": "D. K.",
                "institutes": ["PNNL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "1:00 PM",
                "end_time": "",
                "title": "Miniature Time-of-Flight Mass Analyzers for Remote Sensing of Biochemical Agents",
                "authors": [
                    {
                        "name": "Tim Cornish",
                        "isPresenter": True,
                        "institute": "APL"
                    }
                ],
                "presenter": "Tim Cornish",
                "presenter_initials": "T. C.",
                "institutes": ["APL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "1:20 PM",
                "end_time": "",
                "title": "Miniature Mass Spectrometer-Based Sampling System for In Situ Measurement of Dissolved Gas, Solutes and Proteins present in Marine Waters",
                "authors": [
                    {
                        "name": "Steven Smith",
                        "isPresenter": True,
                        "institute": "JPL"
                    }
                ],
                "presenter": "Steven Smith",
                "presenter_initials": "S. S.",
                "institutes": ["JPL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "1:40 PM",
                "end_time": "",
                "title": "A Transportable lon Trap Secondary lon Mass Spectrometer for Munitions Assessment",
                "authors": [
                    {
                        "name": "John Olson",
                        "isPresenter": True,
                        "institute": "INEEL"
                    }
                ],
                "presenter": "John Olson",
                "presenter_initials": "J. O.",
                "institutes": ["INEEL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "2:20 PM",
                "end_time": "",
                "title": "Quadrupole lon Traps: Miniaturization and Mass Spectrometer Arrays",
                "authors": [
                    {
                        "name": "Ethan Badman",
                        "isPresenter": True,
                        "institute": "Purdue Univ."
                    }
                ],
                "presenter": "Ethan Badman",
                "presenter_initials": "E. B.",
                "institutes": ["Purdue Univ."],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "2:40 PM",
                "end_time": "",
                "title": "Current and Future Applications of Mass Spectrometric Analyses in Non-Traditional Environments",
                "authors": [
                    {
                        "name": "Chuck Wilkerson",
                        "isPresenter": True,
                        "institute": "LANL"
                    }
                ],
                "presenter": "Chuck Wilkerson",
                "presenter_initials": "C. W.",
                "institutes": ["LANL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            }
        ]
    },
    {
        "session_title": "Tuesday Presentations",
        "title": "Tuesday Presentations",
        "date": "1999-02-23",
        "location": "UNKNOWN",
        "presentations": [
            {
                "time": "9:00 AM",
                "end_time": "",
                "title": "Underwater MS: Making more Scents",
                "authors": [
                    {
                        "name": "David Fries",
                        "isPresenter": True,
                        "institute": "USF"
                    }
                ],
                "presenter": "David Fries",
                "presenter_initials": "D. F.",
                "institutes": ["USF"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "9:20 AM",
                "end_time": "",
                "title": "A Mini-lon Cyclotron Resonance Mass spectrometer with Portable Potential",
                "authors": [
                    {
                        "name": "UNKNOWN",
                        "isPresenter": True,
                        "institute": "UNKNOWN"
                    }
                ],
                "presenter": "UNKNOWN",
                "presenter_initials": "",
                "institutes": ["UNKNOWN"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "9:40 AM",
                "end_time": "",
                "title": "Laser Time-of-Flight Mass Spectrometry for Planetary Exploration",
                "authors": [
                    {
                        "name": "Will Brinckerhoff",
                        "isPresenter": True,
                        "institute": "APL"
                    }
                ],
                "presenter": "Will Brinckerhoff",
                "presenter_initials": "W. B.",
                "institutes": ["APL"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "10:20 AM",
                "end_time": "",
                "title": "Fourier Transform Non-Destructive Detection in Quadrupole lon Traps",
                "authors": [
                    {
                        "name": "Garth Patterson",
                        "isPresenter": True,
                        "institute": "Purdue Univ."
                    }
                ],
                "presenter": "Garth Patterson",
                "presenter_initials": "G. P.",
                "institutes": ["Purdue Univ."],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "10:40 AM",
                "end_time": "",
                "title": "Mass Spectrometric Profiling of the Lower Atmosphere: Go Fly a Kite",
                "authors": [
                    {
                        "name": "Steve Balsley",
                        "isPresenter": True,
                        "institute": "Sandia"
                    }
                ],
                "presenter": "Steve Balsley",
                "presenter_initials": "S. B.",
                "institutes": ["Sandia"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            },
            {
                "time": "11:00 AM",
                "end_time": "",
                "title": "Ruggedized Time-of-Flight Mass Spectrometer for Trace Gas Analysis",
                "authors": [
                    {
                        "name": "Marc Gonin",
                        "isPresenter": True,
                        "institute": "University of Houston/lonWerks"
                    }
                ],
                "presenter": "Marc Gonin",
                "presenter_initials": "M. G.",
                "institutes": ["University of Houston/lonWerks"],
                "legacy_url": "",
                "legacy_abstract_url": "",
                "abstract_url": "",
                "abstract_file": ""
            }
        ]
    }
]

# Write updated master database back to file
with open(master_file, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Successfully populated Workshop 1 (1999) content in master_workshops.json.")
