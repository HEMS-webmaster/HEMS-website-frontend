const fs = require('fs');
const path = require('path');

const masterPath = path.join(__dirname, '..', 'src', 'frontend', 'src', 'data', 'master_workshops.json');
const data = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2018 = data.find(ws => ws.year === 2018);
console.log('2018 HEMS workshop object:', JSON.stringify(ws2018, null, 2));
