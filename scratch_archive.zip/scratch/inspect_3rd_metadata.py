import json
import os

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total workshops: {len(data)}")
for ws in data:
    if ws.get('number') == 3:
        print("\n--- 3rd Workshop Metadata ---")
        print(f"Year: {ws.get('year')}")
        print(f"Number: {ws.get('number')}")
        
        # Check sessions
        if 'presentation_sessions' in ws:
            print(f"Sessions count: {len(ws['presentation_sessions'])}")
            for idx, session in enumerate(ws['presentation_sessions']):
                print(f"\n  Session {idx+1}: {session.get('session_title') or session.get('title')}")
                for talk in session.get('presentations', []):
                    title = talk.get('title')
                    p_file = talk.get('presentation_file')
                    a_file = talk.get('abstract_file')
                    if p_file or a_file:
                        print(f"    Talk: {title[:50]}...")
                        if p_file:
                            print(f"      Presentation: {p_file}")
                        if a_file:
                            print(f"      Abstract: {a_file}")
                            
        # Check posters
        if 'posters' in ws:
            print(f"\nPosters count: {len(ws['posters'])}")
            for poster in ws['posters'][:5]:
                print(f"    Poster: {poster.get('title', '')[:50]}")
                print(f"      Abstract: {poster.get('abstract_file')}")
