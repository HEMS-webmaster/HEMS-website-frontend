import os
import json
import re
import difflib
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

proceedings_dir = r"docs/archives_translation/proceedings/3rd"
master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"

# Running Header / Footer Callback
def draw_header_footer(canvas, doc):
    canvas.saveState()
    
    # Running Header Text
    canvas.setFont('Helvetica-Oblique', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 748, '3rd Harsh-Environment Mass Spectrometry Workshop (2002)')
    
    # Running Header Bar (3pt height)
    canvas.setFillColor(colors.HexColor('#1f3a56'))
    canvas.rect(54, 738, 504, 3, fill=True, stroke=False)
    
    # Running Footer Left
    canvas.setFont('Helvetica', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 32, 'https://www.hems-workshop.org')
    
    # Running Footer Right
    canvas.drawRightString(558, 32, 'Presented Talk Abstract')
    
    canvas.restoreState()

# Markdown Abstract Parser
def parse_markdown_abstracts(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    entries = content.split('\n---\n')
    parsed = []
    
    for entry in entries:
        if not entry.strip() or not entry.strip().startswith('##'):
            continue
            
        lines = entry.strip().split('\n')
        title_line = lines[0].strip()
        title = title_line.split('.', 1)[1].strip()
        
        authors_text = ""
        institute_text = ""
        authors_institutes_list = []
        
        abstract_idx = -1
        for idx, line in enumerate(lines):
            if line.strip().startswith('**Abstract**:'):
                abstract_idx = idx
                break
                
        if abstract_idx == -1:
            continue
            
        meta_lines = lines[1:abstract_idx]
        meta_content = "\n".join(meta_lines).strip()
        
        if "**Authors & Institutes**:" in meta_content:
            for line in meta_lines:
                line_strip = line.strip()
                if line_strip.startswith('- ') or line_strip.startswith('• '):
                    authors_institutes_list.append(line_strip[2:].strip())
        else:
            for line in meta_lines:
                if line.startswith('**Authors**:'):
                    authors_text = line.split('**Authors**:', 1)[1].strip().strip(';').strip(',')
                elif line.startswith('**Institute**:'):
                    institute_text = line.split('**Institute**:', 1)[1].strip()
        
        body_lines = []
        for line in lines[abstract_idx+1:]:
            line_strip = line.strip()
            if line_strip:
                body_lines.append(line_strip)
        body = "\n\n".join(body_lines)
        
        parsed.append({
            'title': title,
            'authors_text': authors_text,
            'institute_text': institute_text,
            'authors_institutes_list': authors_institutes_list,
            'body': body
        })
        
    return parsed

# PDF Compiler
def generate_pdf(abstract_data, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=72,
        bottomMargin=54
    )
    
    styles = getSampleStyleSheet()
    
    workshop_style = ParagraphStyle(
        'WorkshopStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        textColor=colors.HexColor('#b38f4d'),
        spaceAfter=8,
        leading=11
    )
    
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=13.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=12,
        leading=15
    )
    
    authors_style = ParagraphStyle(
        'AuthorsStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=4,
        leading=12
    )
    
    institute_style = ParagraphStyle(
        'InstituteStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        textColor=colors.HexColor('#7f8c8d'),
        spaceAfter=15,
        leading=11
    )
    
    abstract_header_style = ParagraphStyle(
        'AbstractHeaderStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=8,
        leading=12
    )
    
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=10,
        leading=13.5
    )
    
    divider = Table([['']], colWidths=[504], rowHeights=[1])
    divider.setStyle(TableStyle([
        ('LINEABOVE', (0,0), (-1,-1), 0.75, colors.HexColor('#e2e8f0')),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
    ]))
    
    story = []
    
    story.append(Paragraph("3RD HARSH-ENVIRONMENT MASS SPECTROMETRY WORKSHOP", workshop_style))
    story.append(Paragraph(abstract_data['title'], title_style))
    story.append(divider)
    story.append(Spacer(1, 10))
    
    if abstract_data['authors_institutes_list']:
        story.append(Paragraph("Authors & Institutes:", authors_style))
        for line in abstract_data['authors_institutes_list']:
            if '(' in line and line.endswith(')'):
                auth_part, inst_part = line.rsplit('(', 1)
                auth_part = auth_part.strip()
                inst_part = inst_part.rstrip(')').strip()
                bullet_html = f"&bull; {auth_part} &mdash; <font fontName='Helvetica-Oblique'>{inst_part}</font>"
            else:
                bullet_html = f"&bull; {line}"
                
            bullet_style = ParagraphStyle(
                'BulletStyle',
                parent=styles['Normal'],
                fontName='Helvetica',
                fontSize=9.0,
                textColor=colors.HexColor('#2c3e50'),
                leftIndent=10,
                firstLineIndent=-10,
                spaceAfter=2,
                leading=11
            )
            story.append(Paragraph(bullet_html, bullet_style))
        story.append(Spacer(1, 10))
    else:
        authors_line = f"Authors: {abstract_data['authors_text']}"
        story.append(Paragraph(authors_line, authors_style))
        if abstract_data['institute_text']:
            inst_line = f"<font fontName='Helvetica-BoldOblique'>Institute</font>: {abstract_data['institute_text']}"
            story.append(Paragraph(inst_line, institute_style))
            
    story.append(Paragraph("ABSTRACT", abstract_header_style))
    
    body_paras = abstract_data['body'].split('\n\n')
    for p in body_paras:
        p_clean = p.strip()
        if p_clean:
            story.append(Paragraph(p_clean, body_style))
            
    doc.build(story, onFirstPage=draw_header_footer, onLaterPages=draw_header_footer)

def main():
    print("Parsing translated markdown files...")
    talk_abstracts = parse_markdown_abstracts('docs/archives_translation/3rdhemstalks.md')
    poster_abstracts = parse_markdown_abstracts('docs/archives_translation/3rdposter.md')
    
    all_source_abstracts = talk_abstracts + poster_abstracts
    print(f"Loaded {len(all_source_abstracts)} parsed source abstracts.")
    
    print("Loading database workshops...")
    with open(master_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        
    ws3 = None
    for ws in data:
        if ws.get('number') == 3:
            ws3 = ws
            break
            
    if not ws3:
        print("Error: 3rd workshop not found in master database.")
        return
        
    assigned_abstracts = []
    
    # 1. Collect all presentations
    for s in ws3.get('presentation_sessions', []):
        session_title = s.get('title', 'General')
        clean_session = re.sub(r'\s*\(.*?\)\s*', '', session_title).strip()
        clean_session = re.sub(r'[^a-zA-Z0-9]', '_', clean_session)
        for p in s.get('presentations', []):
            if p.get('abstract_file'):
                assigned_abstracts.append({
                    'title': p.get('title', ''),
                    'abstract_file': p['abstract_file'],
                    'subdir': clean_session
                })
                
    # 2. Collect posters
    for p in ws3.get('posters', []):
        if p.get('abstract_file'):
            assigned_abstracts.append({
                'title': p.get('title', ''),
                'abstract_file': p['abstract_file'],
                'subdir': 'Posters'
            })
            
    print(f"Found {len(assigned_abstracts)} assigned abstract files in workshop database.")
    
    processed_count = 0
    for item in assigned_abstracts:
        target_filename = item['abstract_file']
        target_title = item['title']
        target_subdir = item['subdir']
        
        # Match with parsed markdown abstracts using difflib
        best_match = None
        best_ratio = 0
        for sa in all_source_abstracts:
            ratio = difflib.SequenceMatcher(None, target_title.lower(), sa['title'].lower()).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = sa
                
        if best_ratio > 0.8:
            print(f"Matched ({best_ratio:.2f}): {target_filename} -> {best_match['title'][:50]}...")
            
            # Generate Premium PDF
            pdf_path = os.path.join(proceedings_dir, target_subdir, target_filename)
            generate_pdf(best_match, pdf_path)
            
            # Generate Preview Text (Clean: Title + Body up to 100 words, no authors/institutes)
            clean_title = best_match['title'].strip()
            clean_body = " ".join(best_match['body'].split())
            
            words = clean_body.split()
            if len(words) > 100:
                body_preview = " ".join(words[:100]) + "..."
            else:
                body_preview = " ".join(words)
                
            preview_text = f"{clean_title}\n\n{body_preview}"
            
            preview_path = pdf_path.replace('.pdf', '_preview.txt')
            with open(preview_path, 'w', encoding='utf-8') as pf:
                pf.write(preview_text)
                
            processed_count += 1
        else:
            print(f"Warning: Could not find good match for assigned file: {target_filename} (Title: {target_title}) - Best ratio was {best_ratio:.2f}")
            
    print(f"\nCompleted! Re-generated {processed_count} abstract PDFs and clean text preview files.")

if __name__ == '__main__':
    main()
