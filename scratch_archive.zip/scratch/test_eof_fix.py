import os
from PyPDF2 import PdfReader, PdfWriter

# Test reading/writing EOF-missing file with PyPDF2 by copying it page-by-page and recreating it
eof_pdf = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th\Technical_Session_II__Mass_Spectrometers_for_Underwater_Applications\3th_Kibelka_Underwater_Mass_Spectrometers_Presentation.pdf"

print("--- Testing alternative EOF-missing reader ---")
if os.path.exists(eof_pdf):
    # Let's see if we can read the file as bytes, append the missing EOF marker %%EOF if not present, and then open it!
    try:
        with open(eof_pdf, 'rb') as f:
            data = f.read()
        
        print(f"File size: {len(data)} bytes")
        print(f"Ends with: {data[-20:]}")
        
        # Check if %%EOF is present in the last 1024 bytes
        if b"%%EOF" not in data[-1024:]:
            print("%%EOF missing in last 1024 bytes! Let's append %%EOF\\r\\n and try parsing.")
            fixed_data = data + b"\r\n%%EOF\r\n"
            reader = PdfReader(bytes_io := __import__('io').BytesIO(fixed_data))
            print(f"Successfully parsed after appending %%EOF! Pages: {len(reader.pages)}")
            
            # Let's try writing
            writer = PdfWriter()
            for page in reader.pages:
                writer.add_page(page)
            writer.add_metadata({'/Title': 'Fixed EOF'})
            temp_out = eof_pdf + ".test_fixed_eof"
            with open(temp_out, "wb") as f:
                writer.write(f)
            print("Wrote successfully after appending EOF marker!")
            os.remove(temp_out)
        else:
            print("%%EOF is present in the last 1024 bytes but PyPDF2 failed.")
    except Exception as e:
        print(f"Failed to fix EOF: {e}")
else:
    print("Test EOF PDF does not exist!")
