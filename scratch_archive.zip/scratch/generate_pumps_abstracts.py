import os
import json
import re
from bs4 import BeautifulSoup
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

html_path = r"c:\Antigravity\HEMS-website\scratch\3rdpumpstalks.htm"
master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"
proceedings_dir = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3rd"

# Premium Running Header / Footer Callback
def draw_header_footer(canvas, doc):
    canvas.saveState()
    
    # Running Header Text
    canvas.setFont('Helvetica-Oblique', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 748, '3rd Harsh-Environment Mass Spectrometry Workshop (2002)')
    
    # Running Header Bar (3pt height)
    canvas.setFillColor(colors.HexColor('#1f3a56'))
    canvas.rect(54, 738, 504, 3, fill=True, stroke=False)
    
    # Running Footer Left
    canvas.setFont('Helvetica', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 32, 'https://www.hems-workshop.org')
    
    # Running Footer Right
    canvas.drawRightString(558, 32, 'Presented Talk Abstract')
    
    canvas.restoreState()

# PDF Compiler
def generate_pdf(abstract_data, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=72,
        bottomMargin=54
    )
    
    styles = getSampleStyleSheet()
    
    workshop_style = ParagraphStyle(
        'WorkshopStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        textColor=colors.HexColor('#b38f4d'),
        spaceAfter=8,
        leading=11
    )
    
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=13.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=12,
        leading=15
    )
    
    authors_header_style = ParagraphStyle(
        'AuthorsHeaderStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=4,
        leading=12
    )
    
    abstract_header_style = ParagraphStyle(
        'AbstractHeaderStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=8,
        leading=12
    )
    
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=10,
        leading=13.5
    )
    
    divider = Table([['']], colWidths=[504], rowHeights=[1])
    divider.setStyle(TableStyle([
        ('LINEABOVE', (0,0), (-1,-1), 0.75, colors.HexColor('#e2e8f0')),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
    ]))
    
    story = []
    
    story.append(Paragraph("3RD HARSH-ENVIRONMENT MASS SPECTROMETRY WORKSHOP", workshop_style))
    story.append(Paragraph(abstract_data['title'], title_style))
    story.append(divider)
    story.append(Spacer(1, 10))
    
    if abstract_data['authors_institutes_list']:
        story.append(Paragraph("Authors & Institutes:", authors_header_style))
        for line in abstract_data['authors_institutes_list']:
            if '(' in line and line.endswith(')'):
                auth_part, inst_part = line.rsplit('(', 1)
                auth_part = auth_part.strip()
                inst_part = inst_part.rstrip(')').strip()
                bullet_html = f"&bull; {auth_part} &mdash; <font fontName='Helvetica-Oblique'>{inst_part}</font>"
            else:
                bullet_html = f"&bull; {line}"
                
            bullet_style = ParagraphStyle(
                'BulletStyle',
                parent=styles['Normal'],
                fontName='Helvetica',
                fontSize=9.0,
                textColor=colors.HexColor('#2c3e50'),
                leftIndent=10,
                firstLineIndent=-10,
                spaceAfter=2,
                leading=11
            )
            story.append(Paragraph(bullet_html, bullet_style))
        story.append(Spacer(1, 10))
            
    story.append(Paragraph("ABSTRACT", abstract_header_style))
    
    body_paras = abstract_data['body'].split('\n\n')
    for p in body_paras:
        p_clean = p.strip()
        if p_clean:
            story.append(Paragraph(p_clean, body_style))
            
    doc.build(story, onFirstPage=draw_header_footer, onLaterPages=draw_header_footer)

def main():
    print("Loading 3rdpumpstalks.htm...")
    with open(html_path, 'r', encoding='utf-8') as f:
        soup = BeautifulSoup(f.read(), 'html.parser')
        
    blockquotes = soup.find_all('blockquote')
    print(f"Found {len(blockquotes)} abstracts in HTML.")
    
    abstracts_map = {}
    for bq in blockquotes:
        anchor = bq.find('a', attrs={'name': True})
        if not anchor:
            continue
        anchor_name = anchor['name'].strip()
        
        b_tag = bq.find('b')
        title = ""
        if b_tag:
            title = b_tag.get_text()
            title = re.sub(r'[\s\n\r]+', ' ', title).strip('"\'“”`‘’ ')
            title = title.replace('&quot;', '"').replace('&ldquo;', '"').replace('&rdquo;', '"')
            
        p_tags = bq.find_all('p')
        if not p_tags:
            continue
            
        body_parts = []
        for p in p_tags[1:]:
            p_text = p.get_text()
            # Strip program links
            for a_link in p.find_all('a'):
                if 'program' in a_link.get_text().lower():
                    a_link.decompose()
            p_text = p.get_text()
            p_clean = re.sub(r'[\s\n\r]+', ' ', p_text).strip()
            if p_clean and p_clean != "program" and not p_clean.startswith(">"):
                p_clean = p_clean.rstrip('> ').strip()
                if p_clean:
                    body_parts.append(p_clean)
                    
        body = "\n\n".join(body_parts)
        abstracts_map[anchor_name] = {
            'title': title,
            'body': body
        }
        
    print(f"Parsed {len(abstracts_map)} abstracts into memory map.")
    
    print("Loading master_workshops.json...")
    with open(master_path, 'r', encoding='utf-8') as f:
        master_data = json.load(f)
        
    ws3 = None
    for ws in master_data:
        if ws.get('number') == 3:
            ws3 = ws
            break
            
    if not ws3:
        print("Error: 3rd workshop not found in master database.")
        return
        
    target_sessions = [
        "Technical Session I: Miniaturization / Technical Issues",
        "Technical Session II: Commercialization Issues"
    ]
    
    generated_count = 0
    
    for session in ws3.get('presentation_sessions', []):
        session_title = session.get('title', '')
        if session_title not in target_sessions:
            continue
            
        print(f"\nProcessing Session: {session_title}")
        clean_session = re.sub(r'\s*\(.*?\)\s*', '', session_title).strip()
        clean_session = re.sub(r'[^a-zA-Z0-9]', '_', clean_session)
        
        for p in session.get('presentations', []):
            legacy_url = p.get('legacy_abstract_url', '')
            if not legacy_url or '#' not in legacy_url:
                continue
                
            anchor_name = legacy_url.split('#')[-1].strip()
            if anchor_name not in abstracts_map:
                print(f"Warning: Anchor '{anchor_name}' not found in HTML abstracts mapping!")
                continue
                
            abstract_html_data = abstracts_map[anchor_name]
            
            # Map presenter last name
            presenter_name = p.get('presenter', '')
            presenter_last = presenter_name.split()[-1] if presenter_name else "Unknown"
            
            # Map title words
            title_words = p.get('title', '').split()
            title_part = "_".join(title_words[:4])
            title_part = re.sub(r'[^a-zA-Z0-9_]', '', title_part)
            
            # Standard filename
            abstract_filename = f"3rd_{presenter_last}_{title_part}_Abstract.pdf"
            p['abstract_file'] = abstract_filename
            print(f"  Assigned: {abstract_filename} for presentation: {p['title'][:50]}...")
            
            # Prepare authors_institutes_list
            authors_institutes_list = []
            for auth in p.get('authors', []):
                name = auth.get('name', '')
                inst = auth.get('institute', '')
                if inst:
                    authors_institutes_list.append(f"{name} ({inst})")
                else:
                    authors_institutes_list.append(name)
                    
            abstract_data = {
                'title': p['title'],
                'authors_institutes_list': authors_institutes_list,
                'body': abstract_html_data['body']
            }
            
            # Save paths
            pdf_path = os.path.join(proceedings_dir, clean_session, abstract_filename)
            
            # Generate Premium PDF
            print(f"    Generating PDF: {pdf_path}")
            generate_pdf(abstract_data, pdf_path)
            
            # Generate Preview Text (Clean: Title + Body up to 100 words, no authors/institutes)
            clean_title = p['title'].strip()
            clean_body = " ".join(abstract_html_data['body'].split())
            words = clean_body.split()
            if len(words) > 100:
                body_preview = " ".join(words[:100]) + "..."
            else:
                body_preview = " ".join(words)
                
            preview_text = f"{clean_title}\n\n{body_preview}"
            
            preview_path = pdf_path.replace('.pdf', '_preview.txt')
            print(f"    Generating Preview: {preview_path}")
            with open(preview_path, 'w', encoding='utf-8') as pf:
                pf.write(preview_text)
                
            generated_count += 1
            
    # Save master_workshops.json
    print("\nSaving updated master_workshops.json...")
    with open(master_path, 'w', encoding='utf-8') as f:
        json.dump(master_data, f, indent=2)
        
    print(f"\nSuccess! Successfully assigned and generated {generated_count} abstract PDFs and previews.")

if __name__ == '__main__':
    main()
