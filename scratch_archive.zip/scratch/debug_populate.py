summary_file = 'source-material/Old site docs/02thWorkshopSummary.md'

with open(summary_file, 'r', encoding='utf-8') as f:
    lines = f.readlines()

current_section = None
empty_abstract_rows = []

for i, line in enumerate(lines):
    if line.startswith('## 5. Oral Presentation Sessions'):
        current_section = 'oral'
    elif line.startswith('## 6. Poster Presentations'):
        current_section = 'poster'
    elif line.startswith('## '):
        current_section = None

    if current_section in ['oral', 'poster'] and line.strip().startswith('|') and line.strip().endswith('|'):
        if not ':---' in line and not '| # |' in line and not 'Start Time' in line:
            parts = line.split('|')
            if current_section == 'poster' and len(parts) >= 7:
                abstract_val = parts[6].strip()
                if not abstract_val:
                    empty_abstract_rows.append((i+1, 'poster', parts[2].strip()))
            elif current_section == 'oral' and len(parts) >= 8:
                abstract_val = parts[7].strip()
                if not abstract_val:
                    empty_abstract_rows.append((i+1, 'oral', parts[3].strip()))

if empty_abstract_rows:
    print("Found empty abstract fields:")
    for line_num, sec, title in empty_abstract_rows:
        print(f"Line {line_num} ({sec}): {title}")
else:
    print("All oral and poster presentation rows have abstract URLs filled!")
