import fitz
import os

pdf_path = 'docs/archives_translation/proceedings/15th/Administrative/15th_Participant_List.pdf'
if not os.path.exists(pdf_path):
    print("Error: PDF path does not exist.")
    exit(1)

doc = fitz.open(pdf_path)
text = ""
for page in doc:
    text += page.get_text("text")

with open('scratch/15th_participants_extracted.txt', 'w', encoding='utf-8') as f:
    f.write(text)

print("Successfully extracted participant list. Length of text:", len(text))

# Let's search for some keywords
keywords = ["student", "award", "winner", "prize", "sponsor", "host"]
for kw in keywords:
    count = text.lower().count(kw)
    print(f"Keyword '{kw}': {count} occurrences")
