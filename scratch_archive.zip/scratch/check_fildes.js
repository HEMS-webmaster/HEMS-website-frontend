const fs = require('fs');
const path = require('path');

const indexJsonPath = path.join(__dirname, '..', 'src', 'frontend', 'public', 'archives-index.json');
const index = JSON.parse(fs.readFileSync(indexJsonPath, 'utf8'));

const fildes = index.find(item => item.title.toLowerCase().includes('fildes') || item.authors.some(a => a.toLowerCase().includes('fildes')));
console.log('Fildes in archives-index.json:', fildes);

const gonin = index.find(item => item.title.toLowerCase().includes('gonin') || item.authors.some(a => a.toLowerCase().includes('gonin')));
console.log('Gonin in archives-index.json:', gonin);

const wiley = index.find(item => item.title.toLowerCase().includes('wiley') || item.authors.some(a => a.toLowerCase().includes('wiley')));
console.log('Wiley in archives-index.json:', wiley);

console.log('Total items in index:', index.length);
