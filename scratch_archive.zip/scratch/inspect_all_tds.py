import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
with open('scratch/tds_output.txt', 'w', encoding='utf-8') as f:
    for i in range(5, 29):
        if i >= len(tds):
            break
        td = tds[i]
        f.write(f"\n=======================================================\n")
        f.write(f"TD INDEX: {i}\n")
        f.write(f"=======================================================\n")
        p_tags = td.find_all('p')
        for j, p in enumerate(p_tags):
            f.write(f"--- Paragraph {j} ---\n")
            f.write(str(p) + "\n")
            f.write("Text: " + p.get_text().strip() + "\n")
print("Successfully wrote to scratch/tds_output.txt")
