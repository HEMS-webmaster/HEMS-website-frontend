import json
import urllib.request
import fitz
import re

# Load master workshops
with open('src/frontend/src/data/master_workshops.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

ws6 = next(w for w in data if w['number'] == 6)

def extract_authors(url):
    print(f"Fetching {url}...")
    full_url = f"https://www.hems-workshop.org/6thWS/{url}"
    try:
        req = urllib.request.Request(full_url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req)
        pdf_bytes = response.read()
        doc = fitz.open(stream=pdf_bytes, filetype='pdf')
        blocks = doc[0].get_text('blocks')
        text_blocks = [b[4].strip() for b in blocks if b[6] == 0 and b[4].strip()]
        
        if len(text_blocks) >= 3:
            content = text_blocks[2]
            content = content.replace('\n \n', '\n\n')
            paras = [p.strip() for p in re.split(r'\n\s*\n', content) if p.strip()]
            
            if len(paras) > 1:
                # Typically: paras[0] = Title, paras[1] = Authors, paras[2] = Institutes
                author_str = paras[1].replace('\n', ' ')
                
                # Clean up numbers (superscripts)
                author_str = re.sub(r'\d+', '', author_str)
                # Split by comma or "and"
                authors = [a.strip() for a in re.split(r',|\band\b', author_str) if a.strip()]
                return authors
    except Exception as e:
        print(f"Error fetching {full_url}: {e}")
    return None

changed = 0

for session in ws6["presentation_sessions"]:
    for pres in session["presentations"]:
        if pres.get("legacy_abstract_url") and "UNKNOWN" not in pres["legacy_abstract_url"]:
            authors = extract_authors(pres["legacy_abstract_url"])
            if authors and len(authors) > 1: # Only update if we found multiple authors!
                print(f"Found authors for '{pres['title']}': {authors}")
                
                new_authors = []
                for name in authors:
                    # check if this is the presenter (already known)
                    is_pres = any(a['isPresenter'] and a['name'] in name for a in pres["authors"])
                    new_authors.append({
                        "name": name,
                        "isPresenter": is_pres,
                        "institute": pres["authors"][0]["institute"] if pres["authors"] else ""
                    })
                pres["authors"] = new_authors
                changed += 1

for poster in ws6["posters"]:
    if poster.get("legacy_abstract_url") and "UNKNOWN" not in poster["legacy_abstract_url"]:
        authors = extract_authors(poster["legacy_abstract_url"])
        if authors and len(authors) > 1:
            print(f"Found authors for poster '{poster['title']}': {authors}")
            
            new_authors = []
            for name in authors:
                is_pres = any(a['isPresenter'] and a['name'] in name for a in poster["authors"])
                new_authors.append({
                    "name": name,
                    "isPresenter": is_pres,
                    "institute": poster["authors"][0]["institute"] if poster["authors"] else ""
                })
            poster["authors"] = new_authors
            changed += 1

if changed > 0:
    with open('src/frontend/src/data/master_workshops.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"Successfully updated {changed} presentations/posters with full author lists!")
else:
    print("No updates made.")
