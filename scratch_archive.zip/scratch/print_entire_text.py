import os
from bs4 import BeautifulSoup

path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th\General\3th_Adams_KSC_Miniature_Rugged_Abstract.pdf"

if os.path.exists(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        html = f.read()
    
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text()
    clean_text = "\n".join(line.strip() for line in text.split("\n") if line.strip())
    print("=== Entire Clean Text ===")
    print(clean_text)
else:
    print("File not found!")
