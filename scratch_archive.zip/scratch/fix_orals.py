import json
import re

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'

with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Hardcoded session dates since they got lost
session_dates = {
    "Technical Session: Field MS Systems": "2003-10-08",
    "Technical Session: Underwater MS": "2003-10-08",
    "Technical Session: Cylindrical Ion Traps": "2003-10-09",
    "Technical Session: MS and Source Design": "2003-10-09",
    "Technical Session: New & Enabling Technologies": "2003-10-10"
}

def clean_text(text):
    if not text:
        return ""
    text = text.replace('\n', ' ').replace('\r', ' ')
    return re.sub(r'\s+', ' ', text).strip()

def clean_author(name):
    name = clean_text(name)
    # Remove things like (1), (2), 1, 2 at the end of the name
    name = re.sub(r'\(\d+\)', '', name)
    name = re.sub(r'\d+$', '', name)
    return name.strip(' .,')

for workshop in data:
    if workshop.get('number') == 4:
        for session in workshop.get('presentation_sessions', []):
            title = session.get('title', '')
            # Match base title to give date
            base_title = title.split('(')[0].strip()
            date_to_use = session_dates.get(base_title, None)
            
            # If the session didn't have a date (null), set it
            if not session.get('date') and date_to_use:
                session['date'] = date_to_use
                
            for pres in session.get('presentations', []):
                # Apply date to presentation as well
                if not pres.get('date') and date_to_use:
                    pres['date'] = date_to_use
                
                pres['title'] = clean_text(pres.get('title', ''))
                
                new_authors = []
                new_institutes = []
                
                for author in pres.get('authors', []):
                    name = clean_author(author['name'])
                    if 'Institute' in name or 'University' in name or 'Laboratory' in name or 'Corp' in name or 'Inc' in name or 'Center' in name:
                        if name not in new_institutes:
                            new_institutes.append(name)
                    elif name:
                        new_authors.append({
                            "name": name,
                            "isPresenter": author.get('isPresenter', False)
                        })
                
                # Make sure the first author is presenter if none are
                if new_authors and not any(a['isPresenter'] for a in new_authors):
                    new_authors[0]['isPresenter'] = True
                    
                pres['authors'] = new_authors
                
                # Process institutes
                existing_insts = pres.get('institutes', [])
                for inst in existing_insts:
                    inst = clean_text(inst)
                    # Split by (1), (2) etc.
                    parts = re.split(r'\(\d+\)', inst)
                    for p in parts:
                        p = p.strip(' ,.')
                        if p and p not in new_institutes:
                            new_institutes.append(p)
                
                pres['institutes'] = new_institutes

        break

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Fixed authors, institutes, and dates for 2003 workshop.")
