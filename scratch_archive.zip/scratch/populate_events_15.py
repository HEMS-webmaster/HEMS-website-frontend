import json
import os

master_path = 'src/frontend/src/data/master_workshops.json'

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

events_15 = [
  {
    "date": "2025-09-15",
    "title": "Travel Day",
    "events": [
      {
        "time": "18:00",
        "end_time": "20:00",
        "title": "Registration - Meet & Greet",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Sheraton Virginia Beach Oceanfront - Ocean Grand Hallway & Foyer",
        "location_url": ""
      }
    ]
  },
  {
    "date": "2025-09-16",
    "title": "HEMS Workshop",
    "events": [
      {
        "time": "07:30",
        "title": "Registration",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Hallway",
        "location_url": ""
      },
      {
        "time": "07:30",
        "title": "Corporate Sponsor Set-up",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Henry",
        "location_url": ""
      },
      {
        "time": "08:00",
        "end_time": "09:30",
        "title": "Continental Breakfast",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "09:45",
        "end_time": "10:00",
        "title": "Welcoming by Dave Vincett",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "10:00",
        "end_time": "12:00",
        "title": "Technical Session I",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "12:00",
        "title": "Lunch",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "13:30",
        "end_time": "14:00",
        "title": "Sponsor Introductions",
        "subtitle": "BaySpec, MassTech, Teledyne FLIR & Pfeiffer",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "14:00",
        "end_time": "15:00",
        "title": "Technical Session II",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "15:00",
        "end_time": "15:30",
        "title": "Afternoon Break",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "15:30",
        "end_time": "16:30",
        "title": "Technical Session III",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "16:30",
        "title": "Dinner (on your own)",
        "subtitle": "",
        "subtitle_url": "",
        "location": "",
        "location_url": ""
      }
    ]
  },
  {
    "date": "2025-09-17",
    "title": "HEMS Workshop",
    "events": [
      {
        "time": "07:30",
        "end_time": "08:30",
        "title": "Continental Breakfast",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "08:30",
        "end_time": "10:00",
        "title": "Technical Session IV",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "10:00",
        "end_time": "10:30",
        "title": "Mid-Morning Break",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "10:30",
        "end_time": "11:30",
        "title": "Technical Session V",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "11:30",
        "title": "Lunch (on your own)",
        "subtitle": "",
        "subtitle_url": "",
        "location": "",
        "location_url": ""
      },
      {
        "time": "13:30",
        "end_time": "14:30",
        "title": "Technical Sessions VI",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "14:30",
        "end_time": "15:00",
        "title": "Afternoon Break",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Grand Ocean Foyer",
        "location_url": ""
      },
      {
        "time": "15:00",
        "end_time": "16:00",
        "title": "Technical Sessions VII",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "18:30",
        "end_time": "21:30",
        "title": "Workshop Dinner",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      }
    ]
  },
  {
    "date": "2025-09-18",
    "title": "HEMS Workshop",
    "events": [
      {
        "time": "07:30",
        "end_time": "08:30",
        "title": "Continental Breakfast",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "08:30",
        "end_time": "10:00",
        "title": "Technical Session VIII",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "10:00",
        "end_time": "10:30",
        "title": "Mid-Morning Break",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Foyer",
        "location_url": ""
      },
      {
        "time": "10:30",
        "end_time": "12:00",
        "title": "Technical Session IX (labeled Technical Session IV)",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      },
      {
        "time": "12:00",
        "title": "Program Survey and Closing",
        "subtitle": "",
        "subtitle_url": "",
        "location": "Ocean Grand Ballroom - Cape Charles",
        "location_url": ""
      }
    ]
  }
]

found = False
for ws in data:
    if ws.get('number') == 15:
        ws['events'] = events_15
        found = True
        break

if found:
    with open(master_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print("Successfully populated itinerary events for HEMS Workshop 15 in master_workshops.json")
else:
    print("Error: HEMS Workshop 15 not found in master_workshops.json")
