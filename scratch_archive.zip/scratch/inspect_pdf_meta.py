from PyPDF2 import PdfReader
import os

pdf_path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\2th\Technical_Session_I\2th_Beauchamp_Mass_Spectrometers_for_Abstract.pdf"

if not os.path.exists(pdf_path):
    print("Error: test PDF not found!")
    exit(1)

reader = PdfReader(pdf_path)
meta = reader.metadata

print(f"Metadata type: {type(meta)}")
print("Metadata contents:")
if meta:
    for k, v in meta.items():
        print(f"  {k}: {repr(v)}")
else:
    print("  No metadata found.")
