const fs = require('fs');

const masterPath = './src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2005 = masterData.find(ws => ws.year === "2005");

if (ws2005 && ws2005.presentations) {
  const sessions = [];
  
  const grouped = {};
  ws2005.presentations.forEach(p => {
    const isPM = p.time.includes('p.m.') || p.time.startsWith('12:');
    const key = `${p.date}_${isPM ? 'PM' : 'AM'}`;
    if (!grouped[key]) {
      grouped[key] = {
        date: p.date,
        isPM: isPM,
        presentations: []
      };
    }
    delete p.session;
    grouped[key].presentations.push(p);
  });

  const keys = Object.keys(grouped).sort();
  keys.forEach(k => {
    const g = grouped[k];
    
    // Create a local date to get the weekday safely
    // 2005-09-21 was Wednesday
    const parts = g.date.split('-');
    const dateObj = new Date(parts[0], parts[1]-1, parts[2]);
    const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
    
    const sessionTitle = `Technical Session (${dayName} ${g.isPM ? 'PM' : 'AM'})`;
    
    sessions.push({
      date: g.date,
      title: sessionTitle,
      time: g.presentations[0].time,
      end_time: "",
      location: "SandDollar Rooftop Restaurant",
      presentations: g.presentations
    });
  });

  ws2005.sessions = sessions;
  delete ws2005.presentations;

  fs.writeFileSync(masterPath, JSON.stringify(masterData, null, 2));
  console.log("Updated 2005 sessions schema");
} else {
  console.log("No presentations array found or already grouped.");
}
