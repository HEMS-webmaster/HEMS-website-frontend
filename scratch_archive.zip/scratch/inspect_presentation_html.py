import os
from bs4 import BeautifulSoup

path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th\Technical_Session_I__Miniaturization___Technical_Issues\3th_Young_The_Knudsen_Compressor_Presentation.pdf"

if os.path.exists(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        html = f.read()
    
    soup = BeautifulSoup(html, 'html.parser')
    print("=== HTML Contents ===")
    print(soup.prettify()[:2000])
else:
    print("File not found!")
