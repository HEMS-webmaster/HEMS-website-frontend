import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
for i in [5, 6, 7]:
    print(f"=== TD INDEX {i} ===")
    p_tags = tds[i].find_all('p')
    print(f"Number of paragraphs: {len(p_tags)}")
    for j, p in enumerate(p_tags):
        print(f"  P {j} text: {' '.join(p.get_text().split())[:120]}")
