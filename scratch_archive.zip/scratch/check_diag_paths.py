import os
import sys

# Find correct path by matching registry entries
md_path = r"c:\Antigravity\HEMS-website\docs\design\pdf_seo_registry.md"

with open(md_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Searching for exact paths in registry...")
for line in lines:
    if "**Path**:" in line:
        path = line.split("`")[1]
        if "3th_Kibelka_Underwater" in path or "10th_Krause" in path:
            abs_p = os.path.join(r"c:\Antigravity\HEMS-website", path)
            print(f"Registry Path: {path} -> Exists: {os.path.exists(abs_p)}")
