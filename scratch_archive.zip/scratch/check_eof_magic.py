import os

# Let's inspect the binary data at the end of the EOF-missing file to see if it is a zipped file or corrupted
eof_pdf = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th\Technical_Session_II__Mass_Spectrometers_for_Underwater_Applications\3th_Kibelka_Underwater_Mass_Spectrometers_Presentation.pdf"

if os.path.exists(eof_pdf):
    with open(eof_pdf, 'rb') as f:
        data = f.read()
    print(f"Header: {data[:10]}")
    print(f"Trailer (last 100 bytes): {data[-100:]}")
    # Check if the header is '%PDF-'
    if data.startswith(b'%PDF-'):
        print("Valid PDF magic header found.")
    else:
        print("Invalid PDF header!")
