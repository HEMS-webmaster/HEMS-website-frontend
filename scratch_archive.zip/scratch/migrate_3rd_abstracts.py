import os
import json
import re
from bs4 import BeautifulSoup
import difflib

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

def get_abstracts_from_file(filepath):
    soup = BeautifulSoup(open(filepath, encoding='utf-8', errors='replace'), 'html.parser')
    abstracts = []
    
    current_abstract = None
    for p in soup.find_all('p'):
        b_tag = p.find('b')
        if b_tag and '"' in b_tag.text:
            if current_abstract:
                abstracts.append(current_abstract)
            
            title = b_tag.text.strip().replace('"', '').replace('\n', ' ').replace('\r', '')
            title = re.sub(r'\s+', ' ', title).strip()
            
            b_tag.extract()
            for a in p.find_all('a'):
                a.extract()
            
            authors_text = p.text.replace('\n', ' ').replace('\r', '')
            authors_text = re.sub(r'\s+', ' ', authors_text).strip()
            
            current_abstract = {
                'title': title,
                'authors_text': authors_text,
                'body': []
            }
        elif current_abstract:
            text = p.text.replace('\n', ' ').replace('\r', '')
            text = re.sub(r'\s+', ' ', text).strip()
            if text:
                if 'Back to 3rd HEMS Workshop' in text:
                    continue
                current_abstract['body'].append(text)
    
    if current_abstract:
        abstracts.append(current_abstract)
        
    return abstracts

def generate_pdf(abstract_data, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = SimpleDocTemplate(output_path, pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Create custom styles if needed
    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], spaceAfter=12)
    author_style = ParagraphStyle('AuthorStyle', parent=styles['Normal'], spaceAfter=12, fontName='Helvetica-Oblique')
    body_style = ParagraphStyle('BodyStyle', parent=styles['Normal'], spaceAfter=12)
    
    story = []
    
    story.append(Paragraph(abstract_data['title'], title_style))
    story.append(Paragraph(abstract_data['authors_text'], author_style))
    
    for p in abstract_data['body']:
        story.append(Paragraph(p, body_style))
        
    doc.build(story)

# Main
html_files = ['scratch/3rdhemstalks.htm', 'scratch/3rdposter.htm', 'scratch/3rdpumpstalks.htm']
all_abstracts = []
for f in html_files:
    all_abstracts.extend(get_abstracts_from_file(f))

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Find 4th workshop
ws4 = None
for w in data:
    if w.get('number') == 4:
        ws4 = w
        break

def get_clean_session(session_title):
    return re.sub(r'\s*\(.*?\)\s*', '', session_title).strip().replace(' ', '_').replace('&', '_')

def get_clean_session_regex(session_title):
    clean = re.sub(r'\s*\(.*?\)\s*', '', session_title).strip()
    return re.sub(r'[^a-zA-Z0-9]', '_', clean)

matched_count = 0

for session in ws4.get('presentation_sessions', []):
    session_title = session.get('title', 'General')
    clean_session = get_clean_session_regex(session_title)
    target_dir = os.path.join('c:/Antigravity/HEMS-website/docs/archives_translation/proceedings/4th', clean_session)
    
    for pIdx, pres in enumerate(session.get('presentations', [])):
        pres_title = pres.get('title', '')
        
        # Try to find a matching abstract from 3rd workshop
        # We use sequence matcher
        best_match = None
        best_ratio = 0
        
        for abs_data in all_abstracts:
            ratio = difflib.SequenceMatcher(None, pres_title.lower(), abs_data['title'].lower()).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = abs_data
                
        if best_ratio > 0.6:  # Reasonable threshold for titles
            matched_count += 1
            print(f"Match found! ({best_ratio:.2f})")
            print(f"  4th Pres: {pres_title[:60]}")
            print(f"  3rd Abs:  {best_match['title'][:60]}")
            
            # Build filename logic from PresentationsManager
            presenterName = f"Author_{pIdx}"
            if pres.get('authors') and len(pres['authors']) > 0:
                presenter = next((a for a in pres['authors'] if a.get('isPresenter')), pres['authors'][0])
                namePart = presenter['name'].split(',')[0].strip()
                nameWords = namePart.split(' ')
                presenterName = re.sub(r'[^a-zA-Z0-9]', '', nameWords[-1])
                
            titleSnippet = f"Talk_{pIdx}"
            words = [w for w in re.split(r'\s+', re.sub(r'[^a-zA-Z0-9\s]', '', pres_title)) if w]
            if words:
                titleSnippet = '_'.join(words[:3])
                
            absFileName = f"4th_{presenterName}_{titleSnippet}_Abstract.pdf"
            
            # Generate PDF
            pdf_path = os.path.join(target_dir, absFileName)
            generate_pdf(best_match, pdf_path)
            
            # Update json
            pres['abstract_file'] = absFileName
            pres['legacy_abstract_url'] = 'https://www.hems-workshop.org/3rdWS/3rdquicklinksalpha.html'
            
# Posters
target_dir_posters = os.path.join('c:/Antigravity/HEMS-website/docs/archives_translation/proceedings/4th', 'Posters')
for pIdx, pres in enumerate(ws4.get('posters', [])):
    pres_title = pres.get('title', '')
    
    best_match = None
    best_ratio = 0
    
    for abs_data in all_abstracts:
        ratio = difflib.SequenceMatcher(None, pres_title.lower(), abs_data['title'].lower()).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = abs_data
            
    if best_ratio > 0.6:
        matched_count += 1
        print(f"Match found for Poster! ({best_ratio:.2f})")
        print(f"  4th Pres: {pres_title[:60]}")
        print(f"  3rd Abs:  {best_match['title'][:60]}")
        
        presenterName = f"Author_{pIdx}"
        if pres.get('authors') and len(pres['authors']) > 0:
            presenter = next((a for a in pres['authors'] if a.get('isPresenter')), pres['authors'][0])
            namePart = presenter['name'].split(',')[0].strip()
            nameWords = namePart.split(' ')
            presenterName = re.sub(r'[^a-zA-Z0-9]', '', nameWords[-1])
            
        titleSnippet = f"Talk_{pIdx}"
        words = [w for w in re.split(r'\s+', re.sub(r'[^a-zA-Z0-9\s]', '', pres_title)) if w]
        if words:
            titleSnippet = '_'.join(words[:3])
            
        absFileName = f"4th_{presenterName}_{titleSnippet}_Abstract.pdf"
        
        pdf_path = os.path.join(target_dir_posters, absFileName)
        generate_pdf(best_match, pdf_path)
        
        pres['abstract_file'] = absFileName
        pres['legacy_abstract_url'] = 'https://www.hems-workshop.org/3rdWS/3rdquicklinksalpha.html'

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"Total matched and generated PDFs: {matched_count}")
