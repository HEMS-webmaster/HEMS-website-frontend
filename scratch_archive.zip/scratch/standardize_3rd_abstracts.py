import urllib.request
import re
from bs4 import BeautifulSoup

def parse_authors_institutes(raw_str):
    groups = []
    start_idx = -1
    stack = []
    last_end = 0
    
    for i, char in enumerate(raw_str):
        if char in '([':
            if not stack:
                start_idx = i
            stack.append(char)
        elif char in ')]':
            if stack:
                stack.pop()
                if not stack:
                    # Found a complete bracketed group
                    author_part = raw_str[last_end:start_idx].strip()
                    inst_part = raw_str[start_idx+1:i].strip()
                    groups.append((author_part, inst_part))
                    last_end = i + 1
                    
    # If there is any trailing author part or no brackets found at all
    if last_end < len(raw_str):
        remain = raw_str[last_end:].strip()
        if remain:
            remain = remain.strip(';').strip(',').strip()
            if remain:
                groups.append((remain, ""))
                
    # Now let's clean each group's author list and split them
    final_groups = []
    for authors_str, inst in groups:
        authors_str = authors_str.strip(';').strip(',').strip('.').strip()
        if not authors_str:
            continue
            
        authors_str_clean = authors_str.replace(" and ", ", ").replace(" & ", ", ")
        
        authors = [a.strip() for a in authors_str_clean.split(',')]
        authors = [a for a in authors if a]
        
        cleaned_authors = []
        for a in authors:
            if a.startswith("and "):
                a = a[4:].strip()
            if a:
                cleaned_authors.append(a)
                
        final_groups.append((cleaned_authors, inst))
        
    return final_groups

def clean_body_text(body_text):
    # Strip any trailing program link like "> program" or "program"
    body_text = ' '.join(body_text.split())
    # Match: optional leading > or &gt;, optional spaces, case-insensitive "program", optional trailing dots/spaces
    body_text = re.sub(r'\s*(?:[>&gt;]+\s*)?program\s*$', '', body_text, flags=re.IGNORECASE)
    return body_text.strip()

def main():
    url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
    print(f"Fetching from {url}...")
    html = urllib.request.urlopen(url).read().decode('latin-1')
    soup = BeautifulSoup(html, 'html.parser')
    
    tds = soup.find_all('td')
    # Abstracts are in tds[6:28]
    abstract_tds = tds[6:28]
    
    print(f"Found {len(abstract_tds)} abstracts to parse.")
    
    markdown_content = []
    markdown_content.append("# 3rd Harsh-Environment Mass Spectrometry Workshop - Presented Talks (Abstracts)")
    markdown_content.append(f"\n*Source: [{url}]({url})*\n")
    
    for idx, td in enumerate(abstract_tds):
        p_tags = td.find_all('p')
        if not p_tags:
            continue
            
        # 1. Parse Title
        p0 = p_tags[0]
        title_tag = p0.find(['b', 'strong'])
        title_str = ""
        if title_tag:
            title_str = ' '.join(title_tag.get_text().split()).strip()
        else:
            title_str = ' '.join(p0.get_text().split()).strip()
            
        title_str = title_str.strip('"').strip("'").strip('“').strip('”').strip()
        
        # 2. Parse Authors and Institutes
        authors_institutes_str = ""
        if title_tag:
            curr = title_tag.next_sibling
            while curr:
                authors_institutes_str += curr.get_text() if hasattr(curr, 'get_text') else str(curr)
                curr = curr.next_sibling
        else:
            authors_institutes_str = p0.get_text()
            
        authors_institutes_str = ' '.join(authors_institutes_str.split()).strip()
        parsed_groups = parse_authors_institutes(authors_institutes_str)
        
        # 3. Parse Body Paragraphs
        body_parts = []
        for p in p_tags[1:]:
            p_text = p.get_text().strip()
            if p_text:
                cleaned_p = clean_body_text(p_text)
                if cleaned_p:
                    body_parts.append(cleaned_p)
        body_str = "\n\n".join(body_parts)
        
        # Formulate Markdown entry
        markdown_content.append(f"\n---\n")
        markdown_content.append(f"## {idx+1}. {title_str}\n")
        
        # Add Authors & Institutes
        if len(parsed_groups) == 1:
            authors, inst = parsed_groups[0]
            authors_formatted = ", ".join(authors)
            markdown_content.append(f"**Authors**: {authors_formatted}  ")
            if inst:
                markdown_content.append(f"**Institute**: {inst}  ")
            markdown_content.append("") # empty line
        else:
            markdown_content.append("**Authors & Institutes**:")
            for authors, inst in parsed_groups:
                authors_formatted = ", ".join(authors)
                if inst:
                    markdown_content.append(f"- {authors_formatted} ({inst})")
                else:
                    markdown_content.append(f"- {authors_formatted}")
            markdown_content.append("") # empty line
            
        # Add Abstract Body
        markdown_content.append(f"**Abstract**:")
        markdown_content.append(body_str)
        markdown_content.append("")
        
    output_path = 'docs/archives_translation/3rdhemstalks.md'
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(markdown_content))
        
    print(f"Successfully wrote parsed abstracts to {output_path}")

if __name__ == '__main__':
    main()
