import json
import os

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for workshop in data:
    if workshop.get('number') == 4 or workshop.get('year') == '2003':
        workshop['city'] = 'St. Petersburg Beach, Florida'
        workshop['venue'] = 'University of South Florida, Marine Science Department, Center for Ocean Technology'
        workshop['sponsors'] = [
            {
                "company": "University of South Florida, Marine Science Department, Center for Ocean Technology",
                "isHost": True,
                "year": "2003"
            },
            {
                "company": "Detector Technologies, Inc.",
                "url": "http://www.detechinc.com/",
                "year": "2003"
            },
            {
                "company": "ENG Concepts",
                "year": "2003"
            },
            {
                "company": "Griffin Analytical Technologies",
                "url": "http://www.griffinanalytical.com/",
                "year": "2003"
            },
            {
                "company": "Ionwerks, Inc.",
                "url": "http://www.ionwerks.com/",
                "year": "2003"
            },
            {
                "company": "Monitor Instruments",
                "url": "http://www.monitorinstruments.com",
                "year": "2003"
            },
            {
                "company": "Siemens",
                "url": "http://www.sea.siemens.com/ia/product/aiquantra.html",
                "year": "2003"
            },
            {
                "company": "Standford Research Systems",
                "url": "http://www.thinksrs.com/",
                "year": "2003"
            },
            {
                "company": "Varian, Inc.",
                "url": "http://www.varianinc.com/cgi-bin/nav?/",
                "year": "2003"
            }
        ]

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Updated 2003 workshop data.")
