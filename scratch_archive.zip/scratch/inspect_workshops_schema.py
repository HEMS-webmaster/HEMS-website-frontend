import json

with open('src/frontend/src/data/master_workshops.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print(f"Total workshops: {len(data)}")
for i, ws in enumerate(data[:3]):
    print(f"\n--- Workshop {i+1} ---")
    for key, val in ws.items():
        if isinstance(val, list):
            print(f"  {key}: list of length {len(val)}")
            if len(val) > 0:
                print(f"    First item keys: {list(val[0].keys()) if isinstance(val[0], dict) else type(val[0])}")
        else:
            print(f"  {key}: {val}")
