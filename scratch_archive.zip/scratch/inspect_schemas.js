const fs = require('fs');
const path = require('path');

const masterPath = path.join(__dirname, '..', 'src', 'frontend', 'src', 'data', 'master_workshops.json');
const data = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

data.forEach(ws => {
  const keys = Object.keys(ws);
  console.log(`Year ${ws.year} (Ordinal ${ws.number}):`);
  console.log('  Top-level keys:', keys.filter(k => ['presentation_sessions', 'posters', 'schedule', 'program'].includes(k)));
  
  if (ws.presentation_sessions) {
    console.log('    Uses presentation_sessions directly');
  }
  if (ws.schedule) {
    console.log('    Uses schedule');
    if (ws.schedule.length > 0) {
      console.log('      Sample schedule item keys:', Object.keys(ws.schedule[0]));
      if (ws.schedule[0].items) {
        console.log('        Has schedule[].items');
      }
      if (ws.schedule[0].presentations) {
        console.log('        Has schedule[].presentations');
      }
    }
  }
});
