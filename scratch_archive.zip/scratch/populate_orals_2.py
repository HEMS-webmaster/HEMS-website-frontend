import json

master_file = 'src/frontend/src/data/master_workshops.json'

with open(master_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Define the presentation sessions for 2001 (2nd workshop)
presentation_sessions_2001 = [
  {
    "session_title": "Technical Session I",
    "title": "Technical Session I",
    "date": "2001-03-19",
    "location": "UNKNOWN",
    "presentations": [
      {
        "time": "9:00 AM",
        "end_time": "",
        "title": "Mass Spectrometers for In-Situ Planetary Exploration",
        "authors": [
          {
            "name": "Pat Beauchamp",
            "isPresenter": True,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          }
        ],
        "presenter": "Pat Beauchamp",
        "presenter_initials": "P. B.",
        "institutes": [
          "Jet Propulsion Laboratory, Pasadena, CA"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "9:30 AM",
        "end_time": "",
        "title": "A small multiple reflectron time-of-flight mass spectrometer (MR-TOF-MS) for in-situ investigations",
        "authors": [
          {
            "name": "A. Casares",
            "isPresenter": True,
            "institute": "Justus-Liebig University, Giessen, Germany"
          },
          {
            "name": "H. Wollnik",
            "isPresenter": False,
            "institute": "Justus-Liebig University, Giessen, Germany"
          },
          {
            "name": "F. Goesmann",
            "isPresenter": False,
            "institute": "Max-Planck Institute fuer Aeronomie (MPIE), Katlenburg-Lindau, Germany"
          },
          {
            "name": "A. Kholomeev",
            "isPresenter": False,
            "institute": "Justus-Liebig University, Giessen, Germany"
          },
          {
            "name": "R. Roll",
            "isPresenter": False,
            "institute": "Max-Planck Institute fuer Aeronomie (MPIE), Katlenburg-Lindau, Germany"
          },
          {
            "name": "H. Rosenbauer",
            "isPresenter": False,
            "institute": "Max-Planck Institute fuer Aeronomie (MPIE), Katlenburg-Lindau, Germany"
          }
        ],
        "presenter": "A. Casares",
        "presenter_initials": "A. C.",
        "institutes": [
          "Justus-Liebig University, Giessen, Germany",
          "Max-Planck Institute fuer Aeronomie (MPIE), Katlenburg-Lindau, Germany"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "10:30 AM",
        "end_time": "",
        "title": "In-situ Laser TOF MS on Planets and Small Bodies",
        "authors": [
          {
            "name": "Will Brinckerhoff",
            "isPresenter": True,
            "institute": "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
          }
        ],
        "presenter": "Will Brinckerhoff",
        "presenter_initials": "W. B.",
        "institutes": [
          "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "11:00 AM",
        "end_time": "",
        "title": "A Fully Redundant On-Line Mass Spectrometric System for the Space Shuttle Used to Monitor Cyogenic Fuel Leaks",
        "authors": [
          {
            "name": "T. P. Griffin",
            "isPresenter": True,
            "institute": "NASA Kennedy Space Center, FL"
          },
          {
            "name": "G. R. Naylor",
            "isPresenter": False,
            "institute": "Dynacs Inc., Kennedy Space Center, FL"
          },
          {
            "name": "W. D. Haskell",
            "isPresenter": False,
            "institute": "Dynacs Inc., Kennedy Space Center, FL"
          },
          {
            "name": "G. S. Breznik",
            "isPresenter": False,
            "institute": "NASA Kennedy Space Center, FL"
          },
          {
            "name": "C. A. Mizell",
            "isPresenter": False,
            "institute": "NASA Kennedy Space Center, FL"
          }
        ],
        "presenter": "T. P. Griffin",
        "presenter_initials": "T. G.",
        "institutes": [
          "NASA Kennedy Space Center, FL",
          "Dynacs Inc., Kennedy Space Center, FL"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      }
    ]
  },
  {
    "session_title": "Technical Session II",
    "title": "Technical Session II",
    "date": "2001-03-19",
    "location": "UNKNOWN",
    "presentations": [
      {
        "time": "1:30 PM",
        "end_time": "",
        "title": "A Miniaturized Cylindrical lon Trap Mass Spectrometer",
        "authors": [
          {
            "name": "Garth E. Patterson",
            "isPresenter": True,
            "institute": "Purdue University, West Lafayette, IN"
          },
          {
            "name": "R. Graham Cooks",
            "isPresenter": False,
            "institute": "Purdue University, West Lafayette, IN"
          }
        ],
        "presenter": "Garth E. Patterson",
        "presenter_initials": "G. P.",
        "institutes": [
          "Purdue University, West Lafayette, IN"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "2:00 PM",
        "end_time": "",
        "title": "Recent Developments in Micro lon Trap Mass Spectrometry",
        "authors": [
          {
            "name": "Jeremy Moxom",
            "isPresenter": True,
            "institute": "Oak Ridge National Laboratory, Oak Ridge, TN"
          },
          {
            "name": "William B. Whitten",
            "isPresenter": False,
            "institute": "Oak Ridge National Laboratory, Oak Ridge, TN"
          },
          {
            "name": "Peter T. A. Reilly",
            "isPresenter": False,
            "institute": "Oak Ridge National Laboratory, Oak Ridge, TN"
          },
          {
            "name": "J. Michael Ramsey",
            "isPresenter": False,
            "institute": "Oak Ridge National Laboratory, Oak Ridge, TN"
          }
        ],
        "presenter": "Jeremy Moxom",
        "presenter_initials": "J. M.",
        "institutes": [
          "Oak Ridge National Laboratory, Oak Ridge, TN"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "2:30 PM",
        "end_time": "",
        "title": "Miniature TOF Mass Spectrometer using a Flexible Circuitboard Reflectron",
        "authors": [
          {
            "name": "Tim Cornish",
            "isPresenter": True,
            "institute": "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
          }
        ],
        "presenter": "Tim Cornish",
        "presenter_initials": "T. C.",
        "institutes": [
          "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      }
    ]
  },
  {
    "session_title": "Technical Session III",
    "title": "Technical Session III",
    "date": "2001-03-20",
    "location": "UNKNOWN",
    "presentations": [
      {
        "time": "9:30 AM",
        "end_time": "",
        "title": "Disaster Management Using Mobile Mass Spectrometers",
        "authors": [
          {
            "name": "Gerhard Matz",
            "isPresenter": True,
            "institute": "Technical University of Hamburg-Harburg, Hamburg, Germany"
          }
        ],
        "presenter": "Gerhard Matz",
        "presenter_initials": "G. M.",
        "institutes": [
          "Technical University of Hamburg-Harburg, Hamburg, Germany"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "10:00 AM",
        "end_time": "",
        "title": "Direct Sampling Mass Spectrometry in Atmospheric Chemistry",
        "authors": [
          {
            "name": "Dennis Barket, Jr.",
            "isPresenter": True,
            "institute": "Purdue University, West Lafayette, IN"
          },
          {
            "name": "Julia Hurst",
            "isPresenter": False,
            "institute": "Purdue University, West Lafayette, IN"
          },
          {
            "name": "Amanda Grannas",
            "isPresenter": False,
            "institute": "Purdue University, West Lafayette, IN"
          },
          {
            "name": "Christophe Guimbaud",
            "isPresenter": False,
            "institute": "Purdue University, West Lafayette, IN"
          },
          {
            "name": "Paul Shepson",
            "isPresenter": False,
            "institute": "Purdue University, West Lafayette, IN"
          }
        ],
        "presenter": "Dennis Barket, Jr.",
        "presenter_initials": "D. B.",
        "institutes": [
          "Purdue University, West Lafayette, IN"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "10:30 AM",
        "end_time": "",
        "title": "MS for Trace Explosives Detection in Aviation Security",
        "authors": [
          {
            "name": "R. T. Chamberlain",
            "isPresenter": True,
            "institute": "FAA/Wm. J. Hughes Tech. Ctr., Atlantic City, NJ"
          },
          {
            "name": "Richard Lareau",
            "isPresenter": False,
            "institute": "FAA/Wm. J. Hughes Tech. Ctr., Atlantic City, NJ"
          },
          {
            "name": "Karl Hanold",
            "isPresenter": False,
            "institute": "Syagen Technology, Inc., Tustin, CA"
          },
          {
            "name": "Jack Syagen",
            "isPresenter": False,
            "institute": "Syagen Technology, Inc., Tustin, CA"
          },
          {
            "name": "Kevin Linker",
            "isPresenter": False,
            "institute": "Sandia National Laboratory, Albuquerque, NM"
          },
          {
            "name": "Chuck Rhykerd",
            "isPresenter": False,
            "institute": "Sandia National Laboratory, Albuquerque, NM"
          },
          {
            "name": "Frank Bouchier",
            "isPresenter": False,
            "institute": "Sandia National Laboratory, Albuquerque, NM"
          }
        ],
        "presenter": "R. T. Chamberlain",
        "presenter_initials": "R. C.",
        "institutes": [
          "FAA/Wm. J. Hughes Tech. Ctr., Atlantic City, NJ",
          "Syagen Technology, Inc., Tustin, CA",
          "Sandia National Laboratory, Albuquerque, NM"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "11:00 AM",
        "end_time": "",
        "title": "Volcanic Monitoring using Field-Portable Mass Spectrometers: Towards On-Site and Real Time Gas Analysis at Fumaroles",
        "authors": [
          {
            "name": "Jorge A. Diaz",
            "isPresenter": True,
            "institute": "Universidad de Costa Rica"
          }
        ],
        "presenter": "Jorge A. Diaz",
        "presenter_initials": "J. D.",
        "institutes": [
          "Universidad de Costa Rica"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      }
    ]
  },
  {
    "session_title": "Technical Session IV",
    "title": "Technical Session IV",
    "date": "2001-03-20",
    "location": "UNKNOWN",
    "presentations": [
      {
        "time": "2:00 PM",
        "end_time": "",
        "title": "Project NEREUS: Concepts and principles for in-situ MS",
        "authors": [
          {
            "name": "H. F. Hemond",
            "isPresenter": True,
            "institute": "Massachusetts Institute of Technology, Cambridge, MA"
          },
          {
            "name": "R. Camilli",
            "isPresenter": False,
            "institute": "Massachusetts Institute of Technology, Cambridge, MA"
          }
        ],
        "presenter": "H. F. Hemond",
        "presenter_initials": "H. H.",
        "institutes": [
          "Massachusetts Institute of Technology, Cambridge, MA"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "2:30 PM",
        "end_time": "",
        "title": "Development of an Underwater Mass Spectrometer for Dissolved Gases, Solutes, and Large Organic Compounds",
        "authors": [
          {
            "name": "Gary M. McMurtry",
            "isPresenter": True,
            "institute": "SOEST, University of Hawaii, Honolulu, Hawaii"
          },
          {
            "name": "Steven J. Smith",
            "isPresenter": False,
            "institute": "Jet Propulsion Laboratory/California Institute of Technology, Pasadena, CA"
          }
        ],
        "presenter": "Gary M. McMurtry",
        "presenter_initials": "G. M.",
        "institutes": [
          "SOEST, University of Hawaii, Honolulu, Hawaii",
          "Jet Propulsion Laboratory/California Institute of Technology, Pasadena, CA"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "3:30 PM",
        "end_time": "",
        "title": "Applications of in-water mass spectrometry for detection of volatile organic compounds and dissolved gases",
        "authors": [
          {
            "name": "R. T. Short",
            "isPresenter": True,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "D. P. Fries",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "G. Kibelka",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "M. L. Kerr",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "S. K. Toler",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "P. G. Wenner",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          },
          {
            "name": "R. H. Byrne",
            "isPresenter": False,
            "institute": "The University of South Florida, St. Petersburg, FL"
          }
        ],
        "presenter": "R. T. Short",
        "presenter_initials": "R. S.",
        "institutes": [
          "The University of South Florida, St. Petersburg, FL"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "4:00 PM",
        "end_time": "",
        "title": "Polymeric Membrane Chlorocarbon Permeabilities Determined by Membrane Introduction Mass Spectrometry (MIMS)",
        "authors": [
          {
            "name": "Mark L. Stone",
            "isPresenter": True,
            "institute": "Idaho National Engineering and Environmental Laboratory/Bechtel, Idaho Falls, ID"
          }
        ],
        "presenter": "Mark L. Stone",
        "presenter_initials": "M. S.",
        "institutes": [
          "Idaho National Engineering and Environmental Laboratory/Bechtel, Idaho Falls, ID"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "4:30 PM",
        "end_time": "",
        "title": "Solid phase microextraction as a method for sampling with analysis by gas chromatography/mass spectrometry in the field",
        "authors": [
          {
            "name": "LCDR Gary Hook",
            "isPresenter": True,
            "institute": "Uniformed Services University of the Health Sciences, Bethesda, MD"
          },
          {
            "name": "LCDR Phil Smith",
            "isPresenter": False,
            "institute": "Uniformed Services University of the Health Sciences, Bethesda, MD"
          },
          {
            "name": "Kenneth Williams",
            "isPresenter": False,
            "institute": "U.S. Army Center for Health Promotion and Preventive Medicine, Edgewood, MD"
          },
          {
            "name": "Michael Sheely",
            "isPresenter": False,
            "institute": "U.S. Army Center for Health Promotion and Preventive Medicine, Edgewood, MD"
          }
        ],
        "presenter": "LCDR Gary Hook",
        "presenter_initials": "G. H.",
        "institutes": [
          "Uniformed Services University of the Health Sciences, Bethesda, MD",
          "U.S. Army Center for Health Promotion and Preventive Medicine, Edgewood, MD"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      }
    ]
  },
  {
    "session_title": "Technical Session V",
    "title": "Technical Session V",
    "date": "2001-03-21",
    "location": "UNKNOWN",
    "presentations": [
      {
        "time": "8:30 AM",
        "end_time": "",
        "title": "Tiny Time-of-Flight (TOF) Mass Spectrometer for Biodetection",
        "authors": [
          {
            "name": "Wayne Bryden",
            "isPresenter": True,
            "institute": "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
          }
        ],
        "presenter": "Wayne Bryden",
        "presenter_initials": "W. B.",
        "institutes": [
          "Applied Physics Laboratory, The Johns Hopkins University, Laurel, MD"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "9:00 AM",
        "end_time": "",
        "title": "Biological applications on a miniaturized delayed extraction TOF mass spectrometer",
        "authors": [
          {
            "name": "M. C. Prieto",
            "isPresenter": True,
            "institute": "The Johns Hopkins University, Baltimore, MD"
          },
          {
            "name": "V. Kovtoun",
            "isPresenter": False,
            "institute": "The Johns Hopkins University, Baltimore, MD"
          },
          {
            "name": "R. J. Cotter",
            "isPresenter": False,
            "institute": "The Johns Hopkins University, Baltimore, MD"
          }
        ],
        "presenter": "M. C. Prieto",
        "presenter_initials": "M. P.",
        "institutes": [
          "The Johns Hopkins University, Baltimore, MD"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "10:00 AM",
        "end_time": "",
        "title": "The Portable Horiba-Kore Mass Spectrometer MS-200",
        "authors": [
          {
            "name": "Frank Nuber",
            "isPresenter": True,
            "institute": "Kore Technology Ltd., Cambridge, England"
          },
          {
            "name": "Dr. Steve Mullock",
            "isPresenter": False,
            "institute": "Kore Technology Ltd., Cambridge, England"
          },
          {
            "name": "Clive Corlett",
            "isPresenter": False,
            "institute": "Kore Technology Ltd., Cambridge, England"
          }
        ],
        "presenter": "Frank Nuber",
        "presenter_initials": "F. N.",
        "institutes": [
          "Kore Technology Ltd., Cambridge, England"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      },
      {
        "time": "10:30 AM",
        "end_time": "",
        "title": "Progress Toward Highly Miniaturized Vacuum Pumps",
        "authors": [
          {
            "name": "Dean Wiberg",
            "isPresenter": True,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          },
          {
            "name": "Beverly Eyre",
            "isPresenter": False,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          },
          {
            "name": "Kirill Shcheglov",
            "isPresenter": False,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          },
          {
            "name": "Victor White",
            "isPresenter": False,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          },
          {
            "name": "Vachik Garkanian",
            "isPresenter": False,
            "institute": "Jet Propulsion Laboratory, Pasadena, CA"
          }
        ],
        "presenter": "Dean Wiberg",
        "presenter_initials": "D. W.",
        "institutes": [
          "Jet Propulsion Laboratory, Pasadena, CA"
        ],
        "legacy_url": "",
        "legacy_abstract_url": ""
      }
    ]
  }
]

# Update the master_workshops.json entry for WS 2
updated = False
for ws in data:
    if str(ws.get('number')) == '2':
        ws['presentation_sessions'] = presentation_sessions_2001
        updated = True
        break

if updated:
    with open(master_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print("Successfully populated 2001 oral presentations in master_workshops.json.")
else:
    print("Workshop 2 not found!")
