from bs4 import BeautifulSoup
import re
import sys

with open('c:/Antigravity/HEMS-website/scratch/4thprogram.html', 'r', encoding='utf-8') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

current_date = None
events = []

for tag in soup.find_all(['h3', 'h4', 'strong', 'tr']):
    if tag.name in ['h3', 'h4']:
        text = tag.get_text(strip=True)
        if 'Tuesday' in text or 'Wednesday' in text or 'Thursday' in text or 'Friday' in text:
            current_date = text
            print(f"\n--- DATE: {current_date} ---")
    elif tag.name == 'tr':
        tds = tag.find_all('td')
        if len(tds) >= 2:
            time_str = tds[0].get_text(strip=True)
            content_td = tds[1]
            content_str = content_td.get_text(strip=True)
            
            # Check if it's an event (no author, short text, or bolded)
            # Presentations usually have links (<a> tags) or authors
            has_link = content_td.find('a') is not None
            is_bold = content_td.find('b') is not None or content_td.find('strong') is not None
            
            if time_str and not has_link:
                # likely an itinerary event
                print(f"[{time_str}] {content_str}")
