import json

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for ws in data:
    if ws.get('number') in [1, 2, 3, 11, 12, 13]:
        print(f"Number: {ws.get('number')} -> Title: {repr(ws.get('title'))} -> Tagline: {repr(ws.get('tagline'))}")
