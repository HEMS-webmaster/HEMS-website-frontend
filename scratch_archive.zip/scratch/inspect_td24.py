import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
td = tds[24]
p_tags = td.find_all('p')
print(f"TD INDEX 24 has {len(p_tags)} paragraphs:")
for idx, p in enumerate(p_tags):
    print(f"\n--- Paragraph {idx} ---")
    print(str(p))
