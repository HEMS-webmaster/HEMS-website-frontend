const fs = require('fs');

const masterPath = './src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2005 = masterData.find(ws => ws.year === "2005");

if (ws2005) {
  if (ws2005.presentation_sessions) {
    ws2005.presentation_sessions.forEach(session => {
      if (session.presentations) {
        session.presentations.forEach(p => {
          if (p.title) {
            p.title = p.title.replace(/["“”]/g, '').trim();
          }
        });
      }
    });
  }

  if (ws2005.posters) {
    ws2005.posters.forEach(p => {
      if (p.title) {
        p.title = p.title.replace(/["“”]/g, '').trim();
      }
    });
  }

  fs.writeFileSync(masterPath, JSON.stringify(masterData, null, 2));
  console.log("Stripped quotes from 2005 titles");
}
