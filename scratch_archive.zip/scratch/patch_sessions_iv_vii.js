// Patch sessions IV-VII of the 12th workshop with authors/institutes
const fs = require('fs');
const path = require('path');

const masterPath = path.join(__dirname, '..', 'src', 'frontend', 'src', 'data', 'master_workshops.json');
const raw = fs.readFileSync(masterPath, 'utf8').replace(/^\uFEFF/, '');
const workshops = JSON.parse(raw);

const ws12 = workshops.find(w => w.number === 12);
if (!ws12) { console.error('Workshop 12 not found'); process.exit(1); }

// Data extracted from the raw text for Sessions IV-VII
const sessionsData = {
  "Technical Session IV": [
    {
      title: "Rapid Identification of Drug Seizures by ASAP-MS on a Low-Cost, Deployable, Single Quadrupole Instrument",
      name: "Bryan McCullough",
      authors: [
        { name: "Bryan McCullough", isPresenter: true, institute: "National Measurement Laboratory, LGC" },
        { name: "Chris Hopley", isPresenter: false, institute: "National Measurement Laboratory, LGC" },
        { name: "David Douce", isPresenter: false, institute: "Waters Corporation" },
        { name: "Nicola Lumley", isPresenter: false, institute: "Waters Corporation" },
        { name: "Steve Bajic", isPresenter: false, institute: "Waters Corporation" },
        { name: "Kate Whyatt", isPresenter: false, institute: "Waters Corporation" }
      ],
      institutes: ["National Measurement Laboratory, LGC", "Waters Corporation"]
    },
    {
      title: "Mobile Mass Spectrometer Systems for Online Oil Emission and Oil Dilution Measurements in Combustion Engine Test Cells.",
      name: "Andreas Behn",
      authors: [
        { name: "Andreas Behn", isPresenter: true, institute: "Lubrisense GmbH" },
        { name: "Matthias Feindt", isPresenter: false, institute: "Lubrisense GmbH" },
        { name: "Sven Krause", isPresenter: false, institute: "Lubrisense GmbH" },
        { name: "Lars Schomann", isPresenter: false, institute: "Lubrisense GmbH" },
        { name: "Ann-Christin Preuss", isPresenter: false, institute: "Institute of Analytical Measurement Technology Hamburg" },
        { name: "Gerhard Matz", isPresenter: false, institute: "Institute of Analytical Measurement Technology Hamburg" }
      ],
      institutes: ["Lubrisense GmbH", "Institute of Analytical Measurement Technology Hamburg"]
    }
  ],
  "Technical Session V": [
    {
      title: "Two-dimensional mass spectrometry on benchtop and portable ion trap mass spectrometers",
      name: "Dalton Snyder",
      authors: [
        { name: "Dalton Snyder", isPresenter: true, institute: "Purdue University, Department of Chemistry" },
        { name: "Lucas Szalwinski", isPresenter: false, institute: "Purdue University, Department of Chemistry" },
        { name: "Ryan Hilger", isPresenter: false, institute: "Purdue University, Department of Chemistry" },
        { name: "Robert Schrader", isPresenter: false, institute: "Purdue University, Department of Chemistry" },
        { name: "Valentina Pirro", isPresenter: false, institute: "Purdue University, Department of Chemistry" },
        { name: "R. Graham Cooks", isPresenter: false, institute: "Purdue University, Department of Chemistry" },
        { name: "Zachary St. John", isPresenter: false, institute: "The College of New Jersey" },
        { name: "Desmond Kaplan", isPresenter: false, institute: "KapScience LLC" },
        { name: "Ryan Danell", isPresenter: false, institute: "Danell Consulting, Inc." },
        { name: "Veronica Pinnick", isPresenter: false, institute: "NASA Goddard Space Flight Center" },
        { name: "Paul Mahaffy", isPresenter: false, institute: "NASA Goddard Space Flight Center" },
        { name: "Mitch Wells", isPresenter: false, institute: "FLIR Systems, Inc." }
      ],
      institutes: [
        "Purdue University, Department of Chemistry",
        "The College of New Jersey",
        "KapScience LLC",
        "Danell Consulting, Inc.",
        "NASA Goddard Space Flight Center",
        "FLIR Systems, Inc."
      ]
    },
    {
      title: "Development of Micro-Time-Of-Flight Mass Spectrometer for in situ gas analysis",
      name: "Alexandre Sonnette",
      authors: [
        { name: "Alexandre Sonnette", isPresenter: true, institute: "CEA, DAM, DIF" },
        { name: "Frédéric Progent", isPresenter: false, institute: "CEA, DAM, DIF" },
        { name: "Jérôme Tupinier", isPresenter: false, institute: "CEA, DAM, DIF" },
        { name: "Pierre-Etienne Buthier", isPresenter: false, institute: "CEA, DAM, DIF" },
        { name: "Jean-Christophe Lictevout", isPresenter: false, institute: "CEA, DAM, DIF" },
        { name: "Sébastien Vigne", isPresenter: false, institute: "CEA, DAM, DIF" },
        { name: "Thomas Alava", isPresenter: false, institute: "CEA, LETI, MINATEC Campus" }
      ],
      institutes: ["CEA, DAM, DIF", "CEA, LETI, MINATEC Campus"]
    },
    {
      title: "Instrumentation for Lunar Volatile Analysis",
      name: "Janine Captain",
      authors: [
        { name: "Janine Captain", isPresenter: true, institute: "NASA Kennedy Space Center" }
      ],
      institutes: ["NASA Kennedy Space Center"]
    }
  ],
  "Technical Session VI": [
    {
      title: "Development of a robust Fourier-Transform ion trap for semiconductor manufacturing",
      name: "Valerie Derpmann",
      authors: [
        { name: "Valerie Derpmann", isPresenter: true, institute: "Carl Zeiss SMT GmbH" },
        { name: "Yessica Brachthäuser", isPresenter: false, institute: "Carl Zeiss SMT GmbH" },
        { name: "Rüdiger Reuter", isPresenter: false, institute: "Carl Zeiss SMT GmbH" },
        { name: "Michel Aliman", isPresenter: false, institute: "Carl Zeiss SMT GmbH" },
        { name: "Alexander Laue", isPresenter: false, institute: "Carl Zeiss SMT GmbH" },
        { name: "Hin Yiu Chung", isPresenter: false, institute: "Carl Zeiss SMT GmbH" }
      ],
      institutes: ["Carl Zeiss SMT GmbH"]
    },
    {
      title: "Reverse-gas stack modeling-coupled to fieldable mass spectrometry to locate chemical effluent streams for clandestine drug labs, explosives manufacturing, and chemical weapon deployment.",
      name: "Guido F. Verbeck",
      authors: [
        { name: "Guido F. Verbeck", isPresenter: true, institute: "University of North Texas" },
        { name: "Camila Anguiano Virgen", isPresenter: false, institute: "University of North Texas" },
        { name: "Kenneth C. Wright", isPresenter: false, institute: "INFICON Inc." },
        { name: "Jaime L. Winfield", isPresenter: false, institute: "INFICON Inc." },
        { name: "James D. Fox", isPresenter: false, institute: "INFICON Inc." }
      ],
      institutes: ["University of North Texas", "INFICON Inc."]
    },
    {
      title: "Evaluation of Portable Linear Ion Trap Mass Spectrometer Coupled to Paper Spray Ionization Source for the Detection of Chemical Warfare Agents",
      name: "Ethan M. McBride",
      authors: [
        { name: "Ethan M. McBride", isPresenter: true, institute: "Excet, Inc." },
        { name: "Phillip M. Mach", isPresenter: false, institute: "Excet, Inc." },
        { name: "Elizabeth S. Dhummakupt", isPresenter: false, institute: "Excet, Inc." },
        { name: "Trevor Glaros", isPresenter: false, institute: "Excet, Inc." },
        { name: "Daniel O. Carmany", isPresenter: false, institute: "Excet, Inc." },
        { name: "Paul S. Demond", isPresenter: false, institute: "Excet, Inc." },
        { name: "Gabrielle R. Boyd", isPresenter: false, institute: "Excet, Inc." }
      ],
      institutes: ["Excet, Inc."]
    }
  ],
  "Technical Session VII": [
    {
      title: "A Quadrupole Ion Trap for the Detection of Biomarkers at Icy Worlds",
      name: "Joshua Wiley",
      authors: [
        { name: "Joshua Wiley", isPresenter: true, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Anton Belousov", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Sarah Waller", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Dragan Nikolic", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Richard Kidd", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Stojan Madzunkov", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Morgan Cable", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" },
        { name: "Murray Darrach", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" }
      ],
      institutes: ["Jet Propulsion Laboratory, California Institute of Technology"]
    },
    {
      title: "Optimization of a drone based miniature mass spectrometer system (Drone-MS) for in situ gas plume measurements",
      name: "Jorge Andres Diaz",
      authors: [
        { name: "Jorge Andres Diaz", isPresenter: true, institute: "GasLAB, CICANUM, Physics School, Universidad de Costa Rica" },
        { name: "Ernesto Corrales", isPresenter: false, institute: "GasLAB, CICANUM, Physics School, Universidad de Costa Rica" },
        { name: "David Diaz", isPresenter: false, institute: "GasLAB, CICANUM, Physics School, Universidad de Costa Rica" },
        { name: "Alfredo Alan", isPresenter: false, institute: "GasLAB, CICANUM, Physics School, Universidad de Costa Rica" },
        { name: "Kenneth Wright", isPresenter: false, institute: "INFICON Inc." },
        { name: "Robert Kline-Shoder", isPresenter: false, institute: "CREARE Inc." },
        { name: "David Pieri", isPresenter: false, institute: "Jet Propulsion Laboratory, California Institute of Technology" }
      ],
      institutes: [
        "GasLAB, CICANUM, Physics School, Universidad de Costa Rica",
        "INFICON Inc.",
        "CREARE Inc.",
        "Jet Propulsion Laboratory, California Institute of Technology"
      ]
    }
  ]
};

// Also fix the corrupted affiliation strings (PowerShell encoding damage)
const affiliationFixes = {
  "Technical Session V": {
    "Alexandre Sonnette": "Alexandre Sonnette, Frédéric Progent, Jérôme Tupinier, Pierre-Etienne Buthier, Jean-Christophe Lictevout, Sébastien Vigne, CEA, DAM, DIF; Thomas Alava, CEA, LETI, MINATEC Campus"
  },
  "Technical Session VI": {
    "Valerie Derpmann": "Valerie Derpmann, Yessica Brachthäuser, Rüdiger Reuter, Michel Aliman, Alexander Laue, Hin Yiu Chung, Carl Zeiss SMT GmbH"
  }
};

let updated = 0;
for (const session of ws12.presentation_sessions) {
  const data = sessionsData[session.title];
  if (!data) continue;

  for (const pres of session.presentations) {
    const match = data.find(d => d.title === pres.title);
    if (match) {
      pres.authors = match.authors;
      pres.institutes = match.institutes;
      updated++;
      console.log(`  ✓ ${pres.name} — ${match.authors.length} authors, ${match.institutes.length} institutes`);
    }

    // Fix corrupted affiliations
    const fixes = affiliationFixes[session.title];
    if (fixes && fixes[pres.name]) {
      pres.affiliation = fixes[pres.name];
      console.log(`  ✓ Fixed affiliation encoding for ${pres.name}`);
    }
  }
}

// Also fix dates — the raw text says 10/18 but some entries say 2019. It should be 2018.
for (const session of ws12.presentation_sessions) {
  if (session.date && session.date.startsWith('2019')) {
    session.date = session.date.replace('2019', '2018');
    console.log(`  ✓ Fixed date: ${session.title} → ${session.date}`);
  }
}

console.log(`\nUpdated ${updated} presentations across sessions IV-VII`);

fs.writeFileSync(masterPath, JSON.stringify(workshops, null, 2), 'utf8');
console.log('Saved master_workshops.json');
