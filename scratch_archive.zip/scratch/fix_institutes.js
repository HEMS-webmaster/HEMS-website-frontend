const fs = require('fs');
const path = './src/frontend/src/data/master_workshops.json';
const data = JSON.parse(fs.readFileSync(path, 'utf8'));

const ws2005 = data.find(ws => ws.year === "2005");

function fixInstitutes(items) {
  if (!items) return;
  items.forEach(item => {
    if (typeof item.institutes === 'string') {
      item.institutes = item.institutes.split(';').map(n => n.trim()).filter(n => n.length > 0);
    }
  });
}

fixInstitutes(ws2005.presentations);
fixInstitutes(ws2005.posters);

fs.writeFileSync(path, JSON.stringify(data, null, 2));
console.log('Fixed institutes schema for 2005');
