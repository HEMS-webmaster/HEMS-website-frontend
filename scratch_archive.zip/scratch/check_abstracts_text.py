import os
import glob
import fitz

proceedings_dir = r"docs/archives_translation/proceedings/3rd"
abstract_files = glob.glob(os.path.join(proceedings_dir, "**", "*_Abstract.pdf"), recursive=True)

print(f"Found {len(abstract_files)} abstract PDFs to audit.")

missing_keyword = []
for fp in abstract_files:
    filename = os.path.basename(fp)
    doc = fitz.open(fp)
    page = doc.load_page(0)
    text = page.get_text()
    
    if "ABSTRACT" not in text:
        missing_keyword.append(filename)
        print(f"Warning: 'ABSTRACT' keyword NOT found in {filename}!")
    else:
        print(f"Success: 'ABSTRACT' found in {filename}")

print(f"\nAudit complete. Missing keyword in: {len(missing_keyword)} files.")
