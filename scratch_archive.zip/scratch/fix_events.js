const fs = require('fs');

const masterPath = './src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2005 = masterData.find(ws => ws.year === "2005");

if (ws2005 && ws2005.events) {
  // If the first event doesn't have a nested 'events' array, it's flat and needs grouping
  if (!ws2005.events[0].events) {
    const grouped = {};
    
    ws2005.events.forEach(ev => {
      const d = ev.date;
      if (!grouped[d]) grouped[d] = [];
      grouped[d].push({
        time: ev.time || "",
        end_time: ev.end_time || "",
        title: ev.title || "",
        subtitle: ev.subtitle || "",
        subtitle_url: "",
        location: ev.location || "",
        location_url: ""
      });
    });

    const newEvents = [];
    let dayCount = 1;
    
    // Sort dates
    const dates = Object.keys(grouped).sort();
    
    for (const d of dates) {
      const items = grouped[d];
      let dayTitle = "";
      if (d === "2005-09-20") {
        dayTitle = "Travel Day";
      } else {
        dayTitle = `HEMS Workshop, Day ${dayCount}`;
        dayCount++;
      }
      
      newEvents.push({
        time: items[0].time, // start time of first event
        end_time: "",
        title: dayTitle,
        subtitle: "",
        location: "",
        date: d,
        events: items
      });
    }
    
    ws2005.events = newEvents;
    fs.writeFileSync(masterPath, JSON.stringify(masterData, null, 2));
    console.log("Updated 2005 events schema");
  } else {
    console.log("Events already grouped");
  }
}
