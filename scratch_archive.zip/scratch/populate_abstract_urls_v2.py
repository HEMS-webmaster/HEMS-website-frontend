import re

summary_file = 'source-material/Old site docs/02thWorkshopSummary.md'

abstract_map = {
    "mass spectrometers for in situ planetary exploration": "abstracts2nd/AbstractBeauchamp.pdf",
    "a small multiple reflectron time of flight mass spectrometer mr tof ms for in situ investigations": "abstracts2nd/AbstractWollnik.pdf",
    "in situ laser tof ms on planets and small bodies": "abstracts2nd/AbstractBrinckerhoff.pdf",
    "a fully redundant on line mass spectrometric system for the space shuttle used to monitor cyogenic fuel leaks": "abstracts2nd/AbstractGriffin.pdf",
    "a miniaturized cylindrical lon trap mass spectrometer": "abstracts2nd/AbstractPatterson.pdf",
    "recent developments in micro lon trap mass spectrometry": "abstracts2nd/AbstractMoxom.pdf",
    "miniature tof mass spectrometer using a flexible circuitboard reflectron": "abstracts2nd/AbstractCornish.pdf",
    "disaster management using mobile mass spectrometers": "abstracts2nd/AbstractMatz.pdf",
    "direct sampling mass spectrometry in atmospheric chemistry": "abstracts2nd/AbstractBarket.pdf",
    "ms for trace explosives detection in aviation security": "abstracts2nd/AbstractChamberlain.pdf",
    "volcanic monitoring using field portable mass spectrometers towards on site and real time gas analysis at fumaroles": "abstracts2nd/AbstractDiaz.pdf",
    "project nereus concepts and principles for in situ ms": "abstracts2nd/AbstractHemond.pdf",
    "development of an underwater mass spectrometer for dissolved gases solutes and large organic compounds": "abstracts2nd/AbstractMcMurtry.pdf",
    "applications of in water mass spectrometry for detection of volatile organic compounds and dissolved gases": "abstracts2nd/AbstractShort.pdf",
    "polymeric membrane chlorocarbon permeabilities determined by membrane introduction mass spectrometry mims": "abstracts2nd/AbstractStone.pdf",
    "solid phase microextraction as a method for sampling with analysis by gas chromatography mass spectrometry in the field": "abstracts2nd/AbstractHook.pdf",
    "tiny time of flight tof mass spectrometer for biodetection": "abstracts2nd/AbstractBryden.pdf",
    "biological applications on a miniaturized delayed extraction tof mass spectrometer": "abstracts2nd/AbstractPrieto.pdf",
    "the portable horiba kore mass spectrometer ms 200": "abstracts2nd/AbstractNuber.pdf",
    "progress toward highly miniaturized vacuum pumps": "abstracts2nd/AbstractWiberg.pdf",
    "compact and rugged multipurpose tof": "abstracts2nd/PosterAbstractGonin.pdf",
    "development of a low cost miniature mass spectrometer": "abstracts2nd/PosterAbstractRohrs.pdf",
    "project nereus construction of a practical autonomous underwater gas analyzer": "abstracts2nd/PosterAbstractCamilli.pdf",
    "remotely operated mass spectrometers adaptive search platforms for field chemical profiling": "abstracts2nd/PosterAbstractFries.pdf"
}

def clean_title(title):
    title = title.replace('-', ' ').replace('/', ' ')
    title = re.sub(r'[^a-zA-Z0-9\s]', '', title)
    title = re.sub(r'\s+', ' ', title).strip().lower()
    return title

with open(summary_file, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
modified_count = 0
current_section = None

for i, line in enumerate(lines):
    # Track section headers
    if line.startswith('## 5. Oral Presentation Sessions'):
        current_section = 'oral'
    elif line.startswith('## 6. Poster Presentations'):
        current_section = 'poster'
    elif line.startswith('## ') and not line.startswith('## 5. Oral') and not line.startswith('## 6. Poster'):
        current_section = None

    # Check if the line is a table row in our target sections
    if current_section in ['oral', 'poster'] and line.strip().startswith('|') and line.strip().endswith('|'):
        parts = line.split('|')
        # Skip header and separator lines
        if not ':---' in line and not '| # |' in line and not 'Start Time' in line:
            if current_section == 'poster':
                # | # | Title | Authors | Presenter | Legacy Poster URL | Legacy Abstract URL |
                # Length of parts split by |: parts[0] is "", parts[1] is #, parts[2] is Title, parts[3] is Authors...
                if len(parts) >= 7:
                    raw_title = parts[2].strip().strip('"').strip("'").strip('“').strip('”')
                    cleaned = clean_title(raw_title)
                    
                    matched_url = abstract_map.get(cleaned)
                    if matched_url:
                        if not matched_url.startswith("http"):
                            matched_url = "https://www.hems-workshop.org/2ndWS/" + matched_url
                        current_abstract_val = parts[6].strip()
                        parts[6] = f" {matched_url} "
                        new_line = '|'.join(parts)
                        if current_abstract_val != matched_url:
                            print(f"Modifying Poster line {i+1}:")
                            print(f"  Old: {line.strip()}")
                            print(f"  New: {new_line.strip()}")
                            line = new_line
                            modified_count += 1
            elif current_section == 'oral':
                # | # | Time | Title | Authors | Presenter | Legacy Presentation URL | Legacy Abstract URL |
                # Length of parts split by |: parts[0] is "", parts[1] is #, parts[2] is Time, parts[3] is Title...
                if len(parts) >= 8:
                    raw_title = parts[3].strip().strip('"').strip("'").strip('“').strip('”')
                    cleaned = clean_title(raw_title)
                    
                    matched_url = abstract_map.get(cleaned)
                    if matched_url:
                        if not matched_url.startswith("http"):
                            matched_url = "https://www.hems-workshop.org/2ndWS/" + matched_url
                        current_abstract_val = parts[7].strip()
                        parts[7] = f" {matched_url} "
                        new_line = '|'.join(parts)
                        if current_abstract_val != matched_url:
                            print(f"Modifying Oral line {i+1}:")
                            print(f"  Old: {line.strip()}")
                            print(f"  New: {new_line.strip()}")
                            line = new_line
                            modified_count += 1

    new_lines.append(line)

if modified_count > 0:
    with open(summary_file, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    print(f"\nSuccessfully updated {modified_count} abstract URLs in {summary_file}.")
else:
    print("\nNo modifications made.")
