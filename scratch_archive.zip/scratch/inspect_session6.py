import json

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for ws in data:
    if ws.get('number') == 3:
        # Let's inspect Session 6 (Miniaturization / Technical Issues)
        session6 = ws['presentation_sessions'][5]
        print(f"Session 6: {session6.get('session_title')}")
        for talk in session6.get('presentations', []):
            print(f"\nTalk: {talk.get('title')}")
            for k, v in talk.items():
                print(f"  {k}: {repr(v)}")
