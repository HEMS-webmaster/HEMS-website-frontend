from bs4 import BeautifulSoup
import re
import json

with open('c:/Antigravity/HEMS-website/scratch/4thprogram.html', 'r', encoding='utf-8') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

current_date = None
current_session = None

sessions = []

# Mapping day text to date
dates = {
    'Tuesday': '2003-10-07',
    'Wednesday': '2003-10-08',
    'Thursday': '2003-10-09',
    'Friday': '2003-10-10'
}

for tag in soup.find_all(['h3', 'h4', 'strong', 'tr']):
    if tag.name in ['h3', 'h4']:
        text = tag.get_text(strip=True)
        for day, date_str in dates.items():
            if day in text:
                current_date = date_str
    elif tag.name == 'tr':
        tds = tag.find_all('td')
        if len(tds) >= 2:
            time_str = tds[0].get_text(strip=True)
            content_td = tds[1]
            
            # Check if this is a session header
            if 'Technical Session:' in content_td.get_text():
                title_text = content_td.get_text(strip=True)
                match = re.match(r'(Technical Session:.*?)\((.*?)\)', title_text)
                if match:
                    title = match.group(1).strip()
                    location = match.group(2).strip()
                else:
                    title = title_text
                    location = ""
                
                current_session = {
                    "date": current_date,
                    "title": title,
                    "time": time_str,
                    "end_time": "",
                    "location": location,
                    "presentations": []
                }
                sessions.append(current_session)
                continue
                
            # It's a presentation if it has an <a> tag
            a_tag = content_td.find('a')
            if a_tag and current_session:
                title = a_tag.get_text(strip=True).strip('“"”')
                url = a_tag.get('href')
                if url and not url.startswith('http'):
                    url = f"https://www.hems-workshop.org/4thWS/{url.lstrip('/')}"
                
                # Extract text after </a> to get authors and institutes
                # In BS, we can get next_siblings
                remaining_text = ""
                for sibling in a_tag.next_siblings:
                    if sibling.name == 'em':
                        remaining_text += sibling.get_text()
                    elif sibling.name is None:
                        remaining_text += str(sibling)
                
                remaining_text = remaining_text.strip()
                print("---")
                print(f"Time: {time_str}")
                print(f"Title: {title}")
                print(f"URL: {url}")
                print(f"Authors/Inst: {remaining_text}")

