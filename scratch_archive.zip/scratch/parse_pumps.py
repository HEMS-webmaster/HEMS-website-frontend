import re
from bs4 import BeautifulSoup

html_path = r"c:\Antigravity\HEMS-website\scratch\3rdpumpstalks.htm"

with open(html_path, 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f.read(), 'html.parser')

blockquotes = soup.find_all('blockquote')
print(f"Found {len(blockquotes)} blockquotes.")

for idx, bq in enumerate(blockquotes):
    print(f"\n--- Blockquote {idx+1} ---")
    
    # Extract anchor
    anchor = bq.find('a', attrs={'name': True})
    anchor_name = anchor['name'] if anchor else "None"
    
    # Extract title from <b>
    b_tag = bq.find('b')
    title = ""
    if b_tag:
        title = b_tag.get_text()
        # Clean title: remove quotes, newlines, and multiple spaces
        title = re.sub(r'[\s\n\r]+', ' ', title).strip('"\'“”`‘’ ')
        title = title.replace('&quot;', '"').replace('&ldquo;', '"').replace('&rdquo;', '"')
    
    # The first paragraph usually contains the title and author details
    p_tags = bq.find_all('p')
    if not p_tags:
        print("Error: No p tags in blockquote")
        continue
        
    first_p = p_tags[0]
    
    # Let's extract authors and institute
    # Usually, title is in <b>, and the rest is authors and institute
    # In some, authors are in <i>, institute is in parentheses
    # Let's get the text of the first paragraph, and strip the title text
    first_p_text = first_p.get_text()
    
    # Clean up authors/institutes text
    # Let's see if we can find <i> tag
    i_tag = first_p.find('i')
    if i_tag:
        authors = i_tag.get_text().strip()
    else:
        # If no <i> tag, maybe they are after the <b> tag
        # Let's get the text after <b>
        b_text = b_tag.get_text() if b_tag else ""
        rest_text = first_p_text.replace(b_text, "").strip()
        authors = rest_text
        
    # Standardize authors: clean multiple spaces
    authors = re.sub(r'[\s\n\r]+', ' ', authors).strip()
    
    # Extract institute from parentheses in the first paragraph
    match = re.search(r'\((.*?)\)', first_p_text)
    institute = match.group(1).strip() if match else ""
    
    # Let's clean authors text from institute parentheses and clean any trailing commas/semicolons
    if institute:
        authors = authors.replace(f"({institute})", "").strip()
    authors = re.sub(r'[\s\n\r]+', ' ', authors).strip(' ;,()')
    
    # The remaining p tags (and rest of the first p if it contains the abstract text)
    # represent the body text of the abstract
    body_parts = []
    
    # If the first p has a large amount of text after the author details (e.g. Phil Muntz has abstract in first p too!)
    # Let's check: in Phil Muntz, the first p has:
    # <b>...</b><br><i>Phil Muntz</i> (University of Southern California)</p>
    # Oh wait, in Phil Muntz, does it have abstract in a second p?
    # Yes, <p>Vacuum pumps for miniaturized instruments...
    # Wait, let's look at the remaining paragraphs
    for p in p_tags[1:]:
        p_text = p.get_text()
        # Remove trailing "program" links
        if "> program" in p_text or ">program" in p_text or "program" in p_text.lower() and (">" in p_text or "→" in p_text or "href" in str(p)):
            # Strip the program link
            # Clean up link text from the paragraph
            for a_link in p.find_all('a'):
                if 'program' in a_link.get_text().lower():
                    a_link.decompose()
            p_text = p.get_text()
            
        p_clean = re.sub(r'[\s\n\r]+', ' ', p_text).strip()
        if p_clean and p_clean != "program" and not p_clean.startswith(">"):
            # Strip trailing '>' or '&gt;'
            p_clean = p_clean.rstrip('> ').strip()
            if p_clean:
                body_parts.append(p_clean)
                
    body = "\n\n".join(body_parts)
    
    print(f"Anchor: {anchor_name}")
    print(f"Title: {title}")
    print(f"Authors: {authors}")
    print(f"Institute: {institute}")
    print(f"Body snippet: {body[:150]}...")
