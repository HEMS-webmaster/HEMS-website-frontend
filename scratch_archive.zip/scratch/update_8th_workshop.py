import json
import re
import urllib.parse
import os

with open('source-material/Old site docs/08thWorkshopSummary.md', 'r', encoding='utf-8') as f:
    md_content = f.read()

master_path = 'src/frontend/src/data/master_workshops.json'
with open(master_path, 'r', encoding='utf-8') as f:
    master_data = json.load(f)

def get_block(start_str, end_str):
    start = md_content.find(start_str)
    if start == -1: return ""
    end = md_content.find(end_str, start)
    if end == -1: end = len(md_content)
    return md_content[start:end]

sponsors = []
sponsors_block = get_block("## 3. Corporate Sponsors", "## 4. Itinerary Events")
for line in sponsors_block.split('\n'):
    if line.startswith('|') and not line.startswith('| #') and not line.startswith('| ---'):
        parts = [p.strip() for p in line.split('|') if p.strip() != '']
        if len(parts) >= 4:
            name = parts[1]
            url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[2])
            link = url_match.group(2) if url_match else (parts[2] if parts[2] != 'UNKNOWN' else "")
            year = parts[3] if parts[3] != 'UNKNOWN' else ""
            sponsors.append({
                "company": name,
                "year": year,
                "link": link,
                "logo_file": ""
            })

events_list = []
events_block = get_block("## 4. Itinerary Events", "## 5. Oral Presentation Sessions")
days = re.split(r'### (\d{4}-\d{2}-\d{2}) — (.*?)\n', events_block)
for i in range(1, len(days)-2, 3):
    date = days[i]
    title = days[i+1].strip()
    table = days[i+2]
    day_events = []
    for line in table.split('\n'):
        if line.startswith('|') and not line.startswith('| Start') and not line.startswith('| ---'):
            parts = [p.strip() for p in line.split('|')[1:-1]]
            if len(parts) >= 5:
                day_events.append({
                    "time": parts[0],
                    "end_time": parts[1],
                    "title": parts[2],
                    "subtitle": parts[3],
                    "subtitle_url": "",
                    "location": parts[4] if parts[4] != 'UNKNOWN' else "",
                    "location_url": ""
                })
    events_list.append({
        "date": date,
        "title": title,
        "events": day_events
    })

presentations_sessions = []
tech_block = get_block("## 5. Oral Presentation Sessions", "## 6. Poster Presentations")
def extract_url(raw):
    m = re.search(r'\[(.*?)\]\((.*?)\)', raw)
    if m:
        u = m.group(2)
        if 'google.com/search' in u:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get('q')
            if q: return q[0]
        return u
    if 'http' in raw:
        u = re.search(r'(https?://[^\s]+)', raw)
        if u: return u.group(1)
    return raw.strip() if raw.strip() != 'UNKNOWN' else ""

sessions = re.split(r'### Session: (.*?)\n', tech_block)
for i in range(1, len(sessions)-1, 2):
    s_title = sessions[i].strip()
    s_body = sessions[i+1]
    
    date_match = re.search(r'\* \*\*Date:\*\* (.*?)\n', s_body)
    date_str = date_match.group(1).strip() if date_match else ""
    
    loc_match = re.search(r'\* \*\*Location:\*\* (.*?)\n', s_body)
    loc_str = loc_match.group(1).strip() if loc_match else ""
    if loc_str == 'UNKNOWN': loc_str = ""

    institutes_mapping = {}
    inst_block = re.search(r'#### Institutes Referenced in This Session(.*?)$', s_body, re.DOTALL)
    if inst_block:
        for line in inst_block.group(1).strip().split('\n'):
            if line.startswith('|') and not line.startswith('| Talk') and not line.startswith('| ---'):
                parts = [p.strip() for p in line.split('|')[1:-1]]
                if len(parts) >= 2:
                    institutes_mapping[parts[0]] = parts[1]
    
    pres_list = []
    table_body = s_body.split('####')[0]
    for line in table_body.strip().split('\n'):
        if line.startswith('|') and not line.startswith('| #') and not line.startswith('| ---'):
            parts = [p.strip() for p in line.split('|')[1:-1]]
            if len(parts) >= 7:
                talk_num = parts[0]
                time_str = parts[1]
                title_str = parts[2]
                authors_raw = parts[3]
                presenter_raw = parts[4]
                pres_url_raw = parts[5]
                abs_url_raw = parts[6]

                pres_url = extract_url(pres_url_raw)
                abs_url = extract_url(abs_url_raw)
                
                p_file = os.path.basename(urllib.parse.unquote(pres_url)) if pres_url else ""
                a_file = os.path.basename(urllib.parse.unquote(abs_url)) if abs_url else ""

                presenter_name = re.sub(r'\*\*', '', presenter_raw).replace('[PRESENTER]', '').strip()
                
                authors = []
                for a in [x.strip() for x in authors_raw.split(',')]:
                    is_pres = False
                    if a.strip() == presenter_name or presenter_name in a:
                        is_pres = True
                    authors.append({
                        "name": a.strip(),
                        "isPresenter": is_pres,
                        "institute": institutes_mapping.get(talk_num, "")
                    })
                
                if not any(a["isPresenter"] for a in authors) and presenter_name:
                    for a in authors:
                        if presenter_name in a["name"]:
                            a["isPresenter"] = True
                            break
                if not any(a["isPresenter"] for a in authors) and len(authors) > 0:
                    authors[0]["isPresenter"] = True

                pres_list.append({
                    "time": time_str,
                    "title": title_str,
                    "authors": authors,
                    "url": pres_url,
                    "abstract_url": abs_url,
                    "presentation_file": p_file,
                    "abstract_file": a_file
                })
    
    presentations_sessions.append({
        "date": date_str,
        "title": s_title,
        "location": loc_str,
        "presentations": pres_list
    })

posters_list = []
posters_block = get_block("## 6. Poster Presentations", "## 7. Student Award Presenters")
institutes_mapping = {}
inst_block = re.search(r'#### Institutes Referenced in Posters(.*?)$', posters_block, re.DOTALL)
if inst_block:
    for line in inst_block.group(1).strip().split('\n'):
        if line.startswith('|') and not line.startswith('| Talk') and not line.startswith('| ---'):
            parts = [p.strip() for p in line.split('|')[1:-1]]
            if len(parts) >= 2:
                institutes_mapping[parts[0]] = parts[1]
                
table_body = posters_block.split('####')[0]
for line in table_body.strip().split('\n'):
    if line.startswith('|') and not line.startswith('| #') and not line.startswith('| ---'):
        parts = [p.strip() for p in line.split('|')[1:-1]]
        if len(parts) >= 6:
            talk_num = parts[0]
            title_str = parts[1]
            authors_raw = parts[2]
            presenter_raw = parts[3]
            pres_url_raw = parts[4]
            abs_url_raw = parts[5]
            
            pres_url = extract_url(pres_url_raw)
            abs_url = extract_url(abs_url_raw)
            
            if 'Amerom.pdf' in pres_url_raw and pres_url.endswith('van'):
                pres_url += '%20Amerom.pdf'

            p_file = os.path.basename(urllib.parse.unquote(pres_url)) if pres_url else ""
            a_file = os.path.basename(urllib.parse.unquote(abs_url)) if abs_url else ""

            presenter_name = re.sub(r'\*\*', '', presenter_raw).replace('[PRESENTER]', '').strip()
            
            authors = []
            for a in [x.strip() for x in authors_raw.split(',')]:
                authors.append({
                    "name": a.strip(),
                    "isPresenter": (a.strip() == presenter_name or presenter_name in a),
                    "institute": institutes_mapping.get(talk_num, "")
                })
            
            posters_list.append({
                "title": title_str,
                "authors": authors,
                "url": pres_url,
                "abstract_url": abs_url,
                "poster_file": p_file,
                "abstract_file": a_file
            })

students_list = []
awards_block = get_block("## 7. Student Award Presenters", "## 8. Extraction Notes")
for line in awards_block.split('\n'):
    if line.startswith('|') and not line.startswith('| #') and not line.startswith('| ---'):
        parts = [p.strip() for p in line.split('|')[1:-1]]
        if len(parts) >= 6:
            name = parts[1]
            inst = parts[2]
            title = parts[3]
            pres_url_raw = parts[4]
            abs_url_raw = parts[5]

            pres_url = extract_url(pres_url_raw)
            abs_url = extract_url(abs_url_raw)

            p_file = os.path.basename(urllib.parse.unquote(pres_url)) if pres_url else ""
            a_file = os.path.basename(urllib.parse.unquote(abs_url)) if abs_url else ""

            students_list.append({
                "name": name,
                "institute": inst if inst != 'UNKNOWN' else "",
                "url": pres_url,
                "presentation_file": p_file,
                "abstract_url": abs_url,
                "abstract_file": a_file
            })

for ws in master_data:
    if ws.get("number") == 8:
        ws["sponsors"] = sponsors
        ws["events"] = events_list
        ws["posters"] = posters_list
        ws["presentation_sessions"] = presentations_sessions
        ws["student_awards"] = students_list
        ws["venue_address"] = ""
        ws["city"] = "St. Pete Beach, Florida"
        ws["dates"] = "September 19–22, 2011"
        ws["venue"] = "Don CeSar Hotel"

with open(master_path, 'w', encoding='utf-8') as f:
    json.dump(master_data, f, indent=2)
print(f"Updated Workshop 8! Sponsors: {len(sponsors)}, Events: {len(events_list)}, Sessions: {len(presentations_sessions)}, Posters: {len(posters_list)}, Students: {len(students_list)}")
