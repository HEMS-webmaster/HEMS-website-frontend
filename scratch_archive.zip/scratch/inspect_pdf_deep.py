import fitz
import sys

pdf_path = "docs/archives_translation/proceedings/3th/Technical_Session_I__Space_Environments/3th_Beauchamp_Novel_Mass_Spectrometric_Abstract.pdf"
doc = fitz.open(pdf_path)
page = doc.load_page(0)

print(f"Page size: {page.rect.width} x {page.rect.height}")

print("\n--- DRAWINGS ---")
drawings = page.get_drawings()
for i, d in enumerate(drawings[:10]):
    print(f"Drawing {i}: type={d['type']}, fill={d.get('fill')}, color={d.get('color')}, rect={d['rect']}")

print("\n--- TEXT BLOCKS ---")
blocks = page.get_text("dict")["blocks"]
for b_idx, b in enumerate(blocks):
    if "lines" in b:
        for l_idx, line in enumerate(b["lines"]):
            for s_idx, span in enumerate(line["spans"]):
                print(f"Block {b_idx} Line {l_idx} Span {s_idx}:")
                print(f"  Text: {repr(span['text'])}")
                print(f"  Font: {span['font']}, Size: {span['size']:.2f}, Color: #{span['color']:06x}")
                print(f"  Origin: ({span['origin'][0]:.2f}, {span['origin'][1]:.2f})")
