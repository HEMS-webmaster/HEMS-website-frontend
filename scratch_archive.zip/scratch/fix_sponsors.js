const fs = require('fs');

// 1. Update 2005 Workshop Sponsors
const masterPath = './src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2005 = masterData.find(ws => ws.year === "2005");
if (ws2005 && ws2005.sponsors) {
  const updatedSponsors = [];
  
  // Host
  const host = ws2005.sponsors.find(s => s.isHost || s.name === "University of South Florida, Marine Science Department, Center for Ocean Technology");
  if (host) {
    updatedSponsors.push({ company: host.name || host.company, isHost: true });
  }

  const mapping = {
    "Griffin Analytical Technologies": { company: "FLIR / Griffin Analytical Technologies", logo: "FLIR_Griffin_Analytical_Technologies.png" },
    "Monitor Instruments": { company: "Monitor Instruments", logo: "Monitor_Instruments.png" },
    "Siemens": { company: "Siemens", logo: "Siemens.png" },
    "Varian, Inc.": { company: "Varian, Inc", logo: "Varian_Inc.png" },
    "Alcatel Vacuum": { company: "Alcatel Vacuum", logo: "Alcatel_Vacuum.png" },
    "Burle": { company: "Burle", logo: "Burle.png" },
    "Microsaic Systems": { company: "Microsaic Systems", logo: "Microsaic_Systems.png" },
    "Pfeiffer Vacuum": { company: "Pfeiffer Vacuum", logo: "Pfeiffer_Vacuum.png" }
  };

  ws2005.sponsors.forEach(s => {
    if (s.isHost || (s.name && s.name.includes("University of South Florida"))) return;
    
    const key = s.name || s.company;
    const mapped = mapping[key];
    if (mapped) {
      updatedSponsors.push({
        company: mapped.company,
        url: s.url || "",
        logo_file: mapped.logo
      });
    }
  });

  ws2005.sponsors = updatedSponsors;
  fs.writeFileSync(masterPath, JSON.stringify(masterData, null, 2));
  console.log("Updated 2005 sponsors in master_workshops.json");
}

// 2. Update Corporate Registry
const registryPath = './src/frontend/src/data/corporate_registry.json';
const registryData = JSON.parse(fs.readFileSync(registryPath, 'utf8'));

const newSponsors = [
  { company: "Monitor Instruments", url: "http://www.monitorinstruments.com", logo_file: "Monitor_Instruments.png", year_began: "2005" },
  { company: "Siemens", url: "http://www.sea.siemens.com/ia/product/aiquantra.html", logo_file: "Siemens.png", year_began: "2005" },
  { company: "Burle", url: "http://www.burle.com/", logo_file: "Burle.png", year_began: "2005" },
  { company: "Microsaic Systems", url: "http://www.microsaic.com/", logo_file: "Microsaic_Systems.png", year_began: "2005" }
];

newSponsors.forEach(ns => {
  if (!registryData.find(r => r.company === ns.company)) {
    registryData.push(ns);
  }
});

// Update Alcatel Vacuum year_began to 2005
const alcatel = registryData.find(r => r.company === "Alcatel Vacuum");
if (alcatel && (parseInt(alcatel.year_began) > 2005)) {
  alcatel.year_began = "2005";
}

registryData.sort((a, b) => a.company.localeCompare(b.company));
fs.writeFileSync(registryPath, JSON.stringify(registryData, null, 2));
console.log("Updated corporate_registry.json");
