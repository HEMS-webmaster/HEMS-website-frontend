import json

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

w4 = [w for w in data if w['number'] == 4][0]

updated = 0

def fix_pres(pres):
    global updated
    insts = pres.get('institutes', [])
    if not insts:
        return
        
    for a in pres.get('authors', []):
        if not a.get('institute'):
            # Just assign the first institute as a default so the dropdown isn't blank
            a['institute'] = insts[0]
            updated += 1

for session in w4.get('presentation_sessions', []):
    for pres in session.get('presentations', []):
        fix_pres(pres)

for pres in w4.get('posters', []):
    fix_pres(pres)

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"Assigned a default institute to {updated} authors in the 4th workshop.")
