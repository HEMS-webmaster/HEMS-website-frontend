import os
import sys

# We need a pdf parser in python or we can read the raw pdf stream for text strings.
# Reading raw PDF bytes for simple ASCII text strings is extremely fast and doesn't require complex dependencies.
def search_pdf_raw(file_path, term):
    try:
        with open(file_path, 'rb') as f:
            content = f.read()
        
        # Simple case-insensitive search
        term_bytes = term.lower().encode('utf-8')
        if term_bytes in content.lower():
            return True
    except Exception as e:
        pass
    return False

pdf_files = []
for root, dirs, files in os.walk(r"c:\Antigravity\HEMS-website"):
    for file in files:
        if file.lower().endswith(".pdf"):
            pdf_files.append(os.path.join(root, file))

print(f"Scanning {len(pdf_files)} PDFs for 'Hexblock'...")
matches = []
for pdf in pdf_files:
    if search_pdf_raw(pdf, 'Hexblock'):
        matches.append(pdf)

print(f"Found 'Hexblock' in {len(matches)} files:")
for m in matches:
    print(m)
