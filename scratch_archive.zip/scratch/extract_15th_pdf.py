import fitz
import sys

pdf_path = 'docs/archives_translation/proceedings/15th/Administrative/15th_Program.pdf'
doc = fitz.open(pdf_path)

text = ""
for page in doc:
    text += page.get_text("text")

with open('scratch/15th_pdf_extracted.txt', 'w', encoding='utf-8') as f:
    f.write(text)

print("Successfully extracted PDF text to scratch/15th_pdf_extracted.txt")
