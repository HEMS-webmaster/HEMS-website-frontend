import json
import re

md_path = r'c:\Antigravity\HEMS-website\source-material\Old site docs\06thWorkshopSummary.md'
json_path = r'c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json'

with open(md_path, 'r', encoding='utf-8') as f:
    md_content = f.read()

lines = md_content.split('\n')
mapping = {}
for line in lines:
    if line.strip().startswith('|') and not line.strip().startswith('|:') and not line.strip().startswith('| # |') and not line.strip().startswith('| Talk # |') and not line.strip().startswith('| Poster # |'):
        parts = [p.strip() for p in line.split('|')[1:-1]]
        if len(parts) >= 6:
            if len(parts) == 6:
                if '"' in parts[1]:
                    title = parts[1].strip('"').strip()
                    pres = parts[4]
                    abs_url = parts[5]
                    mapping[title] = (pres, abs_url)
                elif '"' in parts[3]:
                    title = parts[3].strip('"').strip()
                    pres = parts[4]
                    abs_url = parts[5]
                    mapping[title] = (pres, abs_url)
            elif len(parts) == 7:
                if '"' in parts[2]:
                    title = parts[2].strip('"').strip()
                    pres = parts[5]
                    abs_url = parts[6]
                    mapping[title] = (pres, abs_url)

with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws = next(w for w in data if w['number'] == 6)

changes = 0
missing_titles = []

for poster in ws.get('posters', []):
    t = poster.get('title', '').strip()
    if t in mapping:
        p, a = mapping[t]
        p_full = f"https://www.hems-workshop.org/6thWS/{p}" if p else ""
        a_full = f"https://www.hems-workshop.org/6thWS/{a}" if a else ""
        if poster.get('legacy_url') != p_full or poster.get('legacy_abstract_url') != a_full:
            poster['legacy_url'] = p_full
            poster['legacy_abstract_url'] = a_full
            changes += 1
    else:
        missing_titles.append(f"Poster: {t}")

for session in ws.get('presentation_sessions', []):
    for pres in session.get('presentations', []):
        t = pres.get('title', '').strip()
        if t in mapping:
            p, a = mapping[t]
            p_full = f"https://www.hems-workshop.org/6thWS/{p}" if p else ""
            a_full = f"https://www.hems-workshop.org/6thWS/{a}" if a else ""
            if pres.get('legacy_url') != p_full or pres.get('legacy_abstract_url') != a_full:
                pres['legacy_url'] = p_full
                pres['legacy_abstract_url'] = a_full
                changes += 1
        else:
            missing_titles.append(f"Talk: {t}")

for student in ws.get('student_awards', []):
    t = student.get('title', '').strip()
    if t in mapping:
        p, a = mapping[t]
        p_full = f"https://www.hems-workshop.org/6thWS/{p}" if p else ""
        a_full = f"https://www.hems-workshop.org/6thWS/{a}" if a else ""
        if student.get('legacy_url') != p_full or student.get('legacy_abstract_url') != a_full:
            student['legacy_url'] = p_full
            student['legacy_abstract_url'] = a_full
            changes += 1
    else:
        missing_titles.append(f"Student: {t}")

if changes > 0:
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print(f"Made {changes} changes")
else:
    print("No changes needed. Everything matched.")

if missing_titles:
    print("The following items were in JSON but didn't match a title in MD:")
    for m in missing_titles:
        print(m)
