import ast

with open('scratch/recovered_generator.py', 'r', encoding='utf-8') as f:
    content = f.read().strip()

# If the file starts and ends with quotes, it is a Python string literal
try:
    code = ast.literal_eval(content)
    with open('scratch/recovered_generator_clean.py', 'w', encoding='utf-8') as out:
        out.write(code)
    print("Successfully extracted code!")
except Exception as e:
    print("Failed to parse as string literal via ast.literal_eval:", e)
    # Fallback to eval or standard decoding if needed
    try:
        code = eval(content)
        with open('scratch/recovered_generator_clean.py', 'w', encoding='utf-8') as out:
            out.write(code)
        print("Successfully extracted via eval!")
    except Exception as e2:
        print("Failed to parse via eval:", e2)
