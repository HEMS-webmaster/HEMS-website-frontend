import os
import json

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws4 = None
for w in data:
    if w.get('number') == 4:
        ws4 = w
        break

reverted_count = 0

def clean_presentation(pres, session_dir):
    global reverted_count
    if pres.get('legacy_abstract_url') == 'https://www.hems-workshop.org/3rdWS/3rdquicklinksalpha.html':
        print(f"Reverting {pres.get('title')[:50]}...")
        
        # Delete PDF
        if pres.get('abstract_file'):
            pdf_path = os.path.join('c:/Antigravity/HEMS-website/docs/archives_translation/proceedings/4th', session_dir, pres['abstract_file'])
            if os.path.exists(pdf_path):
                os.remove(pdf_path)
                print(f"  Deleted {pdf_path}")
            del pres['abstract_file']
            
        del pres['legacy_abstract_url']
        reverted_count += 1

import re
def get_clean_session_regex(session_title):
    clean = re.sub(r'\s*\(.*?\)\s*', '', session_title).strip()
    return re.sub(r'[^a-zA-Z0-9]', '_', clean)

for session in ws4.get('presentation_sessions', []):
    session_title = session.get('title', 'General')
    clean_session = get_clean_session_regex(session_title)
    
    for pres in session.get('presentations', []):
        clean_presentation(pres, clean_session)

for pres in ws4.get('posters', []):
    clean_presentation(pres, 'Posters')

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"\nDone! Reverted {reverted_count} presentations.")
