import json
import os
import glob

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"
proceedings_dir = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3rd"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws3 = None
for ws in data:
    if ws.get('number') == 3:
        ws3 = ws
        break

if not ws3:
    print("3rd workshop not found!")
    exit(1)

print("3rd Workshop sessions and presentations:")
total_abstracts = 0
missing_abstracts = []

# Collect all files in proceedings/3rd recursively
existing_files = glob.glob(os.path.join(proceedings_dir, "**", "*"), recursive=True)
existing_filenames = [os.path.basename(f) for f in existing_files if os.path.isfile(f)]
print(f"Total existing files in proceedings/3rd: {len(existing_filenames)}")

for session in ws3.get('presentation_sessions', []):
    session_title = session.get('title', '')
    print(f"\nSession: {session_title}")
    for idx, pres in enumerate(session.get('presentations', [])):
        title = pres.get('title', '')
        abstract_file = pres.get('abstract_file', '')
        legacy_abstract_url = pres.get('legacy_abstract_url', '')
        
        print(f"  Presentation {idx+1}: {title[:50]}...")
        if abstract_file:
            total_abstracts += 1
            is_missing = abstract_file not in existing_filenames
            print(f"    Abstract File: {abstract_file} (Missing: {is_missing})")
            if is_missing:
                missing_abstracts.append({
                    'type': 'presentation',
                    'session_title': session_title,
                    'title': title,
                    'abstract_file': abstract_file,
                    'legacy_abstract_url': legacy_abstract_url,
                    'presentation': pres
                })
        else:
            print("    No abstract file assigned in JSON")

for idx, poster in enumerate(ws3.get('posters', [])):
    title = poster.get('title', '')
    abstract_file = poster.get('abstract_file', '')
    legacy_abstract_url = poster.get('legacy_abstract_url', '')
    
    if abstract_file:
        is_missing = abstract_file not in existing_filenames
        if is_missing:
            missing_abstracts.append({
                'type': 'poster',
                'session_title': 'Posters',
                'title': title,
                'abstract_file': abstract_file,
                'legacy_abstract_url': legacy_abstract_url,
                'poster': poster
            })

print(f"\nTotal expected abstract files: {total_abstracts}")
print(f"Total missing abstract files in proceedings/3rd: {len(missing_abstracts)}")
for missing in missing_abstracts:
    print(f"  - {missing['abstract_file']} ({missing['type']}): {missing['title']}")
