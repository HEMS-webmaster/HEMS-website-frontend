const fs = require('fs');
const dataPath = 'src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
const ws13 = masterData.find(w => w.number == 13);

const DATE_17 = "Tuesday, September 17, 2019: HEMS Workshop";
const DATE_18 = "Wednesday, September 18, 2019: HEMS Workshop";
const DATE_19 = "Thursday, September 19, 2019: HEMS Workshop";

ws13.presentations = [
  {
    "time": "08:40",
    "date": DATE_17,
    "session": "Technical Session I",
    "title": "On-site Applications of MIMS and the Importance of Interface Design as Exemplified by Highly Unusual “Fragments” in MIMS Mass Spectra of Chloramines and Bromamines",
    "authors": [{"name": "Frants R. Lauritsen", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Lauritsen_Onsite_Presentation.pdf",
    "abstract_file": "13th_Lauritsen_Onsite_Abstract.pdf"
  },
  {
    "time": "10:30",
    "date": DATE_17,
    "session": "Technical Session II",
    "title": "Development of Micro-Time-Of-Flight Mass Spectrometer with Orthogonal Injection for In situ Gas Analysis",
    "authors": [{"name": "Frédéric Progent", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Progent_Development_Presentation.pdf",
    "abstract_file": "13th_Progent_Development_Abstract.pdf"
  },
  {
    "time": "11:00",
    "date": DATE_17,
    "session": "Technical Session II",
    "title": "The Dragonfly Mission to Titan and the Enabling Technologies of the DraMS Mass Spectrometer Onboard",
    "authors": [{"name": "R. M. Danell", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Danell_The_Presentation.pdf",
    "abstract_file": "13th_Danell_The_Abstract.pdf"
  },
  {
    "time": "08:30",
    "date": DATE_18,
    "session": "Technical Session IV",
    "title": "Electric Field Fragmentation of Mobility Selected Ions Using Tandem Ion Mobility Spectrometry at Ambient Pressure with Molecular Identification through Neural Network Analysis",
    "authors": [{"name": "Gary A. Eiceman", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Eiceman_Electric_Presentation.pdf",
    "abstract_file": "13th_Eiceman_Electric_Abstract.pdf"
  },
  {
    "time": "09:00",
    "date": DATE_18,
    "session": "Technical Session IV",
    "title": "Chemical Ionization of Xenon and Detection Utilizing a High Precision Digital Ion Trap (DIT)",
    "authors": [{"name": "Timothy Vazquez", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Vazquez_Chemical_Presentation.pdf",
    "abstract_file": "13th_Vazquez_Chemical_Abstract.pdf"
  },
  {
    "time": "09:30",
    "date": DATE_18,
    "session": "Technical Session IV",
    "title": "Portable Mass Spectrometer for Explosives and Narcotics Detection",
    "authors": [{"name": "Vadym Berkout", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Berkout_Portable_Presentation.pdf",
    "abstract_file": "13th_Berkout_Portable_Abstract.pdf"
  },
  {
    "time": "11:00",
    "date": DATE_18,
    "session": "Technical Session V",
    "title": "Use of Computational Sensing Techniques to Improve the Performance of Mass Spectrometers in Harsh Environments",
    "authors": [{"name": "Jason J. Amsden", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Amsden_Use_Presentation.pdf",
    "abstract_file": "13th_Amsden_Use_Abstract.pdf"
  },
  {
    "time": "11:30",
    "date": DATE_18,
    "session": "Technical Session V",
    "title": "SIMION Beyond Ion Simulation: Field Analysis, Synthesis, and Harmonic Analysis for MS Design",
    "authors": [{"name": "Robert H. Jackson", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Jackson_SIMION_Presentation.pdf",
    "abstract_file": "13th_Jackson_SIMION_Abstract.pdf"
  },
  {
    "time": "13:30",
    "date": DATE_18,
    "session": "Technical Session VI",
    "title": "Spacecraft Atmosphere Monitor (S.A.M.) First Operational Data",
    "authors": [{"name": "Stojan Madzunkov", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Madzunkov_Spacecraft_Presentation.pdf",
    "abstract_file": "13th_Madzunkov_Spacecraft_Abstract.pdf"
  },
  {
    "time": "14:00",
    "date": DATE_18,
    "session": "Technical Session VI",
    "title": "The Future of Linear Ion Trap Mass Spectrometer Systems for Planetary Exploration",
    "authors": [{"name": "D. A. Kaplan", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Kaplan_The_Presentation.pdf",
    "abstract_file": "13th_Kaplan_The_Abstract.pdf"
  },
  {
    "time": "14:30",
    "date": DATE_18,
    "session": "Technical Session VI",
    "title": "Onsite Analysis of Illicit Drugs by Portable Ion Trap Gas Chromatography-Mass Spectrometry (GCMS)",
    "authors": [{"name": "Charlie Schmidt", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Schmidt_Onsite_Presentation.pdf",
    "abstract_file": "13th_Schmidt_Onsite_Abstract.pdf"
  },
  {
    "time": "15:30",
    "date": DATE_18,
    "session": "Technical Session VII",
    "title": "Membrane Inlet Mass Spectrometry for Ocean Worlds",
    "authors": [{"name": "R. Timothy Short", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Short_Membrane_Presentation.pdf",
    "abstract_file": "13th_Short_Membrane_Abstract.pdf"
  },
  {
    "time": "16:00",
    "date": DATE_18,
    "session": "Technical Session VII",
    "title": "Evolution of a Compact TOF Mass Spectrometer from Space Exploration to the Internet of Things",
    "authors": [{"name": "D. Lasi", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Lasi_Evolution_Presentation.pdf",
    "abstract_file": "13th_Lasi_Evolution_Abstract.pdf"
  },
  {
    "time": "16:30",
    "date": DATE_18,
    "session": "Technical Session VII",
    "title": "Development of a Low-Cost, Low-Power, Miniature Sector Mass Spectrometer with IonCCD Detection",
    "authors": [{"name": "Noah Christian", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Christian_Development_Presentation.pdf",
    "abstract_file": "13th_Christian_Development_Abstract.pdf"
  },
  {
    "time": "09:00",
    "date": DATE_19,
    "session": "Technical Session VIII",
    "title": "Smart City Initiatives and Where HEMS Can Play a Role",
    "authors": [{"name": "Guido Verbek", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Verbek_Smart_Presentation.pdf",
    "abstract_file": "13th_Verbek_Smart_Abstract.pdf"
  },
  {
    "time": "09:30",
    "date": DATE_19,
    "session": "Technical Session VIII",
    "title": "LUVMI Rover to Characterize Volatile Content in Lunar Polar Regions",
    "authors": [{"name": "Simon Sheridan", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Sheridan_LUVMI_Presentation.pdf",
    "abstract_file": "13th_Sheridan_LUVMI_Abstract.pdf"
  },
  {
    "time": "10:30",
    "date": DATE_19,
    "session": "Technical Session IX",
    "title": "Low-Pressure ICP-MS for Planetary Trace Elemental Analysis",
    "authors": [{"name": "Mazdak Taghioskoui", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Taghioskoui_LowPressure_Presentation.pdf",
    "abstract_file": "13th_Taghioskoui_LowPressure_Abstract.pdf"
  },
  {
    "time": "11:00",
    "date": DATE_19,
    "session": "Technical Session IX",
    "title": "QIT-Mass Spectrometer for Lunar and Planetary Applications",
    "authors": [{"name": "Frank Maiwald", "isPresenter": true, "affiliation": ""}],
    "presentation_file": "13th_Maiwald_QITMass_Presentation.pdf",
    "abstract_file": "13th_Maiwald_QITMass_Abstract.pdf"
  }
];

ws13.student_awards = [
  {
    "time": "09:30",
    "date": DATE_17,
    "session": "Technical Session I",
    "title": "Designing a Coded Aperture Cycloidal Mass Analyzer to Detect Perfluorocarbon Tracers",
    "name": "Kathleen L. Horvath",
    "institute": "",
    "presentation_file": "13th_Horvath_Designing_Presentation.pdf",
    "abstract_file": "13th_Horvath_Designing_Abstract.pdf"
  },
  {
    "time": "11:30",
    "date": DATE_17,
    "session": "Technical Session II",
    "title": "Evaluation of Aperture Materials for Coded Apertures Used in a Portable Cycloidal Miniature Mass Spectrometer",
    "name": "Tanouir Aloui",
    "institute": "",
    "presentation_file": "13th_Aloui_Evaluation_Presentation.pdf",
    "abstract_file": "13th_Aloui_Evaluation_Abstract.pdf"
  },
  {
    "time": "10:30",
    "date": DATE_18,
    "session": "Technical Session V",
    "title": "Detection and Analysis of Simulated Chemical Warfare Agents using Portable Mass Spectrometry",
    "name": "Camila Anguiano Virgen",
    "institute": "",
    "presentation_file": "13th_Virgen_Detection_Presentation.pdf",
    "abstract_file": "13th_Virgen_Detection_Abstract.pdf"
  }
];

fs.writeFileSync(dataPath, JSON.stringify(masterData, null, 2));
console.log('Fixed exactly 18 presentations and 3 student awards with full PROGRAM details!');
