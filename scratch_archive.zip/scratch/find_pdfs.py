import os

pdf_files = []
for root, dirs, files in os.walk(r"c:\Antigravity\HEMS-website"):
    for file in files:
        if file.lower().endswith(".pdf"):
            pdf_files.append(os.path.join(root, file))

print(f"Found {len(pdf_files)} PDF files in workspace:")
for pdf in pdf_files[:50]:
    print(pdf)
if len(pdf_files) > 50:
    print(f"... and {len(pdf_files) - 50} more")
