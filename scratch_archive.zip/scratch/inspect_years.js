const fs = require('fs');
const path = require('path');

const masterPath = path.join(__dirname, '..', 'src', 'frontend', 'src', 'data', 'master_workshops.json');
const data = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

console.log('Workshops in master_workshops.json:');
data.forEach(ws => {
  console.log(`Number: ${ws.number}, Year: ${ws.year}, City: ${ws.city}`);
});
