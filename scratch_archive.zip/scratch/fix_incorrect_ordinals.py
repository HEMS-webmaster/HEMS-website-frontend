import os
import json
import time

base_dir = r"c:\Antigravity\HEMS-website"
proceedings_dir = os.path.join(base_dir, "docs", "archives_translation", "proceedings")
master_path = os.path.join(base_dir, "src", "frontend", "src", "data", "master_workshops.json")

print("=== Suffix & Ordinal Repair Script starting up ===")

dir_mappings = {
    "1th": "1st",
    "2th": "2nd",
    "3th": "3rd"
}

# Try to rename directories with retries
for src, dest in dir_mappings.items():
    src_path = os.path.join(proceedings_dir, src)
    dest_path = os.path.join(proceedings_dir, dest)
    if os.path.exists(src_path):
        renamed = False
        for attempt in range(5):
            try:
                os.rename(src_path, dest_path)
                print(f"Renamed directory: {src} -> {dest}")
                renamed = True
                break
            except PermissionError as pe:
                print(f"PermissionError renaming {src} -> {dest} (attempt {attempt+1}): {pe}")
                time.sleep(2)
        if not renamed:
            print(f"Fatal: Failed to rename directory {src} after several attempts.")
            # Let's inspect what files are inside
            try:
                files = os.listdir(src_path)
                print(f"Files inside {src}: {files[:10]}")
            except Exception as ex:
                print(f"Could not list dir: {ex}")
    else:
        print(f"Directory {src} already renamed or does not exist.")

# Rename files in the directories (check both original and target folder names in case rename failed)
active_dirs = [("1st", "1th"), ("2nd", "2th"), ("3rd", "3th")]
file_rename_count = 0

for target, original in active_dirs:
    # Use target if it exists, otherwise fall back to original for file renames
    folder = target if os.path.exists(os.path.join(proceedings_dir, target)) else original
    folder_path = os.path.join(proceedings_dir, folder)
    if not os.path.exists(folder_path):
        continue
    
    print(f"Processing folder: {folder}")
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            prefix_to_replace = None
            replacement_prefix = None
            if original == "1th" and file.lower().startswith("1th_"):
                prefix_to_replace = "1th_"
                replacement_prefix = "1st_"
            elif original == "2th" and file.lower().startswith("2th_"):
                prefix_to_replace = "2th_"
                replacement_prefix = "2nd_"
            elif original == "3th" and file.lower().startswith("3th_"):
                prefix_to_replace = "3th_"
                replacement_prefix = "3rd_"
                
            if prefix_to_replace and replacement_prefix:
                new_file = replacement_prefix + file[len(prefix_to_replace):]
                old_filepath = os.path.join(root, file)
                new_filepath = os.path.join(root, new_file)
                
                try:
                    if not os.path.exists(new_filepath):
                        os.rename(old_filepath, new_filepath)
                        print(f"  Renamed file: {file} -> {new_file}")
                        file_rename_count += 1
                    else:
                        os.remove(old_filepath)
                        print(f"  Removed duplicate: {file}")
                except Exception as ex:
                    print(f"  Failed to rename file {file}: {ex}")

print(f"Successfully renamed {file_rename_count} files on disk.")

# 3. Update master JSON database file paths
if os.path.exists(master_path):
    with open(master_path, 'r', encoding='utf-8') as f:
        master_content = f.read()
        
    import re
    master_content = re.sub(r'(?<!\d)1th_', '1st_', master_content)
    master_content = re.sub(r'(?<!\d)2th_', '2nd_', master_content)
    master_content = re.sub(r'(?<!\d)3th_', '3rd_', master_content)
    
    master_content = re.sub(r'(?<!\d)1th/', '1st/', master_content)
    master_content = re.sub(r'(?<!\d)2th/', '2nd/', master_content)
    master_content = re.sub(r'(?<!\d)3th/', '3rd/', master_content)
    
    with open(master_path, 'w', encoding='utf-8') as f:
        f.write(master_content)
        
    print(f"Successfully updated master database with regex: {master_path}")
else:
    print(f"Error: master_workshops.json not found at {master_path}")
