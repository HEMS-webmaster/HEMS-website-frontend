import os
from PyPDF2 import PdfReader, PdfWriter

# Let's test the create_string_object error file with resolving/coercing the values
string_obj_pdf = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\10th\Technical_Session_VIII\10th_Krause_The_Fast_Path_Presentation.pdf"

print("--- Testing create_string_object file with real metadata values ---")
if os.path.exists(string_obj_pdf):
    try:
        reader = PdfReader(string_obj_pdf)
        meta = reader.metadata
        print("Original metadata:")
        for k, v in meta.items():
            # Resolve the IndirectObject
            resolved_val = v.get_object() if hasattr(v, 'get_object') else v
            print(f"  {k} (resolved type {type(resolved_val)}): {repr(resolved_val)}")
        
        # Build clean metadata
        new_meta = {}
        if meta:
            for k, v in meta.items():
                k_str = str(k)
                # Resolve value
                resolved_val = v.get_object() if hasattr(v, 'get_object') else v
                if resolved_val is not None:
                    # Convert custom PyPDF2 objects to basic python types
                    if isinstance(resolved_val, bytes):
                        # Decode or convert bytes
                        try:
                            new_meta[k_str] = resolved_val.decode('utf-8')
                        except:
                            new_meta[k_str] = resolved_val.decode('latin1')
                    else:
                        new_meta[k_str] = str(resolved_val)
        
        new_meta['/Title'] = 'Test Optimized Title'
        new_meta['/Author'] = 'Test Optimized Author'
        new_meta['/Subject'] = 'Test Optimized Subject'
        new_meta['/Keywords'] = 'Test Optimized Keywords'
        
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        writer.add_metadata(new_meta)
        
        temp_out = string_obj_pdf + ".test_str"
        with open(temp_out, "wb") as f:
            writer.write(f)
        print("Wrote successfully after resolving indirect objects!")
        os.remove(temp_out)
    except Exception as e:
        print(f"Failed create_string_object: {e}")
else:
    print("Test create_string_object PDF does not exist!")
