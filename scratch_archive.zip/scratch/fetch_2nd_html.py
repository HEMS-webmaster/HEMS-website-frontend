import urllib.request
from bs4 import BeautifulSoup
import re

url = 'https://www.hems-workshop.org/2ndWS/2ndprogrampresentations.html'
try:
    print(f"Fetching {url}...")
    headers = {'User-Agent': 'Mozilla/5.0'}
    req = urllib.request.Request(url, headers=headers)
    html = urllib.request.urlopen(req).read().decode('latin-1')
    
    # Save the raw HTML for inspection
    with open('scratch/2ndWS_program.html', 'w', encoding='utf-8') as f:
        f.write(html)
    print("Raw HTML saved to scratch/2ndWS_program.html")

    soup = BeautifulSoup(html, 'html.parser')
    
    print("\n--- Listing all links containing 'abstract' ---")
    links = soup.find_all('a', href=True)
    count = 0
    for link in links:
        href = link['href']
        text = link.get_text(strip=True)
        if 'abstract' in href.lower() or 'abstract' in text.lower():
            print(f"Text: '{text}' | Href: '{href}'")
            count += 1
            
    print(f"\nFound {count} abstract-related links in total.")

except Exception as e:
    print(f"Error fetching URL: {e}")
