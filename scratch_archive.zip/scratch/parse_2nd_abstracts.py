from bs4 import BeautifulSoup
import re

with open('scratch/2ndprogrampresentations.html', 'r', encoding='utf-8', errors='ignore') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

print("--- ALL LINKS ---")
links = []
for a in soup.find_all('a', href=True):
    href = a['href']
    text = a.get_text(strip=True)
    links.append((href, text))
    print(f"Href: {href} | Text: {text}")

print("--- ABSTRACT LINKS ---")
for href, text in links:
    if 'abstract' in href.lower() or 'abstract' in text.lower():
        print(f"Abstract Href: {href} | Text: {text}")
