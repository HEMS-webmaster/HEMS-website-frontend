const fs = require('fs');
const path = require('path');

const masterPath = path.join(__dirname, '..', 'src', 'frontend', 'src', 'data', 'master_workshops.json');
const data = JSON.parse(fs.readFileSync(masterPath, 'utf8'));

const ws2018 = data.find(ws => ws.year === 2018);
console.log('2018 Presentations:');
ws2018.presentation_sessions.forEach(session => {
  session.presentations.forEach(talk => {
    console.log(`- Title: "${talk.title}"`);
    console.log(`  Presenter: "${talk.presenter || talk.name}"`);
    console.log(`  Url: "${talk.url || ''}"`);
    console.log(`  Abstract Url: "${talk.abstract_url || ''}"`);
    console.log(`  Presentation File: "${talk.presentation_file || ''}"`);
  });
});
