from bs4 import BeautifulSoup
import re

with open('scratch/2ndprogrampresentations.html', 'r', encoding='utf-8', errors='ignore') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

# We can find all elements and track current section or talk titles.
# Let's find all rows/cells or text blocks that contain presentations.
# Talks are listed sequentially in the HTML. Let's extract all links and their surrounding text.

elements = soup.find_all(['table', 'tr', 'td', 'p', 'b', 'font'])
# Let's print out the exact text around the abstract and presentation links.
# Usually, a talk is formatted as: Title link, followed by (abstract href) and sometimes (presentation href).

# Let's search for "abstract" links specifically and print their sibling text or parent row content
print("--- DETAILED TALK FLOW ---")
for a in soup.find_all('a', href=True):
    href = a['href']
    if 'abstract' in href.lower() and not href.endswith('.zip'):
        # Find preceding text/links
        parent = a.find_parent('td') or a.find_parent('p') or a.find_parent('tr')
        if parent:
            text = parent.get_text(" ", strip=True)
            # Remove extra spacing
            text = re.sub(r'\s+', ' ', text)
            print(f"Abstract Link: {href}")
            print(f"  Parent Context: {text[:200]}...")
            print("-" * 50)
