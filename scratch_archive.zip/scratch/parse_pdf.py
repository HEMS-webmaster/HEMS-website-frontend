import json

lines = open('scratch/13th_pdf_extracted.txt', encoding='utf-8').read().split('\n')
program_lines = lines[137:234]

presentations = []
student_awards = []

current_date = ""
current_session = ""

i = 0
while i < len(program_lines):
    line = program_lines[i].strip()
    if not line:
        i += 1
        continue
    
    if line.startswith("Tue, 9/17"):
        current_date = "2019-09-17"
    elif line.startswith("Wed, 9/18"):
        current_date = "2019-09-18"
    elif line.startswith("Thu, 9/19"):
        current_date = "2019-09-19"
        
    if "Technical Session" in line and not "Vendor" in line and not "Poster" in line:
        if line.endswith(":"):
            # e.g., 8:40 a.m. Technical Session I:
            current_session = line.split(" ", 2)[2].replace(":", "")
        else:
            current_session = line
            
    # A presentation title starts with a time, e.g. 8:40 a.m. Title
    import re
    match = re.match(r'^(\d{1,2}:\d{2}\s+[ap]\.m\.)\s+(.+)', line)
    if match and "Technical Session" not in line and "Break" not in line and "Lunch" not in line and "Vendor" not in line and "Poster" not in line and "Welcome" not in line and "Photo" not in line and "Evening" not in line and "Set-up" not in line and "Dinner" not in line and "Remarks" not in line and "Ends" not in line:
        time_str = match.group(1)
        title = match.group(2)
        
        # Accumulate title if it spans multiple lines
        i += 1
        while i < len(program_lines) and not re.match(r'^\d{1,2}:\d{2}', program_lines[i]) and "Break" not in program_lines[i] and not "Technical Session" in program_lines[i]:
            next_line = program_lines[i].strip()
            if not next_line:
                i += 1
                continue
                
            # If the next line is the author, it usually doesn't have many words, or it has "Student Award Winner"
            if len(next_line.split()) < 5 or "Winner" in next_line or "Lauritsen" in next_line or "Progent" in next_line or "Danell" in next_line or "Eiceman" in next_line or "Vazquez" in next_line or "Berkout" in next_line or "Amsden" in next_line or "Jackson" in next_line or "Madzunkov" in next_line or "Kaplan" in next_line or "Schmidt" in next_line or "Short" in next_line or "Lasi" in next_line or "Christian" in next_line or "Verbek" in next_line or "Sheridan" in next_line or "Taghioskoui" in next_line or "Maiwald" in next_line:
                author_line = next_line
                
                # We found the author
                # Now construct the object
                is_student = "Student Award Winner" in author_line
                author_name = author_line.replace(", 2019 Student Award Winner", "").strip()
                
                # Convert time to 24h
                t_parts = time_str.split(" ")
                hm = t_parts[0].split(":")
                h = int(hm[0])
                m = int(hm[1])
                if t_parts[1] == "p.m." and h != 12:
                    h += 12
                elif t_parts[1] == "a.m." and h == 12:
                    h = 0
                time_24 = f"{h:02d}:{m:02d}"
                
                author_clean = author_name.split(',')[0].split(' ')[-1].replace(r'[^a-zA-Z0-9]', '')
                title_clean = title.replace(r'[^a-zA-Z0-9\s]', '').split()[0]
                
                obj = {
                    "time": time_str,
                    "date": current_date,
                    "session": current_session,
                    "title": title.replace("", '"'),
                    "authors": [
                        {
                            "name": author_name,
                            "isPresenter": True,
                            "affiliation": ""
                        }
                    ],
                    "presentation_file": f"13th_{author_clean}_{title_clean}_Presentation.pdf",
                    "abstract_file": f"13th_{author_clean}_{title_clean}_Abstract.pdf"
                }
                
                if is_student:
                    # student awards have institute instead of affiliation
                    obj["name"] = author_name
                    obj["institute"] = ""
                    del obj["authors"]
                    student_awards.append(obj)
                else:
                    presentations.append(obj)
                    
                break
            else:
                title += " " + next_line
                i += 1
        continue
    i += 1

with open('scratch/fixed_presentations.json', 'w') as f:
    json.dump({ "presentations": presentations, "student_awards": student_awards }, f, indent=2)

print("Extracted", len(presentations), "presentations and", len(student_awards), "student awards")
