import json

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for workshop in data:
    if workshop.get('number') == 4 or workshop.get('year') == '2003':
        new_sponsors = []
        for sponsor in workshop.get('sponsors', []):
            if not sponsor.get('isHost'):
                new_sponsors.append(sponsor)
        workshop['sponsors'] = new_sponsors

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Removed host from 2003 sponsors.")
