import json

log_path = r"C:\Users\ryanb\.gemini\antigravity-ide\brain\c68278c9-9926-4d9b-a048-9feaef8860bf\.system_generated\logs\transcript.jsonl"
with open(log_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines in transcript: {len(lines)}")
print("--- Recent User Inputs ---")
user_inputs = []
for line in lines:
    try:
        data = json.loads(line)
        if data.get('type') == 'USER_INPUT' or data.get('source') == 'USER_EXPLICIT':
            user_inputs.append(data)
    except Exception as e:
        pass

for inp in user_inputs[-10:]:
    print(f"Step {inp.get('step_index')}: Source={inp.get('source')}, Type={inp.get('type')}")
    print(f"  Content: {inp.get('content')}")
    print("-" * 40)
