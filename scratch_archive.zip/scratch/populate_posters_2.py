import json

master_file = 'src/frontend/src/data/master_workshops.json'

with open(master_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Define posters for Workshop 2 (2001)
posters_2001 = [
  {
    "date": "2001-03-19",
    "time": "3:30 PM",
    "session": "Poster Session",
    "title": "Compact and Rugged Multipurpose TOF",
    "authors": [
      {
        "name": "M. Gonin",
        "isPresenter": True,
        "institute": "lonwerks, Inc., Houston, TX"
      },
      {
        "name": "K. Fuhrer",
        "isPresenter": False,
        "institute": "lonwerks, Inc., Houston, TX"
      },
      {
        "name": "J.A. Schultz",
        "isPresenter": False,
        "institute": "lonwerks, Inc., Houston, TX"
      }
    ],
    "institutes": [
      "lonwerks, Inc., Houston, TX"
    ],
    "legacy_url": "",
    "legacy_abstract_url": "",
    "poster_file": "",
    "abstract_file": ""
  },
  {
    "date": "2001-03-19",
    "time": "3:30 PM",
    "session": "Poster Session",
    "title": "Development of a Low Cost Miniature Mass Spectrometer",
    "authors": [
      {
        "name": "Henry W. Rohrs",
        "isPresenter": True,
        "institute": "Mass Sensors, Inc., St. Louis, MO"
      },
      {
        "name": "Rajiv S. Chhatwal",
        "isPresenter": False,
        "institute": "Mass Sensors, Inc., St. Louis, MO"
      },
      {
        "name": "W. Ronald Gentry",
        "isPresenter": False,
        "institute": "Mass Sensors, Inc., St. Louis, MO"
      },
      {
        "name": "Philip S. Berger",
        "isPresenter": False,
        "institute": "Mass Sensors, Inc., St. Louis, MO"
      }
    ],
    "institutes": [
      "Mass Sensors, Inc., St. Louis, MO"
    ],
    "legacy_url": "",
    "legacy_abstract_url": "",
    "poster_file": "",
    "abstract_file": ""
  },
  {
    "date": "2001-03-19",
    "time": "3:30 PM",
    "session": "Poster Session",
    "title": "Project NEREUS: Construction of a practical autonomous underwater gas analyzer",
    "authors": [
      {
        "name": "R. Camilli",
        "isPresenter": True,
        "institute": "Massachusetts Institute of Technology, Cambridge, Ma."
      },
      {
        "name": "H. F. Hemond",
        "isPresenter": False,
        "institute": "Massachusetts Institute of Technology, Cambridge, Ma."
      }
    ],
    "institutes": [
      "Massachusetts Institute of Technology, Cambridge, Ma."
    ],
    "legacy_url": "",
    "legacy_abstract_url": "",
    "poster_file": "",
    "abstract_file": ""
  },
  {
    "date": "2001-03-19",
    "time": "3:30 PM",
    "session": "Poster Session",
    "title": "Remotely Operated Mass Spectrometers: Adaptive Search Platforms for Field Chemical Profiling",
    "authors": [
      {
        "name": "D. P. Fries",
        "isPresenter": True,
        "institute": "The University of South Florida, St. Petersburg, FL"
      },
      {
        "name": "R. T. Short",
        "isPresenter": False,
        "institute": "The University of South Florida, St. Petersburg, FL"
      },
      {
        "name": "G. Kibelka",
        "isPresenter": False,
        "institute": "The University of South Florida, St. Petersburg, FL"
      },
      {
        "name": "M. L. Kerr",
        "isPresenter": False,
        "institute": "The University of South Florida, St. Petersburg, FL"
      },
      {
        "name": "J. Patten",
        "isPresenter": False,
        "institute": "The University of South Florida, St. Petersburg, FL"
      },
      {
        "name": "L. Langebrake",
        "isPresenter": False,
        "institute": "The University of South Florida, St. Petersburg, FL"
      }
    ],
    "institutes": [
      "The University of South Florida, St. Petersburg, FL"
    ],
    "legacy_url": "",
    "legacy_abstract_url": "",
    "poster_file": "",
    "abstract_file": ""
  }
]

updated = False
for ws in data:
    if ws.get('number') == 2:
        ws['posters'] = posters_2001
        updated = True
        break

if updated:
    with open(master_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print("Successfully populated Workshop 2 poster presentations in master_workshops.json.")
else:
    print("Error: Workshop 2 not found!")
