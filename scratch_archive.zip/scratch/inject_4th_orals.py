import json
from bs4 import BeautifulSoup
import re

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
html_path = 'c:/Antigravity/HEMS-website/scratch/4thprogram.html'

with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

sessions = []
current_session = None

dates = {
    'Tuesday': '2003-10-07',
    'Wednesday': '2003-10-08',
    'Thursday': '2003-10-09',
    'Friday': '2003-10-10'
}
current_date = None

for tag in soup.find_all(['h3', 'h4', 'strong', 'tr']):
    if tag.name in ['h3', 'h4']:
        text = tag.get_text(strip=True)
        for day, date_str in dates.items():
            if day in text:
                current_date = date_str
    elif tag.name == 'tr':
        tds = tag.find_all('td')
        if len(tds) >= 2:
            time_str = tds[0].get_text(strip=True)
            content_td = tds[1]
            content_text = content_td.get_text(strip=True)
            
            if 'Technical Session:' in content_text:
                match = re.match(r'(Technical Session:.*?)\((.*?)\)', content_text)
                if match:
                    title = match.group(1).strip()
                    location = match.group(2).strip()
                else:
                    title = content_text
                    location = ""
                
                # Clean up title by removing trailing newlines/spaces
                title = title.replace('\n', ' ').replace('\r', '')
                title = re.sub(r'\s+', ' ', title).strip()
                
                current_session = {
                    "date": current_date,
                    "title": title,
                    "time": time_str,
                    "end_time": "",
                    "location": location,
                    "presentations": []
                }
                sessions.append(current_session)
                continue
            
            # Stop adding to oral presentations if it's a poster session
            if 'Poster Session' in content_text:
                current_session = None
                continue
                
            a_tag = content_td.find('a')
            if a_tag and current_session:
                title = a_tag.get_text(strip=True).strip('“"”')
                url = a_tag.get('href')
                if url and not url.startswith('http'):
                    url = f"https://www.hems-workshop.org/4thWS/{url.lstrip('/')}"
                
                a_tag.extract()
                strong_tag = content_td.find('strong')
                if strong_tag:
                    strong_tag.extract()
                
                em_tag = content_td.find('em')
                institutes = []
                if em_tag:
                    inst_text = em_tag.get_text(strip=True).strip('.,')
                    if inst_text:
                        institutes.append(inst_text)
                    em_tag.extract()
                
                authors_text = content_td.get_text(strip=True).strip('.,')
                authors = []
                if authors_text:
                    parts = re.split(r',|\band\b', authors_text)
                    for i, p in enumerate(parts):
                        name = p.strip()
                        if name:
                            authors.append({
                                "name": name,
                                "isPresenter": (i == 0)
                            })
                
                presentation = {
                    "date": current_date,
                    "time": time_str,
                    "title": title,
                    "authors": authors,
                    "institutes": institutes,
                    "legacy_url": url
                }
                current_session['presentations'].append(presentation)

with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for workshop in data:
    if workshop.get('number') == 4:
        workshop['presentation_sessions'] = sessions
        break

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Updated presentation sessions for 2003 workshop.")
