import json
from bs4 import BeautifulSoup
import re

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
html_path = 'c:/Antigravity/HEMS-website/scratch/4thprogram.html'

with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

soup = BeautifulSoup(html, 'html.parser')

posters = []
in_poster_session = False

def clean_text(text):
    if not text:
        return ""
    text = text.replace('\n', ' ').replace('\r', ' ')
    return re.sub(r'\s+', ' ', text).strip()

def clean_author(name):
    name = clean_text(name)
    name = re.sub(r'\(\d+\)', '', name)
    name = re.sub(r'\d+$', '', name)
    return name.strip(' .,')

for tag in soup.find_all(['h3', 'h4', 'strong', 'tr']):
    if tag.name == 'tr':
        tds = tag.find_all('td')
        if len(tds) >= 2:
            time_str = tds[0].get_text(strip=True)
            content_td = tds[1]
            content_text = content_td.get_text(strip=True)
            
            if 'Poster Session' in content_text:
                in_poster_session = True
                continue
                
            if in_poster_session:
                if 'Evening Free' in content_text or 'Technical Session' in content_text:
                    in_poster_session = False
                    continue
                
                a_tag = content_td.find('a')
                if a_tag:
                    title = clean_text(a_tag.get_text(strip=True).strip('“"”'))
                    url = a_tag.get('href')
                    if url and not url.startswith('http'):
                        url = f"https://www.hems-workshop.org/4thWS/{url.lstrip('/')}"
                    
                    a_tag.extract()
                    strong_tag = content_td.find('strong')
                    if strong_tag:
                        strong_tag.extract()
                    
                    em_tag = content_td.find('em')
                    institutes = []
                    if em_tag:
                        inst_text = clean_text(em_tag.get_text(strip=True).strip('.,'))
                        if inst_text:
                            # Split by (1) etc.
                            parts = re.split(r'\(\d+\)', inst_text)
                            for p in parts:
                                p = p.strip(' ,.')
                                if p and p not in institutes:
                                    institutes.append(p)
                        em_tag.extract()
                    
                    authors_text = content_td.get_text(strip=True).strip('.,')
                    authors = []
                    if authors_text:
                        parts = re.split(r',|\band\b', authors_text)
                        for i, p in enumerate(parts):
                            name = clean_author(p)
                            if 'Institute' in name or 'University' in name or 'Laboratory' in name or 'Corp' in name or 'Inc' in name or 'Center' in name:
                                if name not in institutes:
                                    institutes.append(name)
                            elif name:
                                authors.append({
                                    "name": name,
                                    "isPresenter": False
                                })
                    
                    if authors and not any(a['isPresenter'] for a in authors):
                        authors[0]['isPresenter'] = True
                    
                    poster = {
                        "date": "2003-10-08", # Poster session was on Oct 8
                        "time": "3:30 p.m.",
                        "title": title,
                        "authors": authors,
                        "institutes": institutes,
                        "legacy_url": url
                    }
                    posters.append(poster)

with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for workshop in data:
    if workshop.get('number') == 4:
        workshop['posters'] = posters
        break

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"Updated posters for 2003 workshop. Found {len(posters)} posters.")
