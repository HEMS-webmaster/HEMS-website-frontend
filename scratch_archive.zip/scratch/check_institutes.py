import json

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

w4 = [w for w in data if w['number'] == 4][0]

total_pres = 0
multi_inst = 0
single_inst = 0
no_inst = 0

def check_pres(pres):
    global total_pres, multi_inst, single_inst, no_inst
    total_pres += 1
    insts = pres.get('institutes', [])
    if len(insts) > 1:
        multi_inst += 1
        print(f"MULTI: {pres['title'][:40]}... -> {len(insts)} institutes")
        for a in pres.get('authors', []):
            print(f"  Author: {a['name']}")
    elif len(insts) == 1:
        single_inst += 1
    else:
        no_inst += 1

for session in w4.get('presentation_sessions', []):
    for pres in session.get('presentations', []):
        check_pres(pres)

for pres in w4.get('posters', []):
    check_pres(pres)

print(f"\nTotal: {total_pres}")
print(f"Single Institute: {single_inst}")
print(f"Multi Institute: {multi_inst}")
print(f"No Institute: {no_inst}")
