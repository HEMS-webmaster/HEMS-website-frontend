const fs = require('fs');

const masterPath = './src/frontend/src/data/master_workshops.json';
const newDataPath = './scratch/2005_data.json';

const masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));
const newData = JSON.parse(fs.readFileSync(newDataPath, 'utf8'));

const index = masterData.findIndex(ws => ws.year === "2005");

if (index !== -1) {
  masterData[index] = { ...masterData[index], ...newData };
  fs.writeFileSync(masterPath, JSON.stringify(masterData, null, 2));
  console.log('Successfully updated 2005 data');
} else {
  console.log('Error: 2005 workshop not found');
}
