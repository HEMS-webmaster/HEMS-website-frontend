import os
from PyPDF2 import PdfReader

proceedings_base = r"docs/archives_translation/proceedings"

print("| Filename | Title | Subject | Keywords | Author |")
print("|---|---|---|---|---|")

for root, dirs, files in os.walk(proceedings_base):
    for file in files:
        if file.lower().endswith('_program.pdf') or file.lower().endswith('_participant_list.pdf'):
            path = os.path.join(root, file)
            try:
                reader = PdfReader(path)
                meta = reader.metadata or {}
                title = meta.get('/Title', 'N/A')
                subject = meta.get('/Subject', 'N/A')
                keywords = meta.get('/Keywords', 'N/A')
                author = meta.get('/Author', 'N/A')
                print(f"| {file} | {title} | {subject} | {keywords} | {author} |")
            except Exception as e:
                print(f"| {file} | Error reading: {e} | | | |")
