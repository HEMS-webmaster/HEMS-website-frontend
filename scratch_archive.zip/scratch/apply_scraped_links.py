import re
import json

content_path = r'C:\Users\ryanb\.gemini\antigravity\brain\496ccf2d-440b-41d8-a217-44d060978b41\.system_generated\steps\259\content.md'
with open(content_path, 'r', encoding='utf-8') as f:
    extracted_md = f.read()

# Extract links
links = re.findall(r'\[.*?\]\((.*?)\)', extracted_md)

presentation_links = {}
abstract_orals_links = {}
abstract_posters_links = {}

for link in links:
    m1 = re.search(r'HEMS_Orals_PDF_Alfa/([^.]+)\.pdf', link, re.I)
    if m1:
        presentation_links[m1.group(1).lower()] = link
    
    m2 = re.search(r'Abstracts_orals/([^.]+)\.pdf', link, re.I)
    if m2:
        abstract_orals_links[m2.group(1).lower()] = link
        
    m3 = re.search(r'Abstracts_posters/([^.]+)\.pdf', link, re.I)
    if m3:
        abstract_posters_links[m3.group(1).lower()] = link

# Update Markdown
md_path = r'c:\Antigravity\HEMS-website\source-material\Old site docs\07thWorkshopSummary.md'
with open(md_path, 'r', encoding='utf-8') as f:
    md_lines = f.readlines()

def match_link(authors_str, link_dict):
    authors = [a.strip() for a in authors_str.split(',')]
    for author in authors:
        # Extract last name
        last_name = author.split()[-1].lower()
        if last_name in link_dict:
            return link_dict[last_name]
        # Also try first name if it was a weird formatting
        first_name = author.split()[0].lower()
        if first_name in link_dict:
            return link_dict[first_name]
    return ""

new_md_lines = []
in_orals = False
in_posters = False

for line in md_lines:
    if line.startswith('## 5. Oral Presentation Sessions'):
        in_orals = True
        in_posters = False
    elif line.startswith('## 6. Poster Presentations'):
        in_orals = False
        in_posters = True
    elif line.startswith('## 7. Student Award Presenters'):
        in_orals = False
        in_posters = False
        
    if (in_orals or in_posters) and line.startswith('|') and not line.startswith('| #') and not line.startswith('|:'):
        parts = [p.strip() for p in line.split('|')]
        # Orals has 8 parts, posters has 7 parts
        if in_orals and len(parts) >= 8:
            authors_str = parts[4]
            pres_url = match_link(authors_str, presentation_links)
            abs_url = match_link(authors_str, abstract_orals_links)
            if pres_url:
                parts[6] = f"[URL]({pres_url})"
            if abs_url:
                parts[7] = f"[URL]({abs_url})"
            line = '| ' + ' | '.join(parts[1:-1]) + ' |\n'
        elif in_posters and len(parts) >= 7 and not 'Institute Name' in line and not line.startswith('| Poster'):
            # Posters Table
            # | # | Title | Authors | Presenter | Legacy Poster URL | Legacy Abstract URL |
            # parts is ['', '#', 'Title', 'Authors', 'Presenter', 'Legacy Poster URL', 'Legacy Abstract URL', '']
            authors_str = parts[3]
            abs_url = match_link(authors_str, abstract_posters_links)
            if abs_url:
                parts[6] = f"[URL]({abs_url})"
            line = '| ' + ' | '.join(parts[1:-1]) + ' |\n'
            
    new_md_lines.append(line)

with open(md_path, 'w', encoding='utf-8') as f:
    f.writelines(new_md_lines)

# Update JSON
json_path = r'c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    master = json.load(f)

for ws in master:
    if ws.get('number') == 7:
        for session in ws.get('presentation_sessions', []):
            for pres in session.get('presentations', []):
                authors_str = ",".join([a["name"] for a in pres.get("authors", [])])
                pres_url = match_link(authors_str, presentation_links)
                abs_url = match_link(authors_str, abstract_orals_links)
                if pres_url:
                    pres["url"] = pres_url
                    pres["presentation_file"] = pres_url.split('/')[-1]
                if abs_url:
                    pres["abstract_url"] = abs_url
                    pres["abstract_file"] = abs_url.split('/')[-1]
                    
        for poster in ws.get('posters', []):
            authors_str = ",".join([a["name"] for a in poster.get("authors", [])])
            abs_url = match_link(authors_str, abstract_posters_links)
            if abs_url:
                poster["abstract_url"] = abs_url
                poster["abstract_file"] = abs_url.split('/')[-1]
                
with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(master, f, indent=2)

print("Markdown and JSON updated successfully.")
