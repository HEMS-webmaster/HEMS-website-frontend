import os

path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th\General\3th_Adams_KSC_Miniature_Rugged_Abstract.pdf"

if os.path.exists(path):
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        print("First 300 characters of HTML file disguised as PDF:")
        print(f.read(300))
