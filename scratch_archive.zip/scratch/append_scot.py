import os

scot_content = """

## SCoT Log - 2026-05-27 - Phase 4 (Fixing Improper Workshop Suffixes and Ordinals)

### Current Assessment
The user identified that the workshop titles in the manager navbar and the file naming conventions use improper ordinal suffixes (e.g., `1th`, `2th`, `3th` instead of `1st`, `2nd`, `3rd`).
This error spans across:
1. The physical directory structure: folders on disk are named `1th/`, `2th/`, and `3th/`.
2. The physical files inside: files are named `1th_...`, `2th_...`, and `3th_...`.
3. The master database `master_workshops.json` which references these file paths.
4. The manager frontend dashboard (`page.tsx`) and backend API routes (`upload`, `save`, `serve`, `PreviewHover`) which have hardcoded `th` suffix logic (e.g. `${wsNum}th`).

### Plan
1. Create a Python script `scratch/fix_incorrect_ordinals.py` to:
   - Rename local proceedings directories: `1th` -> `1st`, `2th` -> `2nd`, `3th` -> `3rd`.
   - Rename all filenames starting with `1th_`, `2th_`, or `3th_` to start with `1st_`, `2nd_`, or `3rd_`.
   - Read `master_workshops.json` and replace all references to `1th_`, `2th_`, and `3th_` with `1st_`, `2nd_`, and `3rd_`.
   - Overwrite `master_workshops.json` with the updated paths.
2. Edit `src/frontend/src/app/manager/page.tsx` to display proper ordinal suffixes in the sidebar list (e.g. `3rd Workshop` instead of `3th Workshop`) and use the correct ordinal naming when adding a workshop or serving a file link.
3. Edit the manager API routes to use the `getOrdinal` calculation instead of the hardcoded `${wsNum}th` logic:
   - `src/frontend/src/app/api/manager/upload/route.ts`
   - `src/frontend/src/app/api/manager/save/route.ts`
   - `src/frontend/src/app/manager/components/PreviewHover.tsx`
4. Re-compile the SEO registry and re-run metadata injection.

### Constraints Check
- No forbidden words (such as leverage, utilize, robust, seamless, furthermore, moreover) are present in this trace or will be used in any files.
"""

trace_path = r"c:\Antigravity\HEMS-website\docs\logs\thought_trace.md"

try:
    with open(trace_path, "a", encoding="utf-8") as f:
        f.write(scot_content)
    print("Successfully appended SCoT log to docs/logs/thought_trace.md")
except Exception as e:
    print(f"Error appending SCoT log: {e}")
