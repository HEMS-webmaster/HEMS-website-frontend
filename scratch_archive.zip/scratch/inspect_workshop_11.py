import json

with open('src/frontend/src/data/master_workshops.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for ws in data:
    if ws.get('number') == 2:
        sessions = ws.get('presentation_sessions', [])
        print("Number of sessions:", len(sessions))
        if sessions:
            print("First session sample:")
            print(json.dumps(sessions[0], indent=2))
        break
