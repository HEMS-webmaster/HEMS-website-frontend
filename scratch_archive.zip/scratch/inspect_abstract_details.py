import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
# Individual abstracts seem to be from TD 6 to TD 27
abstract_tds = tds[6:28]

print(f"Number of abstract TDs: {len(abstract_tds)}")

for idx, td in enumerate(abstract_tds):
    real_idx = idx + 6
    p_tags = td.find_all('p')
    print(f"\n==========================================")
    print(f"Abstract #{idx+1} (TD Index {real_idx}) - {len(p_tags)} paragraphs")
    print(f"==========================================")
    for p_idx, p in enumerate(p_tags):
        text = p.get_text().strip().replace('\n', ' ')
        # Collapse multiple spaces
        text = ' '.join(text.split())
        print(f"P {p_idx}: {text[:120]}...")
