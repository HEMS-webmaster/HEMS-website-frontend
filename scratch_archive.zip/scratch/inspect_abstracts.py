import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
print(f"Total TDs found: {len(tds)}")

# Let's inspect tds that look like abstracts
for i, td in enumerate(tds):
    p_tags = td.find_all('p')
    # If a TD contains more than 1 paragraph, and has some bold/italic elements, it might be an abstract
    if len(p_tags) >= 2:
        bold_tags = td.find_all('b')
        italic_tags = td.find_all('i')
        if bold_tags and italic_tags:
            print(f"\n--- TD Index {i} ---")
            print(f"Bold content: {[b.get_text().strip() for b in bold_tags[:2]]}")
            print(f"Italic content: {[it.get_text().strip() for it in italic_tags[:2]]}")
            print(f"Number of paragraphs: {len(p_tags)}")
            for j, p in enumerate(p_tags):
                print(f"  Paragraph {j} text (first 100 chars): {p.get_text().strip()[:100]}")
