import json

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws3 = None
for ws in data:
    if ws.get('number') == 3:
        ws3 = ws
        break

if not ws3:
    print("Error: 3rd workshop not found in database.")
    exit(1)

# Session I (index 0)
s1 = ws3['presentation_sessions'][0]
p2 = s1['presentations'][1] # Mahaffy
p3 = s1['presentations'][2] # Ottens

print("Before updates:")
print(f"  Mahaffy: abstract_file={repr(p2.get('abstract_file'))}")
print(f"  Ottens: abstract_file={repr(p3.get('abstract_file'))}")

p2['abstract_file'] = '3rd_Mahaffy_Mass_Spectrometers_in_Abstract.pdf'
p3['abstract_file'] = '3rd_Ottens_Quadrupole_Ion_Trap_Abstract.pdf'

# Session III (index 2)
s3 = ws3['presentation_sessions'][2]
p4 = s3['presentations'][3] # Eckenrode
print(f"  Eckenrode: abstract_file={repr(p4.get('abstract_file'))}")

p4['abstract_file'] = '3rd_Eckenrode_Addressing_Forensic_Field_Abstract.pdf'

print("\nAfter updates:")
print(f"  Mahaffy: abstract_file={repr(p2['abstract_file'])}")
print(f"  Ottens: abstract_file={repr(p3['abstract_file'])}")
print(f"  Eckenrode: abstract_file={repr(p4['abstract_file'])}")

# Save master workshops
with open(master_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("\nSuccessfully updated master_workshops.json!")
