import json
import re

md_path = 'c:/Antigravity/HEMS-website/source-material/Old site docs/03thWorkshopSummary.md'
json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'

with open(md_path, 'r', encoding='utf-8') as f:
    md_content = f.read()

def extract_table_val(field):
    m = re.search(rf'\|\s*{field}\s*\|\s*(.*?)\s*\|', md_content)
    if m:
        val = m.group(1).strip()
        return val if val != 'UNKNOWN' else ""
    return ""

dates = extract_table_val('Dates')
city = extract_table_val('City')
venue_name = extract_table_val('Venue Name')
venue_address = extract_table_val('Venue Address')
venue_url = extract_table_val('Venue URL')
venue_address_url = extract_table_val('Venue Address URL')

host_match = re.search(r'## 2\. Host Corporation.*?Name\s*\|\s*(.*?)\s*\|.*?URL\s*\|\s*(.*?)\s*\|', md_content, re.DOTALL)
host_name = ""
host_url = ""
if host_match:
    host_name = host_match.group(1).strip()
    host_url_raw = host_match.group(2).strip()
    link_m = re.search(r'\[.*?\]\((.*?)\)', host_url_raw)
    if link_m:
        host_url = link_m.group(1).strip()
    else:
        host_url = host_url_raw

host_name = host_name if host_name != 'UNKNOWN' else ""
host_url = host_url if host_url != 'UNKNOWN' else ""

with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

for w in data:
    if str(w.get('number')) == '3':
        w['year'] = "2002"
        w['dates'] = dates
        w['location'] = city
        w['venue'] = {
            "name": venue_name,
            "address": venue_address,
            "url": venue_url,
            "address_url": venue_address_url
        }
        if host_name:
            w['host_corporation'] = {
                "name": host_name,
                "url": host_url
            }
        else:
            w['host_corporation'] = None
        
        if 'sponsors' not in w:
            w['sponsors'] = []
            
        print("Updated Workshop 3 with:")
        print(f"Dates: {w['dates']}")
        print(f"Location: {w['location']}")
        print(f"Venue: {w['venue']}")
        print(f"Host: {w['host_corporation']}")
        break

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)
