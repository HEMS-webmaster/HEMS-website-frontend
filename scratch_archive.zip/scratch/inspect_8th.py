import os

path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\8th"
all_files = []
for root, dirs, files in os.walk(path):
    for file in files:
        if file.lower().endswith(".pdf"):
            rel_path = os.path.relpath(os.path.join(root, file), path)
            all_files.append(rel_path)

print(f"Found {len(all_files)} PDFs in 8th workshop proceedings:")
for f in sorted(all_files):
    print(f"  {f}")
