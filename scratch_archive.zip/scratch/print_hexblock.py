import json
import sys

# Ensure stdout uses utf-8
sys.stdout.reconfigure(encoding='utf-8')

chunks_path = r"c:\Antigravity\HEMS-website\src\frontend\public\mock-pdf-chunks.json"
try:
    with open(chunks_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    matches = []
    for item in data:
        text = json.dumps(item).lower()
        if 'hexblock' in text:
            matches.append(item)
            
    print(f"Found {len(matches)} matches for 'Hexblock' in mock-pdf-chunks.json:")
    for m in matches:
        print(f"ObjectID: {m.get('objectID')}")
        print(f"Title: {m.get('title')}")
        print(f"Type: {m.get('content_type')}")
        print(f"Slide/Abstract page: {m.get('slide_number')}")
        print(f"Text content:\n{m.get('text_content')}")
        print("-" * 50)
except Exception as e:
    print(f"Error: {e}")
