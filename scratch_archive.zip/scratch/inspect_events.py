import json

with open('src/frontend/src/data/master_workshops.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

for ws in data:
    if ws.get('number') == 2:
        print(json.dumps(ws.get('events'), indent=2))
        break
