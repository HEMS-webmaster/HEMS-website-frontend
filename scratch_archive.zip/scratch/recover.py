import json
import os

def main():
    log_path = r"C:\Users\ryanb\.gemini\antigravity-ide\brain\c68278c9-9926-4d9b-a048-9feaef8860bf\.system_generated\logs\transcript.jsonl"
    recovered_path = r"c:\Antigravity\HEMS-website\scratch\recovered_generator.py"
    
    if not os.path.exists(log_path):
        print(f"Log path does not exist: {log_path}")
        return
        
    print(f"Opening log file: {log_path}")
    with open(log_path, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)
                if data.get("step_index") == 158:
                    print("Found step 158!")
                    tool_calls = data.get("tool_calls", [])
                    if tool_calls:
                        code_content = tool_calls[0]["args"].get("CodeContent")
                        if code_content:
                            with open(recovered_path, 'w', encoding='utf-8') as out_f:
                                out_f.write(code_content)
                            print(f"Successfully recovered code to {recovered_path}")
                            return
                        else:
                            print("CodeContent not found in tool call arguments.")
                    else:
                        print("No tool calls found in step 158.")
            except Exception as e:
                # Some lines might be malformed or something, ignore
                pass

if __name__ == "__main__":
    main()
