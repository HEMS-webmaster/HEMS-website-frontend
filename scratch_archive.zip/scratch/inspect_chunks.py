import json

chunks_path = r"c:\Antigravity\HEMS-website\src\frontend\public\mock-pdf-chunks.json"
try:
    with open(chunks_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"Loaded {len(data)} chunks from mock database.")
    
    matches = []
    for item in data:
        text = json.dumps(item).lower()
        if 'wright' in text:
            matches.append(item)
            
    print(f"Found {len(matches)} matches for 'Wright' in mock-pdf-chunks.json:")
    for m in matches[:10]:
        print(f"ObjectID: {m.get('objectID')}, Title: {m.get('title')}, Authors: {m.get('authors')}")
        if 'Hexblock' in json.dumps(m):
            print("  [FOUND HEXBLOCK IN THIS CHUNK!]")
except Exception as e:
    print(f"Error: {e}")
