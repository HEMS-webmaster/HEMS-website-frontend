import json

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

def get_ordinal(n):
    try:
        n = int(n)
        if 11 <= (n % 100) <= 13:
            suffix = 'th'
        else:
            suffix = ['th', 'st', 'nd', 'rd', 'th'][min(n % 10, 4)]
        return str(n) + suffix
    except ValueError:
        return str(n) + "th"

updated_count = 0
for w in data:
    num = w.get('number')
    if num:
        ordinal = get_ordinal(num)
        w['title'] = f"{ordinal} HEMS Workshop"
        w['tagline'] = f"The {ordinal} Workshop on Harsh-Environment Mass Spectrometry."
        updated_count += 1

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"Updated {updated_count} workshops with title and tagline.")
