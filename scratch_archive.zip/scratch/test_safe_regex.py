import re

test_cases = [
    "1th_Program.pdf",
    "11th_Program.pdf",
    "2th_Beauchamp.pdf",
    "12th_Beauchamp.pdf",
    "3th_Muntz.pdf",
    "13th_Muntz.pdf",
    "/serve?file=3th/Administrative/3th_Program.pdf",
    "/serve?file=13th/Administrative/13th_Program.pdf"
]

print("=== Testing Safe Regex Replacements ===")
for tc in test_cases:
    # Safe regex replacements
    fixed = re.sub(r'(?<!\d)1th_', '1st_', tc)
    fixed = re.sub(r'(?<!\d)2th_', '2nd_', fixed)
    fixed = re.sub(r'(?<!\d)3th_', '3rd_', fixed)
    
    fixed = re.sub(r'(?<!\d)1th/', '1st/', fixed)
    fixed = re.sub(r'(?<!\d)2th/', '2nd/', fixed)
    fixed = re.sub(r'(?<!\d)3th/', '3rd/', fixed)
    
    print(f"Original: {tc} -> Fixed: {fixed}")
