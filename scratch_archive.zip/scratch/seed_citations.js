const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "../src/frontend/src/data/master_workshops.json");
const data = JSON.parse(fs.readFileSync(dbPath, "utf8"));

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-") // Replace spaces with -
    .replace(/[^\w\-]+/g, "") // Remove all non-word chars
    .replace(/\-\-+/g, "-") // Replace multiple - with single -
    .replace(/^-+/, "") // Trim - from start of text
    .replace(/-+$/, ""); // Trim - from end of text
}

function getLastName(fullName) {
  if (!fullName || fullName === "UNKNOWN") return "unknown";
  const parts = fullName.trim().split(/\s+/);
  return parts[parts.length - 1];
}

function getFirstWords(title, count = 3) {
  if (!title) return "untitled";
  const words = title.trim().split(/\s+/).slice(0, count).join(" ");
  return words;
}

data.forEach((workshop) => {
  const year = workshop.year;
  const seenIds = new Set();

  function makeUniqueId(baseId) {
    let uniqueId = baseId;
    let counter = 1;
    while (seenIds.has(uniqueId)) {
      uniqueId = `${baseId}-${counter}`;
      counter++;
    }
    seenIds.add(uniqueId);
    return uniqueId;
  }

  // Seeding presentations
  if (Array.isArray(workshop.presentation_sessions)) {
    workshop.presentation_sessions.forEach((session) => {
      if (Array.isArray(session.presentations)) {
        session.presentations.forEach((pres) => {
          const presenterLast = slugify(getLastName(pres.presenter));
          const titleSlug = slugify(getFirstWords(pres.title, 4));
          const baseId = `${year}-pres-${presenterLast}-${titleSlug}`;
          pres.id = makeUniqueId(baseId);
        });
      }
    });
  }

  // Seeding posters
  if (Array.isArray(workshop.posters)) {
    workshop.posters.forEach((poster) => {
      // Find presenter from authors list or default
      let presenterName = "unknown";
      if (Array.isArray(poster.authors)) {
        const presenterObj = poster.authors.find(a => a.isPresenter);
        if (presenterObj && presenterObj.name) {
          presenterName = presenterObj.name;
        } else if (poster.authors[0] && poster.authors[0].name) {
          presenterName = poster.authors[0].name;
        }
      }
      const presenterLast = slugify(getLastName(presenterName));
      const titleSlug = slugify(getFirstWords(poster.title, 4));
      const baseId = `${year}-poster-${presenterLast}-${titleSlug}`;
      poster.id = makeUniqueId(baseId);
    });
  }
});

fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf8");
console.log("Successfully seeded unique IDs to master_workshops.json");
