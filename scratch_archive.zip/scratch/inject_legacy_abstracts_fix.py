import json
import re
import difflib

md_path = 'c:/Antigravity/HEMS-website/source-material/Old site docs/4thWorkshop Legacyabstracts.md'
with open(md_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

abstract_urls = {}
for line in lines:
    if line.startswith('|') and not line.startswith('| :---') and not line.startswith('| Presentation Title') and not line.startswith('| Title'):
        parts = [p.strip() for p in line.split('|')]
        parts = [p for p in parts if p]
        
        if len(parts) >= 4:
            title = parts[0].strip()
            url = parts[-1].strip()
            
            if 'Miniaturized Confocal Plane Mass Spectrometer' in title:
                title = 'Miniaturized Confocal Plane Mass Spectrometer (or "How to Start a Company ")'
                
            title = re.sub(r'\*\*', '', title)
            title = title.replace('"', '').strip()
            
            if url != 'N/A' and 'Link Broken' not in url:
                abstract_urls[title] = url

json_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(json_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws4 = None
for w in data:
    if w.get('number') == 4:
        ws4 = w
        break

matched_count = 0

def process_presentation(pres):
    global matched_count
    pres_title = pres.get('title', '')
    
    best_match = None
    best_ratio = 0
    
    for md_title, url in abstract_urls.items():
        ratio = difflib.SequenceMatcher(None, pres_title.lower(), md_title.lower()).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = (md_title, url)
            
    if best_ratio > 0.6:
        matched_count += 1
        # Set legacy_abstract_url instead of legacy_url
        pres['legacy_abstract_url'] = best_match[1]
        print(f"Matched ({best_ratio:.2f}): {pres_title[:50]} -> {best_match[1]}")

for session in ws4.get('presentation_sessions', []):
    for pres in session.get('presentations', []):
        process_presentation(pres)

for pres in ws4.get('posters', []):
    process_presentation(pres)

with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print(f"\nUpdated {matched_count} legacy_abstract_urls.")
