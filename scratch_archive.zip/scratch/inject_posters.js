const fs = require('fs');
const dataPath = 'src/frontend/src/data/master_workshops.json';
const masterData = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
const ws13 = masterData.find(w => w.number == 13);

const DATE_17 = "Tuesday, September 17, 2019: HEMS Workshop";

ws13.posters = [
  {
    "title": "Determination of the Presence of Biological Compounds in Aerosol Particles with a Linear Ion Trap",
    "presentation_file": "13th_Grimes_Determination_Poster.pdf",
    "abstract_file": "13th_Grimes_Determination_Abstract.pdf",
    "authors": [
      {
        "name": "Nathan Grimes",
        "isPresenter": true,
        "affiliation": ""
      }
    ],
    "date": DATE_17,
    "time": "16:00",
    "session": "Poster Session"
  },
  {
    "title": "Overview of the MOMA Mass Spectrometer and Examination of Some Mineral Matrices as Learning Curve for MOMA Return Data",
    "presentation_file": "13th_Amerom_Overview_Poster.pdf",
    "abstract_file": "13th_Amerom_Overview_Abstract.pdf",
    "authors": [
      {
        "name": "F. H. W. van Amerom",
        "isPresenter": true,
        "affiliation": ""
      }
    ],
    "date": DATE_17,
    "time": "16:00",
    "session": "Poster Session"
  },
  {
    "title": "A Comparison of Thermionic Filament and Carbon Nanotube Field Emitter Array-based Ion Sources in Coded Aperture Miniature Mass Spectrometers",
    "presentation_file": "13th_Vyas_Comparison_Poster.pdf",
    "abstract_file": "13th_Vyas_Comparison_Abstract.pdf",
    "authors": [
      {
        "name": "Raul Vyas",
        "isPresenter": true,
        "affiliation": ""
      }
    ],
    "date": DATE_17,
    "time": "16:00",
    "session": "Poster Session"
  },
  {
    "title": "In-situ Measurements of δ13C and δ18O of Dissolved CO2 using an Underwater Mass Spectrometer",
    "presentation_file": "13th_Wieman_Insitu_Poster.pdf",
    "abstract_file": "13th_Wieman_Insitu_Abstract.pdf",
    "authors": [
      {
        "name": "Scott T. Wieman",
        "isPresenter": true,
        "affiliation": ""
      }
    ],
    "date": DATE_17,
    "time": "16:00",
    "session": "Poster Session"
  }
];

fs.writeFileSync(dataPath, JSON.stringify(masterData, null, 2));
console.log('Fixed posters with clean titles, dates, and times!');
