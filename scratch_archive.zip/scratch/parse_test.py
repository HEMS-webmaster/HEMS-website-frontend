import urllib.request
from bs4 import BeautifulSoup

url = 'https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdhemstalks.htm'
html = urllib.request.urlopen(url).read().decode('latin-1')
soup = BeautifulSoup(html, 'html.parser')

tds = soup.find_all('td')
abstract_tds = tds[6:28]

for idx, td in enumerate(abstract_tds):
    real_idx = idx + 6
    p_tags = td.find_all('p')
    if not p_tags:
        continue
    p0 = p_tags[0]
    title_tag = p0.find(['b', 'strong'])
    
    # Get all text after title_tag
    authors_institutes_str = ""
    if title_tag:
        curr = title_tag.next_sibling
        while curr:
            authors_institutes_str += curr.get_text() if hasattr(curr, 'get_text') else str(curr)
            curr = curr.next_sibling
    else:
        authors_institutes_str = p0.get_text()
        
    # Clean up spaces
    authors_institutes_str = ' '.join(authors_institutes_str.split()).strip()
    title_str = ' '.join(title_tag.get_text().split()).strip() if title_tag else p0.get_text().strip()
    
    # Strip leading/trailing quotes from title
    title_str = title_str.strip('"').strip("'").strip('“').strip('”')
    
    print(f"\n[{real_idx}] TITLE: {title_str}")
    print(f"    AUTHORS/INSTITUTES RAW: {authors_institutes_str}")
