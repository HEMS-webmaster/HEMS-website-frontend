import json
import os

master_path = 'src/frontend/src/data/master_workshops.json'

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Define presentation sessions for the 15th HEMS workshop (2025)
presentation_sessions_15 = [
  {
    "session_title": "Technical Session I",
    "title": "Technical Session I",
    "date": "2025-09-16",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "10:00 a.m.",
        "end_time": "",
        "title": "Using Classes of Molecules to Identify Air Health",
        "authors": [
          {
            "name": "Guido Verbeck",
            "isPresenter": True,
            "institute": "Augusta University"
          }
        ],
        "presenter": "Guido Verbeck",
        "presenter_initials": "G. V.",
        "institutes": [
          "Augusta University"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "10:30 a.m.",
        "end_time": "",
        "title": "ARAMMIS: Autonomous Robots for Area Mapping, Monitoring and In-situ gas Sensing, focused on Lunar exploration and Earth Science applications",
        "authors": [
          {
            "name": "James Fox",
            "isPresenter": True,
            "institute": "INFICON ISS Emerging Technologies and New Markets Research Group"
          }
        ],
        "presenter": "James Fox",
        "presenter_initials": "J. F.",
        "institutes": [
          "INFICON ISS Emerging Technologies and New Markets Research Group"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "11:00 a.m.",
        "end_time": "",
        "title": "A cart-portable TOF-MS coupled with a thermal desorber for in-field analysis of CBRNE threat materials",
        "authors": [
          {
            "name": "Bett Kimutai",
            "isPresenter": True,
            "institute": "Canadian Nuclear Laboratories"
          }
        ],
        "presenter": "Bett Kimutai",
        "presenter_initials": "B. K.",
        "institutes": [
          "Canadian Nuclear Laboratories"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "11:30 a.m.",
        "end_time": "",
        "title": "Spaceflight Laser Desorption Orbitrap Mass Spectrometry",
        "authors": [
          {
            "name": "Madeline Raith",
            "isPresenter": True,
            "institute": "University of Maryland, College Park"
          }
        ],
        "presenter": "Madeline Raith",
        "presenter_initials": "M. R.",
        "institutes": [
          "University of Maryland, College Park"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session II",
    "title": "Technical Session II",
    "date": "2025-09-16",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "2:00 p.m.",
        "end_time": "",
        "title": "A rugged and field deployable multi-laser resonance Single Particle Mass Spectrometer: Ship-based detection of trace metal-containing aerosols in the atmosphere of the Indian Ocean",
        "authors": [
          {
            "name": "Aleksandrs Kalamasnikovs",
            "isPresenter": True,
            "institute": "University of Rostock"
          }
        ],
        "presenter": "Aleksandrs Kalamasnikovs",
        "presenter_initials": "A. K.",
        "institutes": [
          "University of Rostock"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "2:30 p.m.",
        "end_time": "",
        "title": "Non-proximate, Handheld Probe with Positional Feedback for Real-time Analysis of Three-dimensional Object Surfaces",
        "authors": [
          {
            "name": "G. Asher Newsome",
            "isPresenter": True,
            "institute": "Smithsonian Museum Conservation Institute"
          }
        ],
        "presenter": "G. Asher Newsome",
        "presenter_initials": "G. A. N.",
        "institutes": [
          "Smithsonian Museum Conservation Institute"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session III",
    "title": "Technical Session III",
    "date": "2025-09-16",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "3:30 p.m.",
        "end_time": "",
        "title": "2D MS/MS using a small ion trap mass spectrometer",
        "authors": [
          {
            "name": "Joseph Caruso",
            "isPresenter": True,
            "institute": "Purdue University"
          }
        ],
        "presenter": "Joseph Caruso",
        "presenter_initials": "J. C.",
        "institutes": [
          "Purdue University"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "4:00 p.m.",
        "end_time": "",
        "title": "Instrument Simulation --Why, What to Expect, What tools to use",
        "authors": [
          {
            "name": "Bob Jackson",
            "isPresenter": True,
            "institute": "Ashwood Labs"
          }
        ],
        "presenter": "Bob Jackson",
        "presenter_initials": "B. J.",
        "institutes": [
          "Ashwood Labs"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session IV",
    "title": "Technical Session IV",
    "date": "2025-09-17",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "8:30 a.m.",
        "end_time": "",
        "title": "Novel ship-based and submersible Membrane Inlet-Photo-Ionization Mass Spectrometer (MI-PIMS) for on-line detection of fuel spills, environmental contaminants and TNT in sea water",
        "authors": [
          {
            "name": "Ralf Zimmermann",
            "isPresenter": True,
            "institute": "University of Rostock, Helmholtz Zentrum München"
          }
        ],
        "presenter": "Ralf Zimmermann",
        "presenter_initials": "R. Z.",
        "institutes": [
          "University of Rostock, Helmholtz Zentrum München"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "9:00 a.m.",
        "end_time": "",
        "title": "Simultaneous MIMS and UV/VIS absorption for chemical reaction kinetic studies exemplified by disinfection byproduct formation from environmental contaminants",
        "authors": [
          {
            "name": "Frants Lauritsen",
            "isPresenter": True,
            "institute": "University of Southern Denmark"
          }
        ],
        "presenter": "Frants Lauritsen",
        "presenter_initials": "F. L.",
        "institutes": [
          "University of Southern Denmark"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "9:30 a.m.",
        "end_time": "",
        "title": "SPion®: Flexible Ion Guide for Mass Spectrometry",
        "authors": [
          {
            "name": "Mazdak Taghioskoui",
            "isPresenter": True,
            "institute": "Trace Matters"
          }
        ],
        "presenter": "Mazdak Taghioskoui",
        "presenter_initials": "M. T.",
        "institutes": [
          "Trace Matters"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session V",
    "title": "Technical Session V",
    "date": "2025-09-17",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "10:30 a.m.",
        "end_time": "",
        "title": "Design and Performance of a Person-portable Two-dimensional Tandem Mass Spectrometer for Machine-Learning Enhanced Identification of Threats",
        "authors": [
          {
            "name": "Dalton Snyder",
            "isPresenter": True,
            "institute": "Teledyne FLIR Detection"
          }
        ],
        "presenter": "Dalton Snyder",
        "presenter_initials": "D. S.",
        "institutes": [
          "Teledyne FLIR Detection"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "11:00 a.m.",
        "end_time": "",
        "title": "Integration of the Submersible Under-Ice Mass Spectrometer (SUIMS) with the Icefin ROV for Dissolved Gas Measurements at the Grounding Zone of a Marine-Terminating Glacier",
        "authors": [
          {
            "name": "Jorge Coppin-Massanet",
            "isPresenter": True,
            "institute": "Cornell Universiity"
          }
        ],
        "presenter": "Jorge Coppin-Massanet",
        "presenter_initials": "J. C.",
        "institutes": [
          "Cornell Universiity"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Sessions VI",
    "title": "Technical Sessions VI",
    "date": "2025-09-17",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "1:30 p.m.",
        "end_time": "",
        "title": "A New Aerosol Threat Detector",
        "authors": [
          {
            "name": "Gottfried Kibelka",
            "isPresenter": True,
            "institute": "Detect-ION"
          }
        ],
        "presenter": "Gottfried Kibelka",
        "presenter_initials": "G. K.",
        "institutes": [
          "Detect-ION"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "2:00 p.m.",
        "end_time": "",
        "title": "Multimodal Ionization Strategies for Broad-Spectrum Threat Detection with a Miniature Field Mass Spectrometer",
        "authors": [
          {
            "name": "Nathan Grimes",
            "isPresenter": True,
            "institute": "BaySepc, Inc"
          }
        ],
        "presenter": "Nathan Grimes",
        "presenter_initials": "N. G.",
        "institutes": [
          "BaySepc, Inc"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Sessions VII",
    "title": "Technical Sessions VII",
    "date": "2025-09-17",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "3:00 p.m.",
        "end_time": "",
        "title": "Vertical transport of biogenic CO2, O2 and DO2/Ar in eddies and at fronts is revealed by submersible mass spectrometer",
        "authors": [
          {
            "name": "Brice Loose",
            "isPresenter": True,
            "institute": "URI Graduate School of Oceanography"
          }
        ],
        "presenter": "Brice Loose",
        "presenter_initials": "B. L.",
        "institutes": [
          "URI Graduate School of Oceanography"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "3:30 p.m.",
        "end_time": "",
        "title": "Development of the Dragonfly Mass Spectrometer (DraMS) for Titan",
        "authors": [
          {
            "name": "Desmond Kaplan",
            "isPresenter": True,
            "institute": "KapScience LLC"
          }
        ],
        "presenter": "Desmond Kaplan",
        "presenter_initials": "D. K.",
        "institutes": [
          "KapScience LLC"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session VIII",
    "title": "Technical Session VIII",
    "date": "2025-09-18",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "8:30 a.m.",
        "end_time": "",
        "title": "Standoff Laser Ablation Mass Analyzer (LAMA) for Lunar Surface Analysis",
        "authors": [
          {
            "name": "Xiang Li",
            "isPresenter": True,
            "institute": "NASA Goddard Space Flight Center"
          }
        ],
        "presenter": "Xiang Li",
        "presenter_initials": "X. L.",
        "institutes": [
          "NASA Goddard Space Flight Center"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "9:00 a.m.",
        "end_time": "",
        "title": "Under Water Coded Aperture Miniature Mass Spectrometer for Measurements of Methane Content in the Ocean",
        "authors": [
          {
            "name": "Raphael Bento Serpa",
            "isPresenter": True,
            "institute": "Duke University"
          },
          {
            "name": "Jason Amsden",
            "isPresenter": True,
            "institute": "Department of Electrical and Computer Engin"
          }
        ],
        "presenter": "Raphael Bento Serpa or Jason Amsden",
        "presenter_initials": "R. B. S. / J. A.",
        "institutes": [
          "Duke University",
          "Department of Electrical and Computer Engin"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "9:30 a.m.",
        "end_time": "",
        "title": "Extraterrestrial Molecular Indicators of Life Investigation (EMILI): Development of Flight-Like Prototype",
        "authors": [
          {
            "name": "William Brinkerhoff",
            "isPresenter": True,
            "institute": "NASA Goddard Space Flight Center"
          }
        ],
        "presenter": "William Brinkerhoff",
        "presenter_initials": "W. B.",
        "institutes": [
          "NASA Goddard Space Flight Center"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  },
  {
    "session_title": "Technical Session IX (labeled Technical Session IV)",
    "title": "Technical Session IX (labeled Technical Session IV)",
    "date": "2025-09-18",
    "location": "Ocean Grand Ballroom - Cape Charles",
    "presentations": [
      {
        "time": "10:30 a.m.",
        "end_time": "",
        "title": "Underwater Mass Spectrometry Advancements for Real-time Geochemical Analysis of Deep-sea Cold Seeps",
        "authors": [
          {
            "name": "Ryan Bell",
            "isPresenter": True,
            "institute": "Beaver Creek Analytical, LLC"
          }
        ],
        "presenter": "Ryan Bell",
        "presenter_initials": "R. B.",
        "institutes": [
          "Beaver Creek Analytical, LLC"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "11:00 a.m.",
        "end_time": "",
        "title": "Concurrent Cloud Distributed Simulation with Space Charge using SIMION",
        "authors": [
          {
            "name": "Mark Osgood",
            "isPresenter": True,
            "institute": "Ashwood Labs"
          }
        ],
        "presenter": "Mark Osgood",
        "presenter_initials": "M. O.",
        "institutes": [
          "Ashwood Labs"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      },
      {
        "time": "11:30 a.m.",
        "end_time": "",
        "title": "Surface Induced Dissociation (SID) with Quadrupole Mass Filters: MS/MS without Collision Gas",
        "authors": [
          {
            "name": "Randy Pedder",
            "isPresenter": True,
            "institute": "Adara Technologies, LP"
          }
        ],
        "presenter": "Randy Pedder",
        "presenter_initials": "R. P.",
        "institutes": [
          "Adara Technologies, LP"
        ],
        "legacy_url": "",
        "legacy_abstract_url": "",
        "url": "",
        "abstract_url": "",
        "presentation_file": "",
        "abstract_file": ""
      }
    ]
  }
]

found = False
for ws in data:
    if ws.get('number') == 15:
        ws['presentation_sessions'] = presentation_sessions_15
        found = True
        break

if found:
    with open(master_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print("Successfully populated presentation sessions for HEMS Workshop 15 in master_workshops.json")
else:
    print("Error: HEMS Workshop 15 not found in master_workshops.json")
