import json
import re

def parse_markdown():
    with open('source-material/Old site docs/06thWorkshopSummary.md', 'r', encoding='utf-8') as f:
        lines = f.readlines()

    ws = {
        "number": 6,
        "year": "2007",
        "city": "Cocoa Beach, Florida",
        "venue": "Holiday Inn Cocoa Beach",
        "dates": "September 17-20, 2007",
        "sponsors": [],
        "student_awards": [],
        "posters": [],
        "presentation_sessions": [],
        "events": [],
        "venue_address": "",
        "program_url": "HEMS_2007_Program.pdf",
        "program_file": "HEMS_2007_Program.pdf",
        "participant_list_url": "Participants.pdf",
        "participant_list_file": "Participants.pdf",
        "venue_address_url": "",
        "address": "",
        "venue_url": ""
    }

    current_section = ""
    current_session = None
    current_date = ""

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line.startswith("## "):
            current_section = line[3:]
            continue

        if current_section == "3. Corporate Sponsors":
            if line.startswith("|") and not line.startswith("| # |") and not line.startswith("|:--"):
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 4:
                    company = parts[2]
                    url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[3])
                    url = url_match.group(2) if url_match else parts[3]
                    if url == "UNKNOWN": url = ""
                    ws["sponsors"].append({
                        "company": company,
                        "url": url,
                        "logo_file": ""
                    })

        elif current_section == "4. Itinerary Events":
            if line.startswith("### "):
                # e.g. ### 2007-09-17 — Travel Day
                current_date = line[4:].split("—")[0].strip()
            elif line.startswith("|") and not line.startswith("| Start Time") and not line.startswith("|:-"):
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 6:
                    ws["events"].append({
                        "time": parts[1],
                        "end_time": parts[2],
                        "title": parts[3],
                        "subtitle": parts[4],
                        "location": parts[5],
                        "date": current_date
                    })

        elif current_section == "5. Oral Presentation Sessions":
            if line.startswith("### Session: "):
                if current_session:
                    ws["presentation_sessions"].append(current_session)
                current_session = {
                    "session_title": line.replace("### Session: ", "").strip(),
                    "date": "",
                    "presentations": []
                }
            elif line.startswith("- **Date:** ") and current_session:
                current_session["date"] = line.replace("- **Date:** ", "").strip()
            elif line.startswith("|") and not line.startswith("| #") and not line.startswith("|:-") and not line.startswith("| Talk #"):
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 8 and current_session:
                    presenter_str = parts[5].replace("[PRESENTER]", "").replace("**", "").strip()
                    pres_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[6])
                    pres_url = pres_url_match.group(2) if pres_url_match else parts[6]
                    abs_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[7])
                    abs_url = abs_url_match.group(2) if abs_url_match else parts[7]
                    
                    # Parse authors string into array of objects
                    authors_str = parts[4]
                    author_names = [a.strip() for a in authors_str.replace(" and ", ",").split(",")]
                    authors_arr = []
                    for name in author_names:
                        if name:
                            authors_arr.append({
                                "name": name,
                                "isPresenter": (name == presenter_str) or (presenter_str in name),
                                "institute": ""
                            })
                    
                    pres = {
                        "time": parts[2],
                        "title": parts[3].strip('"'),
                        "authors": authors_arr,
                        "legacy_url": pres_url if pres_url != "UNKNOWN" else "",
                        "legacy_abstract_url": abs_url if abs_url != "UNKNOWN" else "",
                        "institute": ""
                    }
                    current_session["presentations"].append(pres)
                elif len(parts) >= 3 and current_session and current_session["presentations"]:
                    # Institute matching fallback if it's an institute line
                    try:
                        idx = int(parts[1]) - 1
                        if 0 <= idx < len(current_session["presentations"]):
                            institute_name = parts[2] if parts[2] != "UNKNOWN" else ""
                            # Set institute for all authors in this presentation (or just the presenter if preferred)
                            for author in current_session["presentations"][idx]["authors"]:
                                author["institute"] = institute_name
                    except ValueError:
                        pass

        elif current_section == "6. Poster Presentations":
            if line.startswith("|") and not line.startswith("| #") and not line.startswith("|:-") and not line.startswith("| Poster #"):
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 7:
                    presenter_str = parts[4].replace("[PRESENTER]", "").replace("**", "").strip()
                    pres_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[5])
                    pres_url = pres_url_match.group(2) if pres_url_match else parts[5]
                    abs_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[6])
                    abs_url = abs_url_match.group(2) if abs_url_match else parts[6]
                    
                    # Parse authors string into array of objects
                    authors_str = parts[3]
                    author_names = [a.strip() for a in authors_str.replace(" and ", ",").split(",")]
                    authors_arr = []
                    for name in author_names:
                        if name:
                            authors_arr.append({
                                "name": name,
                                "isPresenter": (name == presenter_str) or (presenter_str in name),
                                "institute": ""
                            })
                    
                    ws["posters"].append({
                        "title": parts[2].strip('"'),
                        "authors": authors_arr,
                        "legacy_url": pres_url if pres_url != "UNKNOWN" else "",
                        "legacy_abstract_url": abs_url if abs_url != "UNKNOWN" else "",
                        "institute": ""
                    })
                elif len(parts) >= 3 and ws["posters"]:
                    try:
                        idx = int(parts[1]) - 1
                        if 0 <= idx < len(ws["posters"]):
                            institute_name = parts[2] if parts[2] != "UNKNOWN" else ""
                            for author in ws["posters"][idx]["authors"]:
                                author["institute"] = institute_name
                    except ValueError:
                        pass

        elif current_section == "7. Student Award Presenters":
            if line.startswith("|") and not line.startswith("| #") and not line.startswith("|:-"):
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 7:
                    pres_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[5])
                    pres_url = pres_url_match.group(2) if pres_url_match else parts[5]
                    abs_url_match = re.search(r'\[(.*?)\]\((.*?)\)', parts[6])
                    abs_url = abs_url_match.group(2) if abs_url_match else parts[6]
                    
                    ws["student_awards"].append({
                        "name": parts[2],
                        "institute": parts[3],
                        "title": parts[4].strip('"'),
                        "legacy_url": pres_url if pres_url != "UNKNOWN" else "",
                        "legacy_abstract_url": abs_url if abs_url != "UNKNOWN" else ""
                    })

    if current_session:
        ws["presentation_sessions"].append(current_session)

    with open('src/frontend/src/data/master_workshops.json', 'r', encoding='utf-8') as f:
        master = json.load(f)

    # find and replace
    for i, w in enumerate(master):
        if w["number"] == 6:
            # preserve some fields if we want, but user said "as completely as possible"
            master[i] = ws
            break

    with open('src/frontend/src/data/master_workshops.json', 'w', encoding='utf-8') as f:
        json.dump(master, f, indent=2)

if __name__ == "__main__":
    parse_markdown()
