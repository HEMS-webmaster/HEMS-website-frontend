import urllib.request
import fitz
import re

def test_url(url):
    try:
        response = urllib.request.urlopen(url)
        pdf_bytes = response.read()
        doc = fitz.open(stream=pdf_bytes, filetype='pdf')
        blocks = doc[0].get_text('blocks')
        text_blocks = [b[4].strip() for b in blocks if b[6] == 0 and b[4].strip()]
        if len(text_blocks) >= 3:
            content = text_blocks[2]
            # replace \n \n with \n\n just in case
            content = content.replace('
 
', '

')
            paras = [p.strip() for p in re.split(r'
\s*
', content) if p.strip()]
            print(f'URL: {url}')
            print(f'Paras: {len(paras)}')
            if len(paras) > 1:
                print(f'Author block: {paras[1].encode('utf-8')}')
            print('-'*40)
    except Exception as e:
        print(f'Error on {url}: {e}')

test_url('https://www.hems-workshop.org/6thWS/Abstracts/Austin.pdf')
test_url('https://www.hems-workshop.org/6thWS/Abstracts/Herrero.pdf')
