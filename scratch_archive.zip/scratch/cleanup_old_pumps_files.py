import os
import json
import glob

master_path = r"c:\Antigravity\HEMS-website\src\frontend\src\data\master_workshops.json"
proceedings_dir = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3rd"

with open(master_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

ws3 = None
for ws in data:
    if ws.get('number') == 3:
        ws3 = ws
        break

if not ws3:
    print("3rd workshop not found!")
    exit(1)

# Collect all currently active filenames for WS3
active_filenames = set()

# Add participant list
if ws3.get('participant_list_file'):
    active_filenames.add(ws3['participant_list_file'])

# Add oral files
for session in ws3.get('presentation_sessions', []):
    for pres in session.get('presentations', []):
        if pres.get('abstract_file'):
            active_filenames.add(pres['abstract_file'])
        if pres.get('presentation_file'):
            active_filenames.add(pres['presentation_file'])

# Add poster files
for poster in ws3.get('posters', []):
    if poster.get('abstract_file'):
        active_filenames.add(poster['abstract_file'])
    if poster.get('poster_file'):
        active_filenames.add(poster['poster_file'])
    if poster.get('presentation_file'):
        active_filenames.add(poster['presentation_file'])

print(f"Total active primary files in master_workshops.json for WS3: {len(active_filenames)}")

# Scan proceedings directory for all files
all_files = glob.glob(os.path.join(proceedings_dir, "**", "*"), recursive=True)
files_to_delete = []

for f in all_files:
    if not os.path.isfile(f):
        continue
    
    basename = os.path.basename(f)
    
    # Check if this is a primary file
    if basename in active_filenames:
        continue
        
    # Check if this is a preview file for a primary file
    is_preview = False
    for active in active_filenames:
        if active.endswith('.pdf'):
            txt_preview = active.replace('.pdf', '_preview.txt')
            png_preview = active.replace('.pdf', '_preview.png')
            if basename in (txt_preview, png_preview):
                is_preview = True
                break
                
    if is_preview:
        continue
        
    # If it is not a primary file and not a preview file for an active primary file, mark for deletion!
    files_to_delete.append(f)

print(f"\nFound {len(files_to_delete)} obsolete files to delete:")
for f in files_to_delete:
    print(f"  - {f}")
    os.remove(f)

print("\nCleanup completed successfully!")
