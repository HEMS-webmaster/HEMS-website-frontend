def parse_authors_institutes(raw_str):
    groups = []
    start_idx = -1
    stack = []
    last_end = 0
    
    for i, char in enumerate(raw_str):
        if char in '([:': # Wait, is colon ever used? No, just '(' and '['.
            if char in '([':
                if not stack:
                    start_idx = i
                stack.append(char)
        elif char in ')]':
            if stack:
                stack.pop()
                if not stack:
                    # Found a complete bracketed group
                    author_part = raw_str[last_end:start_idx].strip()
                    inst_part = raw_str[start_idx+1:i].strip()
                    groups.append((author_part, inst_part))
                    last_end = i + 1
                    
    # If there is any trailing author part or no brackets found at all
    if last_end < len(raw_str):
        remain = raw_str[last_end:].strip()
        if remain:
            # Maybe there are no brackets, e.g. "Jack Beauchamp" without institute
            # Let's clean it up
            remain = remain.strip(';').strip(',').strip()
            if remain:
                groups.append((remain, ""))
                
    # Now let's clean each group's author list and split them
    final_groups = []
    for authors_str, inst in groups:
        # Clean authors_str from leading/trailing punctuation (like semicolons, commas, dots)
        authors_str = authors_str.strip(';').strip(',').strip('.').strip()
        if not authors_str:
            continue
            
        # Split authors by comma or "and"
        # First replace " and " with ", " and then split by ","
        authors_str_clean = authors_str.replace(" and ", ", ").replace(" & ", ", ")
        # Also clean up "Director, ASPL and Astronaut" - wait!
        # In [9], "Franklin Chang-Diaz (Director, ASPL and Astronaut, NASA/Johnson Space Center)"
        # The institute is "(Director, ASPL and Astronaut, NASA/Johnson Space Center)"
        # And the author is "Franklin Chang-Diaz".
        # If the institute is extracted as "Director, ASPL and Astronaut, NASA/Johnson Space Center", that's perfect!
        
        authors = [a.strip() for a in authors_str_clean.split(',')]
        # Filter out empty strings
        authors = [a for a in authors if a]
        
        # Also let's clean "and" again if any author starts with "and "
        cleaned_authors = []
        for a in authors:
            if a.startswith("and "):
                a = a[4:].strip()
            if a:
                cleaned_authors.append(a)
                
        final_groups.append((cleaned_authors, inst))
        
    return final_groups

# Test data from our raw output
test_data = {
    6: "Jack Beauchamp, Daniel E. Austin, Thomas J. Ahrens (California Institute of Technology)",
    7: "Paul Mahaffy, Hasso Niemann, Dan Harpold (NASA/ Goddard Space Flight Center)",
    8: "Andrew Ottens, W. Harrison (University of Florida); Timothy Griffin (Dynacs Inc.); William Helms (NASA/ Kennedy Space Center)",
    9: "Jorge Diaz (Universidad de Costa Rica); Franklin Chang-Diaz (Director, ASPL and Astronaut, NASA/Johnson Space Center); Jared P. Squire, Verlin Jacobson, Greg McCaskill, Andres E. Mora Vargas (ASPL- NASA/Johnson Space Center); Henry Rohrs, Rajiv Chhatwal (Mass Sensors, Inc.)",
    10: "John H. Hoffman (University of Texas at Dallas)",
    14: "Gary McMurtry [School of Ocean and Earth Science and Technology (SOEST), University of Hawaii, and Pacific Environmental Technologies], Steven J. Smith (Jet Propulsion Laboratory)",
    20: "Franco Basile, Angelo Madonna, Kent J. Voorhees [Colorado School of Mines (CSM)]; Stephen Lammert (Oak Ridge National Laboratory); Brian Musselman, Vladimir Doroshenko [Science & Engineering Services, Inc. (SESI)]."
}

for k, v in test_data.items():
    print(f"\n=== Test {k} ===")
    print("Raw:", v)
    res = parse_authors_institutes(v)
    for authors, inst in res:
        print(f"  Authors: {authors}")
        print(f"  Institute: {inst}")
