import os

proceedings_dir = r"c:\AntigravityP1_2\HEMS-website\docs\archives_translation\proceedings"

non_pdf_files = []

for root, dirs, files in os.walk(proceedings_dir):
    for file in files:
        if file.lower().endswith('.pdf'):
            full_path = os.path.join(root, file)
            try:
                with open(full_path, 'rb') as f:
                    header = f.read(4)
                
                # Check header
                if header.startswith(b'%PDF'):
                    continue
                
                # Identify actual format
                file_format = "Unknown"
                if header.startswith(b'<HTM') or header.startswith(b'<htm') or header.startswith(b' \n<h') or header.startswith(b'<!DO'):
                    file_format = "HTML"
                elif header == b'PK\x03\x04':
                    file_format = "ZIP/Office"
                
                rel_path = os.path.relpath(full_path, proceedings_dir)
                non_pdf_files.append((rel_path, file_format, header))
            except Exception as e:
                print(f"Error reading {file}: {e}")

print(f"Found {len(non_pdf_files)} non-PDF files disguised as PDFs:")
print("| Relative Path | Stated Extension | Actual Format | Hex Header |")
print("|---|---|---|---|")
for path, fmt, header in non_pdf_files:
    print(f"| {path} | .pdf | {fmt} | {header.hex()} |")
