import re
import os

md_path = r"c:\Antigravity\HEMS-website\docs\design\pdf_seo_registry.md"

if not os.path.exists(md_path):
    print("Error: pdf_seo_registry.md not found!")
    exit(1)

with open(md_path, 'r', encoding='utf-8') as f:
    content = f.read()

blocks = content.split('---')
parsed_count = 0

print(f"Total split blocks: {len(blocks)}")

for idx, block in enumerate(blocks):
    if '### Registry ID:' not in block:
        continue
    
    entry = {}
    id_match = re.search(r'### Registry ID:\s*(\d+)', block)
    if id_match:
        entry['id'] = id_match.group(1)
        
    for line in block.strip().split('\n'):
        line = line.strip()
        if line.startswith('*   **Filename**:'):
            entry['filename'] = re.sub(r'^\*\s+\*\*Filename\*\*:\s*`([^`]+)`', r'\1', line).strip()
        elif line.startswith('*   **Path**:'):
            entry['path'] = re.sub(r'^\*\s+\*\*Path\*\*:\s*`([^`]+)`', r'\1', line).strip()
        elif line.startswith('*   **Type**:'):
            entry['type'] = re.sub(r'^\*\s+\*\*Type\*\*:\s*`([^`]+)`', r'\1', line).strip()
        elif line.startswith('*   **Year**:'):
            entry['year'] = re.sub(r'^\*\s+\*\*Year\*\*:\s*`([^`]+)`', r'\1', line).strip()
        elif line.startswith('*   **Title**:'):
            entry['title'] = re.sub(r'^\*\s+\*\*Title\*\*:\s*', '', line).strip()
        elif line.startswith('*   **Authors**:'):
            entry['authors'] = re.sub(r'^\*\s+\*\*Authors\*\*:\s*', '', line).strip()
        elif line.startswith('*   **Subject**:'):
            entry['subject'] = re.sub(r'^\*\s+\*\*Subject\*\*:\s*', '', line).strip()
        elif line.startswith('*   **Keywords**:'):
            entry['keywords'] = re.sub(r'^\*\s+\*\*Keywords\*\*:\s*', '', line).strip()

    if parsed_count < 3:
        print(f"\nParsed entry {entry.get('id')}:")
        for k, v in entry.items():
            print(f"  {k}: {repr(v)}")
    
    parsed_count += 1

print(f"\nTotal successfully parsed entries: {parsed_count}")
