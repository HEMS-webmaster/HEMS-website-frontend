import json
import re

master_file = 'src/frontend/src/data/master_workshops.json'

abstract_map = {
    "mass spectrometers for in situ planetary exploration": "abstracts2nd/AbstractBeauchamp.pdf",
    "a small multiple reflectron time of flight mass spectrometer mr tof ms for in situ investigations": "abstracts2nd/AbstractWollnik.pdf",
    "in situ laser tof ms on planets and small bodies": "abstracts2nd/AbstractBrinckerhoff.pdf",
    "a fully redundant on line mass spectrometric system for the space shuttle used to monitor cyogenic fuel leaks": "abstracts2nd/AbstractGriffin.pdf",
    "a miniaturized cylindrical lon trap mass spectrometer": "abstracts2nd/AbstractPatterson.pdf",
    "recent developments in micro lon trap mass spectrometry": "abstracts2nd/AbstractMoxom.pdf",
    "miniature tof mass spectrometer using a flexible circuitboard reflectron": "abstracts2nd/AbstractCornish.pdf",
    "disaster management using mobile mass spectrometers": "abstracts2nd/AbstractMatz.pdf",
    "direct sampling mass spectrometry in atmospheric chemistry": "abstracts2nd/AbstractBarket.pdf",
    "ms for trace explosives detection in aviation security": "abstracts2nd/AbstractChamberlain.pdf",
    "volcanic monitoring using field portable mass spectrometers towards on site and real time gas analysis at fumaroles": "abstracts2nd/AbstractDiaz.pdf",
    "project nereus concepts and principles for in situ ms": "abstracts2nd/AbstractHemond.pdf",
    "development of an underwater mass spectrometer for dissolved gases solutes and large organic compounds": "abstracts2nd/AbstractMcMurtry.pdf",
    "applications of in water mass spectrometry for detection of volatile organic compounds and dissolved gases": "abstracts2nd/AbstractShort.pdf",
    "polymeric membrane chlorocarbon permeabilities determined by membrane introduction mass spectrometry mims": "abstracts2nd/AbstractStone.pdf",
    "solid phase microextraction as a method for sampling with analysis by gas chromatography mass spectrometry in the field": "abstracts2nd/AbstractHook.pdf",
    "tiny time of flight tof mass spectrometer for biodetection": "abstracts2nd/AbstractBryden.pdf",
    "biological applications on a miniaturized delayed extraction tof mass spectrometer": "abstracts2nd/AbstractPrieto.pdf",
    "the portable horiba kore mass spectrometer ms 200": "abstracts2nd/AbstractNuber.pdf",
    "progress toward highly miniaturized vacuum pumps": "abstracts2nd/AbstractWiberg.pdf",
    "compact and rugged multipurpose tof": "abstracts2nd/PosterAbstractGonin.pdf",
    "development of a low cost miniature mass spectrometer": "abstracts2nd/PosterAbstractRohrs.pdf",
    "project nereus construction of a practical autonomous underwater gas analyzer": "abstracts2nd/PosterAbstractCamilli.pdf",
    "remotely operated mass spectrometers adaptive search platforms for field chemical profiling": "abstracts2nd/PosterAbstractFries.pdf"
}

def clean_title(title):
    title = title.replace('-', ' ').replace('/', ' ')
    title = re.sub(r'[^a-zA-Z0-9\s]', '', title)
    title = re.sub(r'\s+', ' ', title).strip().lower()
    return title

with open(master_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

updated = False
ws2 = None
for ws in data:
    if ws.get('number') == 2:
        ws2 = ws
        break

if ws2:
    # 1. Update oral presentations
    oral_count = 0
    for session in ws2.get('presentation_sessions', []):
        for pres in session.get('presentations', []):
            title = pres.get('title', '')
            cleaned = clean_title(title)
            matched_url = abstract_map.get(cleaned)
            if matched_url:
                if not matched_url.startswith("http"):
                    matched_url = "https://www.hems-workshop.org/2ndWS/" + matched_url
                pres['legacy_abstract_url'] = matched_url
                pres['abstract_url'] = matched_url
                print(f"Matched Oral: {title[:50]} -> {matched_url}")
                oral_count += 1
            else:
                print(f"Warning: No oral match found for '{title}'")
                
    # 2. Update poster presentations
    poster_count = 0
    for poster in ws2.get('posters', []):
        title = poster.get('title', '')
        cleaned = clean_title(title)
        matched_url = abstract_map.get(cleaned)
        if matched_url:
            if not matched_url.startswith("http"):
                matched_url = "https://www.hems-workshop.org/2ndWS/" + matched_url
            poster['legacy_abstract_url'] = matched_url
            poster['abstract_url'] = matched_url
            print(f"Matched Poster: {title[:50]} -> {matched_url}")
            poster_count += 1
        else:
            print(f"Warning: No poster match found for '{title}'")

    print(f"\nUpdated {oral_count} oral and {poster_count} poster presentations.")
    
    with open(master_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    print("Saved changes to master_workshops.json.")
else:
    print("Error: Workshop 2 not found in master_workshops.json.")
