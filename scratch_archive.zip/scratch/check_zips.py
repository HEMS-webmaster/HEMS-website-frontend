import os
import zipfile

# Let's inspect the files in 3th proceedings directory to check their magic headers
dir_path = r"c:\Antigravity\HEMS-website\docs\archives_translation\proceedings\3th"

print("Scanning 3th proceedings subdirectories for PK headers:")
for root, dirs, files in os.walk(dir_path):
    for file in files:
        if file.lower().endswith('.pdf'):
            full_p = os.path.join(root, file)
            with open(full_p, 'rb') as f:
                header = f.read(4)
            if header == b'PK\x03\x04':
                # It's actually a zip archive! Let's see what is inside.
                print(f"Zip File masked as PDF: {file}")
                try:
                    with zipfile.ZipFile(full_p, 'r') as z:
                        namelist = z.namelist()
                        print(f"  Contents (first 5): {namelist[:5]} (Total files: {len(namelist)})")
                except Exception as e:
                    print(f"  Error opening zip: {e}")
            elif header.startswith(b'%PDF'):
                pass
            else:
                print(f"Unknown header {header} for file: {file}")
