import os
import re
from bs4 import BeautifulSoup

def parse_authors_institutes(raw_str):
    groups = []
    start_idx = -1
    stack = []
    last_end = 0
    
    for i, char in enumerate(raw_str):
        if char in '([':
            if not stack:
                start_idx = i
            stack.append(char)
        elif char in ')]':
            if stack:
                stack.pop()
                if not stack:
                    # Found a complete bracketed group
                    author_part = raw_str[last_end:start_idx].strip()
                    inst_part = raw_str[start_idx+1:i].strip()
                    groups.append((author_part, inst_part))
                    last_end = i + 1
                    
    # If there is any trailing author part or no brackets found at all
    if last_end < len(raw_str):
        remain = raw_str[last_end:].strip()
        if remain:
            remain = remain.strip(';').strip(',').strip()
            if remain:
                groups.append((remain, ""))
                
    # Now let's clean each group's author list and split them
    final_groups = []
    for authors_str, inst in groups:
        authors_str = authors_str.strip(';').strip(',').strip('.').strip()
        if not authors_str:
            continue
            
        authors_str_clean = authors_str.replace(" and ", ", ").replace(" & ", ", ")
        
        authors = [a.strip() for a in authors_str_clean.split(',')]
        authors = [a for a in authors if a]
        
        cleaned_authors = []
        for a in authors:
            if a.startswith("and "):
                a = a[4:].strip()
            if a:
                cleaned_authors.append(a)
                
        final_groups.append((cleaned_authors, inst))
        
    return final_groups

def clean_body_text(body_text):
    body_text = ' '.join(body_text.split())
    # Match: optional leading > or &gt;, optional spaces, case-insensitive "program", optional trailing dots/spaces
    body_text = re.sub(r'\s*(?:[>&gt;]+\s*)?program\s*$', '', body_text, flags=re.IGNORECASE)
    return body_text.strip()

def main():
    html_path = 'scratch/3rdposter.htm'
    print(f"Reading local HTML from {html_path}...")
    with open(html_path, 'r', encoding='latin-1') as f:
        html = f.read()
        
    soup = BeautifulSoup(html, 'html.parser')
    
    # The poster abstracts are inside the td tags of the first inner table
    # Let's find the inner table
    tables = soup.find_all('table')
    print(f"Found {len(tables)} tables.")
    
    # We want the table that contains the posters.
    # In the HTML, there's a table with width="100%" and border="0" inside another table.
    target_table = None
    for t in tables:
        if t.get('width') == '100%':
            target_table = t
            break
            
    if not target_table:
        print("Error: Could not find target table with width='100%'")
        return
        
    tds = target_table.find_all('td')
    print(f"Found {len(tds)} td cells in target table.")
    
    markdown_content = []
    markdown_content.append("# 3rd Harsh-Environment Mass Spectrometry Workshop - Presented Posters (Abstracts)")
    markdown_content.append(f"\n*Source: [https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdposter.htm](https://www.hems-workshop.org/3rdWS/Abstracts%203rd/3rdposter.htm)*\n")
    
    poster_idx = 0
    
    for td in tds:
        # Check if the cell has a bold element containing a quote (which indicates a title)
        p_tags = td.find_all('p')
        if not p_tags:
            continue
            
        p0 = p_tags[0]
        # Title is typically in bold/strong tags or starts with quote
        bold_tag = p0.find(['b', 'strong'])
        if not bold_tag:
            continue
            
        title_str = ' '.join(bold_tag.get_text().split()).strip()
        # Clean title quotes using replace for HTML entities to avoid stripping literal ending characters
        for q in ['&quot;', '&ldquo;', '&rdquo;', '“', '”', '"', "'"]:
            title_str = title_str.replace(q, '')
        title_str = title_str.strip()
        
        # If the title is empty, it's a spacer paragraph
        if not title_str or len(title_str) < 5:
            continue
            
        poster_idx += 1
        
        # 2. Extract Authors and Institutes (what follows bold_tag in p0)
        authors_institutes_str = ""
        curr = bold_tag.next_sibling
        while curr:
            authors_institutes_str += curr.get_text() if hasattr(curr, 'get_text') else str(curr)
            curr = curr.next_sibling
            
        authors_institutes_str = ' '.join(authors_institutes_str.split()).strip()
        # Remove any leading <br> represented as string or leading spaces
        authors_institutes_str = re.sub(r'^<br\s*/?>', '', authors_institutes_str).strip()
        
        # Clean up double punctuation or trailing stuff
        authors_institutes_str = authors_institutes_str.strip()
        parsed_groups = parse_authors_institutes(authors_institutes_str)
        
        # 3. Parse Body Paragraphs
        body_parts = []
        for p in p_tags[1:]:
            p_text = p.get_text().strip()
            if p_text:
                cleaned_p = clean_body_text(p_text)
                if cleaned_p:
                    # Ignore the &nbsp; or spacer paragraphs
                    if cleaned_p != '\xa0' and cleaned_p != '&nbsp;':
                        body_parts.append(cleaned_p)
                        
        body_str = "\n\n".join(body_parts)
        
        # Formulate Markdown entry
        markdown_content.append(f"\n---\n")
        markdown_content.append(f"## {poster_idx}. {title_str}\n")
        
        # Add Authors & Institutes
        if len(parsed_groups) == 1:
            authors, inst = parsed_groups[0]
            authors_formatted = ", ".join(authors)
            markdown_content.append(f"**Authors**: {authors_formatted}  ")
            if inst:
                markdown_content.append(f"**Institute**: {inst}  ")
            markdown_content.append("") # empty line
        else:
            markdown_content.append("**Authors & Institutes**:")
            for authors, inst in parsed_groups:
                authors_formatted = ", ".join(authors)
                if inst:
                    markdown_content.append(f"- {authors_formatted} ({inst})")
                else:
                    markdown_content.append(f"- {authors_formatted}")
            markdown_content.append("") # empty line
            
        # Add Abstract Body
        markdown_content.append(f"**Abstract**:")
        markdown_content.append(body_str)
        markdown_content.append("")
        
    output_path = 'docs/archives_translation/3rdposter.md'
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(markdown_content))
        
    print(f"Successfully wrote {poster_idx} parsed abstracts to {output_path}")

if __name__ == '__main__':
    main()
