import os
import subprocess
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

output_dir = r"docs/archives_translation/proceedings/3rd/Technical_Session_I__Space_Environments"
output_path = os.path.join(output_dir, "3rd_Beauchamp_Novel_Mass_Spectrometric_Abstract.pdf")

# Abstract text details
title = "Novel Mass Spectrometric Approaches to the In situ Chemical Analysis of Galactic and Cometary Dust Particles"
authors = "Authors: Jack Beauchamp, Daniel E. Austin, Thomas J. Ahrens"
institute_html = '<font fontName="Helvetica-BoldOblique">Institute</font>: California Institute of Technology'
abstract_body = (
    "Analysis of the chemical composition of cosmic dust particles offers a challenge for "
    "mass spectrometry. Particles of interest range from high velocity galactic mineral grains "
    "to cometary debris comprising frozen volatiles. A variety of different approaches have "
    "been taken in the past to analyze such particles in the space environment. Considering "
    "the performance and limitations of earlier instruments, we have designed and tested a "
    "novel compact impact-ionization time-of-flight mass spectrometer for analysis of cosmic "
    "dust, suitable for use on deep space missions. The instrument, Dustbuster, incorporates "
    "a large target area with a reflectron, simultaneously optimizing mass resolution, "
    "particle detection, and ion collection. Dust particles hit a 65-cm^2 target plate and "
    "are partially ionized by the impact. The resulting ions, with broad energy and angular "
    "distributions, are accelerated through a modified reflectron, focusing ions of specific "
    "m/z in space and time to produce high-resolution mass spectra. The cylindrically "
    "symmetric instrument is 10 cm in diameter and 20 cm in length, considerably smaller "
    "than previous in situ dust analyzers, and can be easily scaled as needed for specific "
    "mission requirements. Laser desorption ionization of metal and mineral samples embedded "
    "in the impact plate has been used to simulate particle impacts for evaluation of instrument "
    "performance. Mass resolution in these experiments ranged from 60-180, permitting "
    "resolution of isotopes. Instrument performance has been further verified using high-velocity "
    "(2-12 km/s) particles produced by a 2 MV Van de Graaff accelerator. We are now conducting "
    "additional impact experiments using micron-sized ice particles to simulate cometary "
    "debris. This work was supported by a grant from NASA's Planetary Instrument Definition "
    "and Development Program (PIDDP). [Reference: Austin, D. E.; Ahrens, T. J.; and Beauchamp, "
    "J. L. (2002) Rev. Sci. Instrum., 73(1), 185-189.]"
)

def draw_header_footer(canvas, doc):
    canvas.saveState()
    
    # Running Header Text
    canvas.setFont('Helvetica-Oblique', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 748, '3rd Harsh-Environment Mass Spectrometry Workshop (2002)')
    
    # Running Header Bar (3pt height)
    canvas.setFillColor(colors.HexColor('#1f3a56'))
    canvas.rect(54, 738, 504, 3, fill=True, stroke=False)
    
    # Running Footer Left
    canvas.setFont('Helvetica', 8.0)
    canvas.setFillColor(colors.HexColor('#7f8c8d'))
    canvas.drawString(54, 32, 'https://www.hems-workshop.org')
    
    # Running Footer Right
    canvas.drawRightString(558, 32, 'Presented Talk Abstract')
    
    canvas.restoreState()

def build_pdf():
    os.makedirs(output_dir, exist_ok=True)
    
    # SimpleDocTemplate with precise margins to match 54pt X margins and Y boundaries
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=72,
        bottomMargin=54
    )
    
    styles = getSampleStyleSheet()
    
    # Custom premium styles matching our PyMuPDF inspection analysis
    workshop_style = ParagraphStyle(
        'WorkshopStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.5,
        textColor=colors.HexColor('#b38f4d'),
        spaceAfter=8,
        leading=11
    )
    
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=13.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=12,
        leading=15
    )
    
    authors_style = ParagraphStyle(
        'AuthorsStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        textColor=colors.HexColor('#2c3e50'),
        spaceAfter=4,
        leading=12
    )
    
    institute_style = ParagraphStyle(
        'InstituteStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        textColor=colors.HexColor('#7f8c8d'),
        spaceAfter=15,
        leading=11
    )
    
    abstract_header_style = ParagraphStyle(
        'AbstractHeaderStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.0,
        textColor=colors.HexColor('#1f3a56'),
        spaceAfter=8,
        leading=12
    )
    
    body_style = ParagraphStyle(
        'BodyStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9.5,
        textColor=colors.HexColor('#1a1a1a'),
        spaceAfter=10,
        leading=13.5
    )
    
    # Horizontal rule divider below title
    divider = Table([['']], colWidths=[504], rowHeights=[1])
    divider.setStyle(TableStyle([
        ('LINEABOVE', (0,0), (-1,-1), 0.75, colors.HexColor('#e2e8f0')),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
    ]))
    
    story = []
    
    story.append(Paragraph("3RD HARSH-ENVIRONMENT MASS SPECTROMETRY WORKSHOP", workshop_style))
    story.append(Paragraph(title, title_style))
    story.append(divider)
    story.append(Spacer(1, 10))
    story.append(Paragraph(authors, authors_style))
    story.append(Paragraph(institute_html, institute_style))
    story.append(Paragraph("ABSTRACT", abstract_header_style))
    story.append(Paragraph(abstract_body, body_style))
    
    doc.build(story, onFirstPage=draw_header_footer, onLaterPages=draw_header_footer)
    print(f"Successfully generated PDF: {output_path}")

if __name__ == '__main__':
    build_pdf()
    
    # Generate the text preview using the existing preview generator
    print("Generating text preview file...")
    try:
        subprocess.run(["python", "scratch/preview_generator.py", output_path], check=True)
        print("Successfully generated preview text!")
    except Exception as e:
        print(f"Error generating preview text: {e}")
