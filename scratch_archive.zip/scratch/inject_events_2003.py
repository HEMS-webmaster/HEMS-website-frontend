import json

file_path = 'c:/Antigravity/HEMS-website/src/frontend/src/data/master_workshops.json'
with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

events_data = [
    {
        "date": "2003-10-07",
        "title": "Travel Day",
        "time": "",
        "end_time": "",
        "location": "",
        "events": [
            {
                "time": "7:00 p.m.",
                "end_time": "",
                "title": "Welcome Reception",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Tradewinds Sirata Beach Resort",
                "location_url": ""
            }
        ]
    },
    {
        "date": "2003-10-08",
        "title": "HEMS Workshop",
        "time": "7:30 a.m.",
        "end_time": "",
        "location": "",
        "events": [
            {
                "time": "7:30 a.m.",
                "end_time": "",
                "title": "Continental Breakfast",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "8:30 a.m.",
                "end_time": "",
                "title": "Welcoming Remarks",
                "subtitle": "Peter Betzer, Tim Short",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "10:00 a.m.",
                "end_time": "",
                "title": "Coffee Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "11:30 a.m.",
                "end_time": "",
                "title": "Lunch on your own",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "3:00 p.m.",
                "end_time": "",
                "title": "Afternoon Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "5:30 p.m.",
                "end_time": "",
                "title": "Evening Free",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            }
        ]
    },
    {
        "date": "2003-10-09",
        "title": "HEMS Workshop",
        "time": "7:30 a.m.",
        "end_time": "",
        "location": "",
        "events": [
            {
                "time": "7:30 a.m.",
                "end_time": "",
                "title": "Continental Breakfast and Vendor Expo",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "10:00 a.m.",
                "end_time": "",
                "title": "Coffee Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "11:30 a.m.",
                "end_time": "",
                "title": "Lunch on your own",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "3:00 p.m.",
                "end_time": "",
                "title": "Afternoon Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "4:30 p.m.",
                "end_time": "",
                "title": "Free Time",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            },
            {
                "time": "6:30 p.m.",
                "end_time": "",
                "title": "Workshop Dinner",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Breezeway",
                "location_url": ""
            }
        ]
    },
    {
        "date": "2003-10-10",
        "title": "HEMS Workshop",
        "time": "7:30 a.m.",
        "end_time": "",
        "location": "",
        "events": [
            {
                "time": "7:30 a.m.",
                "end_time": "",
                "title": "Continental Breakfast",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "10:00 a.m.",
                "end_time": "",
                "title": "Coffee Break",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Royal Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "11:30 a.m.",
                "end_time": "",
                "title": "Lunch",
                "subtitle": "",
                "subtitle_url": "",
                "location": "Mediterranean Palm Ballroom",
                "location_url": ""
            },
            {
                "time": "1:00 p.m.",
                "end_time": "",
                "title": "Workshop ends",
                "subtitle": "",
                "subtitle_url": "",
                "location": "",
                "location_url": ""
            }
        ]
    }
]

for workshop in data:
    if workshop.get('number') == 4 or workshop.get('year') == '2003':
        workshop['events'] = events_data
        break

with open(file_path, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)

print("Updated itinerary events for 2003 workshop.")
