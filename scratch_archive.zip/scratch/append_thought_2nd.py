import os
from datetime import datetime

thought_log_path = 'docs/logs/thought_trace.md'

thought_text = f"""
## SCoT Trace - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
### Action: Extracting Abstract URLs for 2nd Workshop and Encountering Immutable Reference Lock

#### 1. Context and Objective
We fetched and parsed `https://www.hems-workshop.org/2ndWS/2ndprogrampresentations.html` to find the abstract URL for each oral and poster presentation.
We successfully extracted the abstract URLs:
- For Oral Presentation: Jorge A. Diaz ("Volcanic Monitoring using Field-Portable Mass Spectrometers...") -> `abstracts2nd/AbstractDiaz.pdf`
- For Poster Presentation: D. P. Fries ("Remotely Operated Mass Spectrometers...") -> `abstracts2nd/PosterAbstractFries.pdf`

The user's instruction is to put them in the currently-empty abstract fields of `source-material\\Old site docs\\02thWorkshopSummary.md`.

#### 2. Lock Encounter
The file `source-material\\Old site docs\\02thWorkshopSummary.md` is located within the `source-material/` directory, which is protected under the **IMMUTABLE REFERENCE LOCK (READ-ONLY)** (Rule #1) of `locksrules.md`.
Rule #1 states:
- Protected Directory: `/source-material` (and all subdirectories containing datasets, academic literature, or legacy reference code).
- Restriction: READ-ONLY.
- Modification Policy: You are strictly prohibited from modifying, deleting, or refactoring any file within this folder. It is for context and extraction only.

#### 3. Execution Plan / Escape Hatch Activation
Because the task requires writing to a file inside the protected `/source-material` folder, we must invoke **Rule #6: ESCAPE HATCH (WORKFLOW OVERRIDE)**:
1. STOP all execution immediately.
2. Output in the main chat the exact message:
   "SYSTEM LOCK ENCOUNTERED: I need to modify source-material\\Old site docs\\02thWorkshopSummary.md which violates Lock Rule #1 (IMMUTABLE REFERENCE LOCK). User, do I have explicit permission to bypass this lock for this task?"
3. Await explicit human approval before making the file modification.
"""

if os.path.exists(thought_log_path):
    with open(thought_log_path, 'a', encoding='utf-8') as f:
        f.write(thought_text)
    print("Successfully appended thought trace to log.")
else:
    print("Error: thought_trace.md not found.")
