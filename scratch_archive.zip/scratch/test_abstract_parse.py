import os
import json
import re
from bs4 import BeautifulSoup

def get_abstracts_from_file(filepath):
    soup = BeautifulSoup(open(filepath, encoding='utf-8', errors='replace'), 'html.parser')
    abstracts = []
    
    current_abstract = None
    for p in soup.find_all('p'):
        b_tag = p.find('b')
        if b_tag and '"' in b_tag.text:
            if current_abstract:
                abstracts.append(current_abstract)
            
            title = b_tag.text.strip().replace('"', '').replace('\n', ' ').replace('\r', '')
            title = re.sub(r'\s+', ' ', title).strip()
            
            b_tag.extract()
            for a in p.find_all('a'):
                a.extract()
            
            authors_text = p.text.replace('\n', ' ').replace('\r', '')
            authors_text = re.sub(r'\s+', ' ', authors_text).strip()
            
            current_abstract = {
                'title': title,
                'authors_text': authors_text,
                'body': []
            }
        elif current_abstract:
            text = p.text.replace('\n', ' ').replace('\r', '')
            text = re.sub(r'\s+', ' ', text).strip()
            if text:
                # Some files have 'Back to 3rd HEMS Workshop' at the bottom
                if 'Back to 3rd HEMS Workshop' in text:
                    continue
                current_abstract['body'].append(text)
    
    if current_abstract:
        abstracts.append(current_abstract)
        
    return abstracts

files = ['scratch/3rdhemstalks.htm', 'scratch/3rdposter.htm', 'scratch/3rdpumpstalks.htm']
all_abs = []
for f in files:
    all_abs.extend(get_abstracts_from_file(f))

print(f"Found {len(all_abs)} abstracts.")
print("Sample abstract:")
if all_abs:
    print(all_abs[0]['title'])
    print(all_abs[0]['authors_text'])
    print(all_abs[0]['body'][0][:100] + "...")
